import React, { createContext, useState, useContext, useEffect } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

// Create the context
const AppContext = createContext();

export function useAppContext() {
  return useContext(AppContext);
}

export function AppProvider({ children }) {
  const [runningRecipeContext, setRunningRecipeContext] = useState([]);
  const [activeKitchenId, setActiveKitchenId] = useState(null);
  const [loggedInUser, setLoggedInUser] = useState(null);
  const checkloginUSer = async () => {
    const jsonString = await AsyncStorage.getItem("@token");
    if (jsonString) {
      const decoded = decodeToken(jsonString);
      if (decoded) {
        if (decoded.exp) {
          const currentTime = Math.floor(Date.now() / 1000);
          const isExpired = currentTime >= decoded.exp;
          if (!isExpired) {
            setLoggedInUser(decoded.sub);
          }
        }
      }
    }
  };
  useEffect(() => {
    checkloginUSer();
  }, []);
  const retrieveFromAsyncStorage = async () => {
    try {
      const jsonString = await AsyncStorage.getItem("@RunningRecipe");
      if (jsonString !== null) {
        const data = JSON.parse(jsonString);
        const foundItems = data.filter(
          (item) => item.kitchen_id === activeKitchenId?.kitchen_id
        );

        return foundItems;
      } else {
        console.log("No data found");
      }
    } catch (error) {
      console.error("Error retrieving data from AsyncStorage:", error);
    }
    return [];
  };
  useEffect(() => {
    const getV = async () => {
      let run = await retrieveFromAsyncStorage();
      if (run != null) {
        let temp = run;
        setRunningRecipeContext(temp);
      }
    };
    if (activeKitchenId != null) getV();
    else setRunningRecipeContext([]);
  }, [activeKitchenId]);
  const value = {
    runningRecipeContext,
    setRunningRecipeContext,
    activeKitchenId,
    setActiveKitchenId,
    loggedInUser,
    setLoggedInUser,
  };
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}
const decodeToken = (jwt) => {
  try {
    const base64Url = jwt.split(".")[1]; // Get payload
    let base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/"); // Decode base64url to base64

    // Add padding if necessary
    const padding = "=".repeat((4 - (base64.length % 4)) % 4); // Calculate padding
    base64 += padding; // Add padding

    const jsonPayload = decodeURIComponent(
      atob(base64)
        .split("")
        .map((c) => `%${`00${c.charCodeAt(0).toString(16)}`.slice(-2)}`)
        .join("")
    );

    return JSON.parse(jsonPayload);
  } catch (error) {
    console.error("Error decoding JWT:", error);
    return null;
  }
};
