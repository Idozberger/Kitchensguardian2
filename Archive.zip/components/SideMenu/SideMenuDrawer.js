import { DrawerContentScrollView, DrawerItem } from "@react-navigation/drawer";
import { useRouter } from "expo-router";
import {
  View,
  TouchableHighlight,
  StyleSheet,
  Text,
  Image,
  TouchableWithoutFeedback,
  Alert,
  ScrollView,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useAppContext } from "@/components/AppContext";

// import { Image } from "expo-image";
export default function SideMenuDrawer(props) {
  const router = useRouter();
  const { loggedInUser, setActiveKitchenId, setLoggedInUser, activeKitchenId } =
    useAppContext();

  const handleLogout = async () => {
    try {
      // Clear all local storage data
      setActiveKitchenId(null);
      setLoggedInUser(null);
      await AsyncStorage.clear();

      // Navigate to the "/" route
      router.replace("/");
    } catch (error) {
      console.error("Error clearing local storage:", error);
    }
  };
  return (
    <View
      style={{
        flex: 1,
        backgroundColor: "#FFF6E5",
        paddingHorizontal: 22,
        paddingTop: 50,
        paddingBottom: 30,
        justifyContent: "space-between",
        zIndex: 3,
      }}
    >
      <View style={{ flex: 1 }}>
        <View style={styles.userInfo}>
          <Image
            style={styles.userAvatar}
            source={require("../../assets/images/SideMenu/avatar.png")}
          />
          <Text style={styles.userName}>{loggedInUser?.first_name}</Text>
          <Text style={styles.userEmail}>{loggedInUser?.email}</Text>
        </View>
        <ScrollView 
          style={{
            marginTop: 40,
            flex: 1,
          }}
          showsVerticalScrollIndicator={false}
        >
          <View
            style={{
              justifyContent: "space-between",
              flexDirection: "column",
            }}
          >
            <TouchableWithoutFeedback
              onPress={() => router.replace("/dashboard/profile")}
              // style={styles.item}
            >
              <View style={styles.item}>
                <Image
                  style={styles.itemIcon}
                  source={require("../../assets/images/SideMenu/icons/user.png")}
                />
                <Text style={styles.itemText}>My Profile</Text>
              </View>
            </TouchableWithoutFeedback>

            {activeKitchenId != null && (
              <>
                <TouchableWithoutFeedback
                  onPress={() => {
                    // Alert.alert("Hello");
                    router.push("/dashboard/home/available_recipes/recipe_fav");
                  }}
                >
                  <View style={styles.item}>
                    <Image
                      style={styles.itemIcon}
                      source={require("../../assets/images/SideMenu/icons/heart.png")}
                    />
                    <Text style={styles.itemText}>Favortites</Text>
                  </View>
                </TouchableWithoutFeedback>
                <TouchableWithoutFeedback
                  onPress={() => router.push("/dashboard/home/kitchen/members")}
                  // style={styles.item}
                >
                  <View style={styles.item}>
                    <Image
                      style={styles.itemIcon}
                      source={require("../../assets/images/SideMenu/icons/mail.png")}
                    />
                    <Text style={styles.itemText}>View Kitchen</Text>
                  </View>
                </TouchableWithoutFeedback>
                {/* <TouchableWithoutFeedback
                onPress={() => router.push("/dashboard/home/kitchen/members")}
                // style={styles.item}
              >
                <View style={styles.item}>
                  <Image
                    style={styles.itemIcon}
                    source={require("../../assets/images/SideMenu/icons/family.png")}
                  />
                  <Text style={styles.itemText}>Friends & Family Codes</Text>
                </View>
              </TouchableWithoutFeedback> */}

                <TouchableWithoutFeedback
                  // onPress={() => router.push("/dashboard/home/see_all_items")}
                  onPress={() => router.push("/dashboard/home/searched_items")}
                >
                  <View style={styles.item}>
                    <Image
                      style={styles.itemIcon}
                      source={require("../../assets/images/SideMenu/icons/history.png")}
                    />
                    <Text style={styles.itemText}>Scan History </Text>
                  </View>
                </TouchableWithoutFeedback>
                <TouchableWithoutFeedback
                  onPress={() => router.push("/dashboard/home/kitchen/kitchen_lst")}
                >
                  <View style={styles.item}>
                    <Image
                      style={styles.itemIcon}
                      source={require("../../assets/images/SideMenu/icons/kitchen.png")}
                    />
                    <Text style={styles.itemText}>Kitchens </Text>
                  </View>
                </TouchableWithoutFeedback>
                <TouchableWithoutFeedback
                  onPress={() => router.push("/dashboard/home/my_list_items")}
                >
                  <View style={styles.item}>
                    <Image
                      style={styles.itemIcon}
                      source={require("../../assets/images/SideMenu/icons/kitchen.png")}
                    />
                    <Text style={styles.itemText}>My List </Text>
                  </View>
                </TouchableWithoutFeedback>
                {/* <TouchableWithoutFeedback
                  onPress={() => router.push("/dashboard/home/searched_items")}
                >
                  <View style={styles.item}>
                    <Image
                      style={styles.itemIcon}
                      source={require("../../assets/images/SideMenu/icons/kitchen.png")}
                    />
                    <Text style={styles.itemText}>Searched Items</Text>
                  </View>
                </TouchableWithoutFeedback> */}
              </>
            )}
            {/* <TouchableWithoutFeedback
            onPress={() => router.replace("/")}
            // style={styles.item}
          >
            <View style={styles.item}>
              <Image
                style={styles.itemIcon}
                source={require("../../assets/images/SideMenu/icons/terms.png")}
              />
              <Text style={styles.itemText}>Terms and Conditions </Text>
            </View>
          </TouchableWithoutFeedback> */}
          </View>
        </ScrollView>
      </View>
      <View style={{ marginTop: 20 }}>
        <TouchableWithoutFeedback onPress={handleLogout}>
          <View style={styles.logoutBtn}>
            <Image
              style={styles.logoutIcon}
              source={require("../../assets/images/SideMenu/icons/logout.png")}
            />
            <Text style={styles.logoutText}>Logout</Text>
          </View>
        </TouchableWithoutFeedback>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  userAvatar: {
    width: 48,
    height: 48,
    borderRadius: 32,
    shadowColor: "#FFC529",
    shadowOffset: { width: 0, height: 5.69 },
    shadowOpacity: 0.25, // 40% opacity in hexadecimal translates to approximately 0.25 in shadowOpacity.
    shadowRadius: 28.44,
  },
  logoutBtn: {
    width: 117,
    height: 43,
    borderRadius: 28.5,
    borderWidth: 0.8,
    borderColor: "#F8A600",
    shadowColor: "#E6C068",
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 1,
    shadowRadius: 20,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#161714",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  logoutText: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 16,
    fontWeight: "400",
    lineHeight: 16,
    textAlign: "left",
    color: "#F8A600",
  },
  userName: {
    fontFamily: "InriaSerif_700Bold",
    fontSize: 16,
    fontWeight: "700",
    lineHeight: 20,
    textAlign: "left",
    color: "#000",
    marginTop: 10,
  },
  userEmail: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 10,
    fontWeight: "400",
    lineHeight: 10,
    textAlign: "left",
    color: "#656565",
    marginTop: 5,
  },
  item: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 15,
  },
  itemIcon: {
    width: 23,
    height: 23,
  },
  itemText: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 16,
    fontWeight: "400",
    lineHeight: 16,
    textAlign: "left",
    color: "#000",
    marginLeft: 10,
  },
  logoutIcon: {
    width: 26,
    height: 26,
    marginRight: 8,
  },
});
