import { Image, View, StyleSheet, Text, Pressable, Alert } from "react-native";
import { useNavigation, useRouter, Tabs, useSegments } from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useAppContext } from "@/components/AppContext";
import { useEffect, useState } from "react";
export default function TabLayout() {
  const { runningRecipeContext, activeKitchenId } = useAppContext();
  const [selectedRunningRecipeIndex, setSelectedRunningRecipeIndex] =
    useState(0);
  const router = useRouter();
  const segments = useSegments();
  const hideBottomViewRoute = "recipe_home";
  useEffect(() => {
    if (runningRecipeContext.length < selectedRunningRecipeIndex+1) {
      setSelectedRunningRecipeIndex(0);
    }
  }, [runningRecipeContext]);
  // Check if the last segment of the route matches the specified route
  const shouldHideBottomView =
    (segments.includes("available_recipes") &&
      segments.includes("recipe_home")) ||
    (segments.includes("kitchen")) ||
    (segments.includes("home") && segments.includes("camera"));
  const handlePress = () => {
    router.push({
      pathname: "/dashboard/home/available_recipes/recipe_home",
      params: {
        data: JSON.stringify(runningRecipeContext[selectedRunningRecipeIndex]),
      },
    });
  };
  const retrieveFromAsyncStorage = async () => {
    try {
      const jsonString = await AsyncStorage.getItem("@RunningRecipe");
      if (jsonString !== null) {
        const data = JSON.parse(jsonString);
        return data;
      } else {
        console.log("No data found");
      }
    } catch (error) {
      console.error("Error retrieving data from AsyncStorage:", error);
    }
    return null;
  };
  return (
    <View style={styles.container}>
      <Tabs
        screenOptions={{
          headerShown: false,
          tabBarActiveTintColor: "#000",
          tabBarInactiveTintColor: "#000",
          tabBarHideOnKeyboard: true,
          tabBarStyle: {
            backgroundColor: "#161714", // Tab bar background color
            height: 60, // Tab bar height
            alignItems: "center",
            marginTop:
              runningRecipeContext != null &&
              runningRecipeContext.length > 0 &&
              !shouldHideBottomView
                ? 80
                : 3,
          },
          tabBarLabelStyle: {
            fontFamily: "InriaSerif_400Regular",
            fontSize: 9,
            fontWeight: "400",
            lineHeight: 9,
            textAlign: "center",
            color: "#F8A600",
          },
          tabBarItemStyle: {
            alignItems: "center",
            justifyContent: "center",
            height: 50,
          },
        }}
      >
        <Tabs.Screen
          name="list"
          options={{
            title: "List",
            tabBarIcon: ({}) => (
              <Image
                source={require("../../assets/images/tab_menu/list.png")}
                style={{ width: 24, height: 24 }}
              />
            ),
            href: activeKitchenId != null ? undefined : null,
          }}
          listeners={({ navigation }) => ({
            tabPress: (e) => {
              e.preventDefault(); // Prevent default tab behavior
              router.push("/dashboard/home/my_list_items"); // Reset the route
            },
          })}
        />
        <Tabs.Screen
          name="home"
          options={{
            title: "Home",
            tabBarIcon: ({}) => (
              <Image
                source={require("../../assets/images/tab_menu/home.png")}
                style={{ width: 24, height: 24 }}
              />
            ),
          }}
          listeners={({ navigation }) => ({
            tabPress: (e) => {
              e.preventDefault(); // Prevent default tab behavior
              router.push("/dashboard/home"); // Reset the route
            },
          })}
        />
        <Tabs.Screen
          name="notification"
          options={{
            title: "Notification",
            tabBarIcon: ({}) => (
              <Image
                source={require("../../assets/images/tab_menu/notification.png")}
                style={{ width: 24, height: 24 }}
              />
            ),
            href: activeKitchenId != null ? undefined : null,
          }}
        />
        <Tabs.Screen
          name="profile"
          options={{
            title: "Profile",
            tabBarIcon: ({}) => (
              <Image
                source={require("../../assets/images/tab_menu/profile.png")}
                style={{ width: 24, height: 24 }}
              />
            ),
          }}
        />
      </Tabs>
      {runningRecipeContext != null &&
        runningRecipeContext.length > 0 &&
        !shouldHideBottomView && (
          <Pressable style={styles.absoluteBottomView} onPress={handlePress}>
            <View style={styles.TopBAr}>
              <Text style={styles.title}>Recipe Under making</Text>
              <View style={styles.Navigation}>
                <Pressable
                  onPress={() => {
                    selectedRunningRecipeIndex > 0
                      ? setSelectedRunningRecipeIndex((prev) => prev - 1)
                      : "";
                  }}
                >
                  <Image
                    style={[
                      styles.NavigationArrow,
                      { opacity: selectedRunningRecipeIndex == 0 ? 0.5 : 1 },
                    ]}
                    source={require("../../assets/images/NavigationLeftArrow.png")}
                  />
                </Pressable>
                <Text style={styles.NavigationText}>
                  {selectedRunningRecipeIndex+1} / {runningRecipeContext.length}
                </Text>
                <Pressable
                  onPress={() => {
                    selectedRunningRecipeIndex < runningRecipeContext.length - 1
                      ? setSelectedRunningRecipeIndex((prev) => prev + 1)
                      : "";
                  }}
                >
                  <Image
                    style={[
                      styles.NavigationArrow,
                      {
                        opacity:
                          selectedRunningRecipeIndex <
                          runningRecipeContext.length - 1
                            ? 1
                            : 0.5,
                      },
                    ]}
                    source={require("../../assets/images/NavigationRightArrow.png")}
                  />
                </Pressable>
              </View>
            </View>
            <View style={styles.itemRow}>
              <View style={styles.itemRowLeft}>
                <Image
                  style={styles.itemRowLeftImg}
                  source={require("../../assets/images/kitchen/item.png")}
                />
                <Text
                  style={styles.itemRowLeftLbl}
                  numberOfLines={1} // Limits to 1 line, truncating if overflow occurs
                  ellipsizeMode="tail"
                >
                  {runningRecipeContext[selectedRunningRecipeIndex]?.title}
                </Text>
              </View>
              <View style={styles.itemRowRight}>
                <Text style={styles.itemRowRight_lbl}>Go to recipe {">"}</Text>
              </View>
            </View>
          </Pressable>
        )}
    </View>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFF6E5",
  },
  absoluteBottomView: {
    position: "absolute",
    bottom: 70,
    left: 0,
    right: 0,
    // alignItems: "center", // Center the content horizontally
    // justifyContent: "center", // Center the content vertically
    backgroundColor: "rgba(255, 255, 255, 1)", // Optional background
    padding: 10, // Optional padding
    borderRadius: 10, // Optional rounded corners
    marginHorizontal: 15,
    zIndex: 1,
    borderWidth: 1.5,
    borderColor: "#F8A600",
  },
  itemRow: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  itemRowLeft: {
    flexDirection: "row",
    alignItems: "center",
    maxWidth: "65%",
  },
  title: {
    fontFamily: "InriaSerif_700Bold",
    color: "#000",
    fontSize: 17,
    lineHeight: 21,
    marginBottom: 4,
    // textAlign: "center",
  },
  itemRowRight_lbl: {
    color: "#F8A600",
  },
  TopBAr: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  Navigation: {
    flexDirection: "row",
    alignItems: "center",
  },
  NavigationArrow: {
    maxHeight: 22,
    maxWidth: 22,
  },

  NavigationText: {
    marginHorizontal: 14,
    fontFamily: "InriaSerif_700Bold",
    color: "#000",
    fontSize: 16,
    lineHeight: 21,
  },
});
