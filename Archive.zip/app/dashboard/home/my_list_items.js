import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  ToastAndroid,
  Pressable,
  TextInput,
  Modal,
  ActivityIndicator,
  Alert,
  FlatList,
} from "react-native";
import React, { useState, useEffect } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { getData, postData, getAIGeneratedList } from "../../../services/apiService";

import { useFocusEffect } from "expo-router";
import { useCallback } from "react";
import { useAppContext } from "@/components/AppContext";

import RNPickerSelect from "react-native-picker-select";
import { FontAwesome } from "@expo/vector-icons";

export default function kitchen() {
  const router = useRouter();
  const [showEditModal, setShowEditModal] = useState(null);

  const [loading, setLoading] = useState(false);
  const [isLoadingupdate, setIsLoadingupdate] = useState(false);

  const [listofItems, setListofItems] = useState([]);
  const [aiGeneratedItems, setAiGeneratedItems] = useState([]);
  const { activeKitchenId } = useAppContext();
  const [quantities, setQuantities] = useState({});
  const [modifiedRows, setModifiedRows] = useState({});

  const [searchQuery, setSearchQuery] = useState("");
  const [showAddItemModal, setAddItemModal] = useState(false);
  const [prefilledItemName, setPrefilledItemName] = useState("");
  const [showInventoryConfirm, setShowInventoryConfirm] = useState(false);
  const [showInventorySuccess, setShowInventorySuccess] = useState(false);
  const [inventoryLoading, setInventoryLoading] = useState(false);

  const listTheItemsKitchens = async (KID) => {
    setLoading(true);
    try {
      if (activeKitchenId?.role == "member") {
        const response = await getData(
          "/api/kitchen/get_user_requested_items?kitchen_id=" + KID
        );
        if (response?.error) {
        } else {
          setListofItems(response.user_items);
        }
      } else {
        const response = await getData(
          "/api/kitchen/get_all_mylist_items?kitchen_id=" + KID
        );
        if (response?.error) {
        } else {
          setListofItems(response.items);
        }
      }
    } catch (error) {
      console.error("Error posting data:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchAIGeneratedList = async () => {
    try {
      const response = await getAIGeneratedList(activeKitchenId?.kitchen_id);
      if (response?.error) {
        console.error("Error fetching AI generated list:", response.error);
      } else {
        setAiGeneratedItems(response.missing_items || []);
      }
    } catch (error) {
      console.error("Error fetching AI generated list:", error);
    }
  };

  useFocusEffect(
    useCallback(() => {
      if (activeKitchenId != null) {
        listTheItemsKitchens(activeKitchenId.kitchen_id);
        fetchAIGeneratedList();
      }

      return () => {
        console.log("This route is now unfocused.");
      };
    }, [activeKitchenId])
  );

  const delItemToMyList = async (itemid) => {
    const response = await postData("/api/kitchen/delete_items", {
      kitchen_id: activeKitchenId?.kitchen_id,
      item_ids: [itemid],
    });

    if (response?.deleted_count && response?.deleted_count > 0) {
      const updatedItems = listofItems.filter(
        (item) => item.item_id !== itemid
      );
      setListofItems(updatedItems);
      ToastAndroid.show("Item Deleted!", ToastAndroid.SHORT);
    } else {
      ToastAndroid.show("Something Went Wrong!", ToastAndroid.SHORT);
    }
  };
  const handleIncrement = (itemid) => {
    Alert.alert(
      "Confirm Delete item", // Title
      "Are you sure you want to proceed?", // Message
      [
        {
          text: "Cancel",
          onPress: () => console.log("Cancel Pressed"),
          style: "cancel",
        },
        {
          text: "Yes",
          onPress: () => delItemToMyList(itemid),
        },
      ],
      { cancelable: false } // Prevent closing by tapping outside
    );
  };

  const moveItemToMyList = async (itemid) => {
    const response = await postData("/api/kitchen/update_bucket_type", {
      kitchen_id: activeKitchenId?.kitchen_id,
      item_ids: [itemid],
      bucket_type: "mylist",
    });

    if (response?.modified_count && response?.modified_count > 0) {
      const updatedItems = listofItems.map((item) =>
        item.item_id === itemid ? { ...item, bucket_type: "mylist" } : item
      );
      setListofItems(updatedItems);
      ToastAndroid.show("Item Updated!", ToastAndroid.SHORT);
    } else {
      ToastAndroid.show("Something Went Wrong!", ToastAndroid.SHORT);
    }
  };
  const handleDecrement = (itemid) => {
    Alert.alert(
      "Confirm Item to Buy List", // Title
      "Are you sure you want to proceed?", // Message
      [
        {
          text: "Cancel",
          onPress: () => console.log("Cancel Pressed"),
          style: "cancel",
        },
        {
          text: "Yes",
          onPress: () => moveItemToMyList(itemid),
        },
      ],
      { cancelable: false } // Prevent closing by tapping outside
    );
  };

  const openAddItemModalWithPrefill = (itemName) => {
    setPrefilledItemName(itemName);
    setAddItemModal(true);
  };

  // const handleSaveAll = async () => {
  //   setIsLoadingupdate(true);
  //   const modifiedItems = Object.keys(modifiedRows).map((itemName) => ({
  //     name: itemName,
  //     unit: modifiedRows[itemName]?.unit,
  //     quantity: quantities[itemName],
  //     group: modifiedRows[itemName]?.group,
  //   }));

  //   if (modifiedItems.length > 0) {
  //     console.log(modifiedItems);
  //     try {
  //       const response = await postData("/api/kitchen/update_items", {
  //         kitchen_id: activeKitchenId.kitchen_id,
  //         items: modifiedItems, // Send all modified items
  //       });
  //       ToastAndroid.show("All changes saved!", ToastAndroid.SHORT);
  //       setModifiedRows({}); // Clear modified rows
  //     } catch (error) {
  //       console.error("Error saving data:", error);
  //       ToastAndroid.show("Error saving changes.", ToastAndroid.SHORT);
  //     } finally {
  //       setIsLoadingupdate(false);
  //     }
  //   } else {
  //     ToastAndroid.show("No changes to save.", ToastAndroid.SHORT);
  //   }
  // };
  const filteredAndGroupedItems = listofItems.reduce((acc, item) => {
    if (item.name.toLowerCase().includes(searchQuery.toLowerCase())) {
      if (!acc[item.bucket_type]) {
        acc[item.bucket_type] = [];
      }
      acc[item.bucket_type].push(item);
    }
    return acc;
  }, {});
  return (
    <SafeAreaView style={styles.container}>
      <TouchableOpacity
        onPress={() => router.push("/dashboard/home")}
        style={styles.backBtnCon}
      >
        <Image
          source={require("r../../../assets/images/back.png")}
          style={styles.backBtnIcon}
        />
      </TouchableOpacity>
      <View
        style={{ flex: 1 }}
      // showsVerticalScrollIndicator={false}
      // showsHorizontalScrollIndicator={false}
      >
        <View style={styles.kitchenCon}>
          {/* <Text style={styles.kitchenTitle}>Requested Ingredients</Text> */}
          <Text style={styles.kitchenTitle}>My Lists</Text>
          {/* <View style={styles.searchContainer}>
            <TextInput
              style={styles.searchInput}
              placeholder="Search Ingredients..."
              value={searchQuery}
              onChangeText={setSearchQuery} // Update search query
            />
            <Pressable
              onPress={() => setSearchQuery("")} // Clear search input
              style={styles.clearBtn}
            >
              <Text style={styles.controlText}>Clear</Text>
            </Pressable>
          </View> */}
          <ScrollView
            style={styles.scrollcontainer}
            showsVerticalScrollIndicator={false}
            showsHorizontalScrollIndicator={false}
          >
            {loading ? (
              <Text>Loading...</Text>
            ) : listofItems.length === 0 ? (
              <Text>No Ingredients Found.</Text>
            ) : (
              <>
                <View style={styles.requestedListBox}>
                  <Text style={styles.groupTitle}>Requested Items</Text>
                  {(filteredAndGroupedItems["requested"] == undefined ||
                    filteredAndGroupedItems["requested"].length == 0) && (
                      <Text>No Ingredients Found.</Text>
                    )}
                  {filteredAndGroupedItems["requested"] &&
                    filteredAndGroupedItems["requested"].map((kit, index) => (
                      <View style={styles.kitchenRowTouch} key={kit.name}>
                        <View style={styles.row}>
                          <Image
                            source={require("../../../assets/images/kitchen/item.png")}
                            style={styles.kitchenIcon}
                          />
                          <Text style={styles.kitchenLbl}>{kit.name}</Text>
                          <Text style={styles.kitchenLblUnit}>
                            {"( "} {kit.quantity} {kit.unit} {" )"}
                          </Text>
                        </View>
                        {/* <View style={styles.btnCon}>
                        {activeKitchenId?.role != "member" && (
                          <TouchableOpacity
                            style={styles.button}
                            onPress={() => setShowEditModal(kit)}
                          >
                            <Text style={styles.buttonText}>Edit</Text>
                          </TouchableOpacity>
                        )}
                      </View> */}
                        {activeKitchenId?.role != "member" && (
                          <View style={styles.controls}>
                            <Pressable
                              onPress={() => handleDecrement(kit.item_id)}
                              style={styles.controlBtn}
                            >
                              <Image
                                source={require("../../../assets/images/add.png")}
                                style={styles.userIcon}
                              />
                            </Pressable>

                            <Pressable
                              onPress={() => handleIncrement(kit.item_id)}
                              style={styles.controlBtn}
                            >
                              <Image
                                source={require("../../../assets/images/delete.png")}
                                style={styles.userIcon}
                              />
                            </Pressable>
                          </View>
                        )}
                      </View>
                    ))}
                </View>

                {/* AI generated list */}
                {/* {aiGeneratedItems.length > 0 && ( */}
                  <View style={styles.aiGeneratedListBox}>
                    <Text style={styles.groupTitle}>AI Generated List</Text>
                    {(aiGeneratedItems.length == 0) && (
                      <Text>No Ingredients Found.</Text>
                    )}
                    {aiGeneratedItems.map((item, index) => (
                      <View style={styles.kitchenRowTouch} key={`ai-${index}`}>
                        <View style={styles.row}>
                          <Image
                            source={require("../../../assets/images/kitchen/item.png")}
                            style={styles.kitchenIcon}
                          />
                          <Text style={styles.kitchenLbl}>{item}</Text>
                          {/* <Text style={styles.kitchenLblUnit}>
                            {"( "} {item.quantity || 1} {item.unit || "count"} {" )"}
                          </Text> */}
                        </View>
                        <TouchableOpacity
                          onPress={() => openAddItemModalWithPrefill(item)}
                          style={styles.aiAddButton}
                        >
                          <FontAwesome name="plus" size={16} color="#fc8c03" />
                        </TouchableOpacity>
                      </View>
                    ))}
                  </View>
                {/* )} */}

                <View style={styles.buyListBox}>
                  <TouchableOpacity style={styles.addItemBtn} onPress={() => setAddItemModal(true)}>
                    <FontAwesome name="plus" size={12} color="#fc8c03" style={{ marginRight: 5 }} />
                    <Text style={styles.addItemBtnText}>Add Item</Text>
                  </TouchableOpacity>
                  <Text style={styles.groupTitle}>Final List</Text>
                  {(filteredAndGroupedItems["mylist"] == undefined ||
                    filteredAndGroupedItems["mylist"].length == 0) && (
                      <Text>No Ingredients Found.</Text>
                    )}
                  {filteredAndGroupedItems["mylist"] &&
                    filteredAndGroupedItems["mylist"].map((kit, index) => (
                      <View style={styles.kitchenRowTouch} key={kit.name}>
                        <View style={styles.row}>
                          <Image
                            source={require("../../../assets/images/kitchen/item.png")}
                            style={styles.kitchenIcon}
                          />
                          <Text style={styles.kitchenLbl}>{kit.name}</Text>
                          <Text style={styles.kitchenLblUnit}>
                            {"( "} {kit.quantity} {kit.unit} {" )"}
                          </Text>
                        </View>
                        {/* <View style={styles.btnCon}>
                          {activeKitchenId?.role != "member" && (
                            <TouchableOpacity
                              style={styles.button}
                              onPress={() => setShowEditModal(kit)}
                            >
                              <Text style={styles.buttonText}>Edit</Text>
                            </TouchableOpacity>
                          )}
                        </View> */}
                      </View>
                    ))}
                </View>
                {/* Add Inventory button below Buy List */}
                <View style={styles.addInventoryBox}>
                  <TouchableOpacity
                    style={[
                      styles.addInventoryBtn,
                      (!filteredAndGroupedItems["mylist"] || filteredAndGroupedItems["mylist"].length === 0) && styles.addInventoryBtnDisabled
                    ]}
                    onPress={() => setShowInventoryConfirm(true)}
                    disabled={!filteredAndGroupedItems["mylist"] || filteredAndGroupedItems["mylist"].length === 0}
                  >
                    <FontAwesome name="plus" size={12} color="#fc8c03" />
                    <Text style={styles.addInventoryBtnText}>Add to inventory</Text>
                  </TouchableOpacity>
                </View>
              </>
              // Object.keys(filteredAndGroupedItems).map((group) => (
              // <View >
              //   <Text style={styles.groupTitle}>{group}</Text>
              //   {listofItems.map((kit, index) => (
              //     <View style={styles.kitchenRowTouch} key={kit.name}>
              //       <View style={styles.row}>
              //         <Image
              //           source={require("../../../assets/images/kitchen/item.png")}
              //           style={styles.kitchenIcon}
              //         />
              //         <Text style={styles.kitchenLbl}>{kit.name}</Text>
              //         <Text style={styles.kitchenLblUnit}>
              //           {"( "} {kit.quantity} {kit.unit} {" )"}
              //         </Text>
              //       </View>
              //       <View style={styles.btnCon}>
              //         {activeKitchenId?.role != "member" && (
              //           <TouchableOpacity
              //             style={styles.button}
              //             onPress={() => setShowEditModal(kit)}
              //           >
              //             <Text style={styles.buttonText}>Edit</Text>
              //           </TouchableOpacity>
              //         )}
              //       </View>
              //       {/* <View style={styles.controls}>
              //         <Pressable
              //           onPress={() =>
              //             handleDecrement(kit.name, kit.unit, kit.group)
              //           }
              //           style={styles.controlBtn}
              //         >
              //           <Text style={styles.controlText}>-</Text>
              //         </Pressable>
              //         <TextInput
              //           keyboardType="numeric"
              //           value={quantities[kit.name]?.toString()}
              //           editable={false}
              //           style={styles.quantityInput}
              //         />
              //         <Pressable
              //           onPress={() =>
              //             handleIncrement(kit.name, kit.unit, kit.group)
              //           }
              //           style={styles.controlBtn}
              //         >
              //           <Text style={styles.controlText}>+</Text>
              //         </Pressable>
              //       </View> */}
              //     </View>
              //   ))}
              // </View>
              // ))
            )}
          </ScrollView>
          {/* <View style={styles.btnCon}>
            <TouchableOpacity
              style={styles.button}
              onPress={handleSaveAll}
              disabled={isLoadingupdate}
            >
              <Text style={styles.buttonText}>
                {isLoadingupdate ? "Updating" : "Update"}{" "}
              </Text>
            </TouchableOpacity>
          </View> */}
        </View>
      </View>
      <UpdateItemModal
        isVisible={showEditModal != null}
        onClose={(e) => {
          setShowEditModal(null);
          if (e == true) listTheItemsKitchens(activeKitchenId?.kitchen_id);
        }}
        kitchenid={activeKitchenId?.kitchen_id}
        item={showEditModal}
      />
      <AddItemModal
        isVisible={showAddItemModal}
        onClose={(e) => { 
          setAddItemModal(false);
          setPrefilledItemName("");
        }}
        kitchenid={activeKitchenId?.kitchen_id}
        onItemAdded={() => {
          listTheItemsKitchens(activeKitchenId?.kitchen_id);
          fetchAIGeneratedList();
        }}
        prefilledName={prefilledItemName}
      />
      {/* Inventory Confirmation Modal */}
      <Modal
        animationType="fade"
        transparent={true}
        visible={showInventoryConfirm}
        onRequestClose={() => setShowInventoryConfirm(false)}
      >
        <View style={modal_style.modalOverlay}>
          <View style={modal_style.modalContainer}>
            <Text style={modal_style.modalTitle}>Add to Inventory</Text>
            <Text style={{ textAlign: 'center', marginBottom: 20 }}>
              Do you want to add all items from your Buy List to the inventory?
            </Text>
            <View style={modal_style.buttonContainer}>
              <TouchableOpacity
                style={modal_style.submitButton}
                onPress={async () => {
                  setInventoryLoading(true);
                  try {
                    const resp = await postData("/api/kitchen/add_mylist_items_to_kitchen_inventory", {
                      kitchen_id: activeKitchenId?.kitchen_id
                    });
                    setShowInventoryConfirm(false);
                    setInventoryLoading(false);
                    setShowInventorySuccess(true);
                    // Optionally refresh list
                    listTheItemsKitchens(activeKitchenId?.kitchen_id);
                  } catch (e) {
                    setInventoryLoading(false);
                    setShowInventoryConfirm(false);
                    Alert.alert("Error", "Failed to add items to inventory.");
                  }
                }}
                disabled={inventoryLoading}
              >
                {inventoryLoading ? (
                  <ActivityIndicator size="small" color="#fff" />
                ) : (
                  <Text style={modal_style.submitButtonText}>Yes, Add</Text>
                )}
              </TouchableOpacity>
              <TouchableOpacity
                style={modal_style.closeButton}
                onPress={() => setShowInventoryConfirm(false)}
                disabled={inventoryLoading}
              >
                <Text style={modal_style.submitButtonText}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
      {/* Inventory Success Modal */}
      <Modal
        animationType="fade"
        transparent={true}
        visible={showInventorySuccess}
        onRequestClose={() => setShowInventorySuccess(false)}
      >
        <View style={modal_style.modalOverlay}>
          <View style={modal_style.modalContainer}>
            <Text style={modal_style.modalTitle}>Success!</Text>
            <Text style={{ textAlign: 'center', marginBottom: 20 }}>
              Items successfully added to inventory!
            </Text>
            <TouchableOpacity
              style={modal_style.submitButton}
              onPress={() => setShowInventorySuccess(false)}
            >
              <Text style={modal_style.submitButtonText}>OK</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    //   justifyContent: "center",
    //   alignItems: "center",
    paddingHorizontal: 28,
    paddingVertical: 13,
    backgroundColor: "#FFF6E5",
  },
  scrollcontainer: {
    flex: 1,
    minHeight: 100,
  },
  backBtnCon: {
    width: 38,
    height: 38,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#fff",
    borderRadius: 10,
  },
  kitchenCon: {
    marginTop: 12,
    flex: 1,
    paddingBottom: 12,
  },
  kitchenTitle: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 30,
    fontWeight: "400",
    lineHeight: 36,
    textAlign: "left",
    color: "#000",
    marginBottom: 10,
  },
  requestedListBox: {
    borderWidth: 1,
    borderColor: "#000",
    borderRadius: 10,
    padding: 10,
    marginBottom: 10,
  },
  buyListBox: {
    position: 'relative',
    borderWidth: 1,
    borderColor: "#000",
    borderRadius: 10,
    padding: 10,
    marginBottom: 10,
  },
  aiGeneratedListBox: {
    position: 'relative',
    borderWidth: 1,
    borderColor: "#000",
    borderRadius: 10,
    padding: 10,
    marginBottom: 10,
  },
  addItemBtn: {
    position: 'absolute',
    top: 15,
    right: 5,
    padding: 5,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 8,
    flexDirection: 'row',
    zIndex: 10,
  },
  addItemBtnText: {
    fontSize: 12,
    fontWeight: "bold",
    color: "#fc8c03",
    
  },

  groupTitle: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 18,
    fontWeight: "500",
    lineHeight: 18,
    textAlign: "left",
    color: "#000",
    // marginVertical: 8,
    marginTop: 10,
    marginBottom: 10,
  },
  kitchenLst: {
    flex: 1,
  },
  kitchenRowTouch: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 8,
    justifyContent: "space-between",

  },
  addInventoryBox: {
    marginTop: 0,
    alignItems: "flex-end",
    // backgroundColor: "transparent",
  },
  addInventoryBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    // backgroundColor: "#fc8c03",
    paddingVertical: 8,
    paddingHorizontal: 18,
    borderRadius: 20,
    // elevation: 2,
    borderWidth: 1,
    borderColor: "#fc8c03",
  },
  addInventoryBtnDisabled: {
    opacity: 0.5,
  },
  addInventoryBtnText: {
    fontWeight: "bold",
    marginLeft: 8,
    color: "#fc8c03",
    fontSize: 14,
  },
  aiAddButton: {
    alignItems: "center",
    justifyContent: "center",
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: "#fc8c03",
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    // marginTop: 8,
  },
  controls: {
    flexDirection: "row",
    alignItems: "center",
  },
  userIcon: {
    width: 28,
    height: 28,
  },
  controlBtn: {
    alignItems: "center",
    justifyContent: "center",
    // width: 14,
    // height: 14,
    // backgroundColor: "#000",
    borderWidth: 0,
    borderRadius: 2,
  },
  controlText: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 12,
    fontWeight: "400",
    lineHeight: 12,
    textAlign: "center",
    color: "#fff",
    // marginBottom: 10,
  },
  quantityInput: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 12,
    fontWeight: "400",
    lineHeight: 12,
    textAlign: "center",
    color: "#000",
  },
  kitchenIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 10,
  },
  kitchenLbl: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 14,
    fontWeight: "400",
    lineHeight: 14,
    textAlign: "left",
    color: "#000",
  },
  kitchenLblUnit: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 13,
    fontWeight: "400",
    lineHeight: 13,
    textAlign: "left",
    color: "#6c757d",
    marginLeft: 4,
  },
  btnCon: {
    justifyContent: "center",
    flexDirection: "row",
    marginTop: 10,
  },
  button: {
    width: 55,
    height: 35,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 8,
    backgroundColor: "#F8A600",
  },
  buttonText: {
    fontSize: 13,
  },

  searchContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 15,
  },
  searchInput: {
    flex: 1,
    height: 40,
    borderColor: "#ddd",
    borderWidth: 1,
    borderRadius: 5,
    paddingLeft: 10,
    fontSize: 14,
    marginRight: 10,
  },
  clearBtn: {
    backgroundColor: "#F8A600",
    padding: 8,
    borderRadius: 5,
  },
});

function UpdateItemModal({ isVisible, onClose, kitchenid, item }) {
  const [value, setValue] = useState(0);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async () => {
    if (value == null || value == "" || isNaN(value)) {
      Alert.alert("Missing Fields", "Please fill out Value correctly");
      return;
    }
    try {
      setIsLoading(true);
      const modifiedItems = {
        name: item.name,
        unit: item?.unit,
        quantity: Number((Number(item.quantity) - Number(value)).toFixed(3)),
        group: item?.group,
      };
      console.log(modifiedItems);
      const response = await postData("/api/kitchen/update_items", {
        kitchen_id: kitchenid,
        items: [modifiedItems], // Send all modified items
      });
      console.log(response);
      if (response?.error) {
        throw new Error("Error");
      }

      ToastAndroid.show("Item Updated successfully!", ToastAndroid.SHORT); // Show success toast
    } catch (error) {
      alert("Failed to submit item. Please try again.");
      console.error(error);
    } finally {
      setIsLoading(false); // Hide loader
      onClose(true);
    }
  };
  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={isVisible}
      onRequestClose={() => onClose(false)}
    >
      <View style={modal_style.modalOverlay}>
        <View style={modal_style.modalContainer}>
          <View style={modal_style.titleRow}>
            <Text style={modal_style.modalTitle}>{item?.name}</Text>
            <Text style={modal_style.modalTitleUnit}>
              ~{item?.quantity} {item?.unit}
            </Text>
          </View>
          {/* <View style={modal_style.qtyRow}>
            <Text style={modal_style.qtyText}>Current Quantity:</Text>
            <Text style={modal_style.qtyTextVale}>{item?.quantity}</Text>
          </View> */}
          <Text style={modal_style.addButtonText}>
            Quantity {"( To Remove ):"}
          </Text>
          <TextInput
            style={modal_style.input}
            placeholder="0"
            value={value}
            keyboardType="numeric"
            disabled={isLoading}
            onChangeText={(text) => {
              if (!isNaN(text) && Number(text) <= Number(item?.quantity ?? 0))
                setValue(text);
            }}
          />

          <View style={modal_style.buttonContainer}>
            <TouchableOpacity
              style={modal_style.submitButton}
              onPress={handleSubmit}
            >
              {isLoading ? (
                <ActivityIndicator size="small" color="#0000ff" />
              ) : (
                <Text style={modal_style.submitButtonText}>Remove</Text>
              )}
            </TouchableOpacity>
            <TouchableOpacity
              style={modal_style.closeButton}
              onPress={() => onClose(false)}
              disabled={isLoading}
            >
              <Text style={modal_style.submitButtonText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const modal_style = StyleSheet.create({
  buttonText: {
    color: "#fff",
    fontSize: 16,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  modalContainer: {
    backgroundColor: "#fff",
    width: "85%",
    borderRadius: 10,
    paddingHorizontal: 15,
    paddingVertical: 15,
    elevation: 10,
    maxHeight: "60%",
  },
  titleRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: "bold",
    textAlign: "center",
  },
  modalTitleUnit: {
    fontSize: 16,
    textAlign: "center",
    color: "#9e9e9e",
    marginLeft: 4,
  },
  buttonContainer: {
    flexDirection: "row",
    justifyContent: "center",
    gap: 8,
    marginTop: 10,
  },
  list: {
    flexGrow: 0,
  },
  qtyRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
    paddingHorizontal: 0,
  },
  qtyText: {
    fontSize: 16,
    color: "#545454",
  },
  qtyTextVale: {
    fontSize: 16,
    color: "#000",
    marginLeft: 5,
  },
  index: {
    width: 25,
    textAlign: "center",
    fontSize: 14,
    fontWeight: "bold",
  },
  input: {
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 5,
    paddingVertical: 0,
    paddingHorizontal: 5,
    marginHorizontal: 2,
    height: 35,
  },
  addButton: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 15,
    justifyContent: "center",
  },
  addButtonText: {
    // marginLeft: 10,
    fontSize: 14,
    color: "#007bff",
    marginBottom: 5,
  },
  submitButton: {
    backgroundColor: "#007bff",
    paddingVertical: 8,
    paddingHorizontal: 20,
    borderRadius: 10,
    alignItems: "center",
  },
  closeButton: {
    backgroundColor: "#d33942",
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 10,
    alignItems: "center",
  },
  submitButtonText: {
    color: "#fff",
    fontSize: 16,
  },
});

function AddItemModal({ isVisible, onClose, kitchenid, onItemAdded, prefilledName }) {
  const [items, setItems] = useState([
    { id: Date.now(), name: "", unit: "kg", quantity: "" },
  ]);
  const [isLoading, setIsLoading] = useState(false);

  // Update items when prefilledName changes
  useEffect(() => {
    if (prefilledName) {
      setItems([{ id: Date.now(), name: prefilledName, unit: "kg", quantity: "" }]);
    } else {
      setItems([{ id: Date.now(), name: "", unit: "kg", quantity: "" }]);
    }
  }, [prefilledName]);


  const updateItem = (id, field, value) => {
    setItems((prevItems) =>
      prevItems.map((item) =>
        item.id === id ? { ...item, [field]: value } : item
      )
    );
  };

  const renderRow = ({ item, index }) => (
    <View style={add_item_modal_style.row}>
      {/* <Text style={add_item_modal_style.index}>{index + 1}.</Text> */}
      <TextInput
        style={add_item_modal_style.input}
        placeholder="Item Name"
        value={item.name}
        onChangeText={(text) => updateItem(item.id, "name", text)}
      />
      <TextInput
        style={[add_item_modal_style.input, { maxWidth: 50 }]}
        placeholder="Qty"
        value={item.quantity}
        keyboardType="numeric"
        onChangeText={(text) => updateItem(item.id, "quantity", text)}
      />

      <View style={{ width: 75, marginRight: 5 }}>
        <RNPickerSelect
          onValueChange={(text) => updateItem(item.id, "unit", text)}
          items={[
            { label: "KG", value: "kg" },
            { label: "Litre", value: "litre" },
            { label: "Count", value: "count" },

            { label: "Milliliters", value: "milliliters" },
            { label: "Grams", value: "grams" },
            { label: "Pounds", value: "pounds" },
            { label: "Ounces", value: "ounces" },
          ]}
          value={item.unit}
          useNativeAndroidPickerStyle={false}
          style={{
            inputAndroid: {
              fontSize: 12,
              paddingHorizontal: 10,
              paddingVertical: 5,
              borderWidth: 1,
              borderColor: "#ccc",
              borderRadius: 5,
              color: "#333",
              paddingRight: 0, // to ensure the text is not overlapping the dropdown arrow
            },
            placeholder: {
              color: "#888",
              fontSize: 12,
            },
            iconContainer: {
              top: 15,
              right: 8,
            },
          }}
          Icon={() => {
            return <FontAwesome name="chevron-down" size={12} color="#888" />;
          }}
        />
      </View>
    </View>
  );

  const handleSubmit = async () => {
    const hasEmptyFields = items.some(
      (item) =>
        !item.name?.trim() ||
        !item.unit?.trim() ||
        !item.quantity ||
        isNaN(item.quantity)
    );

    if (hasEmptyFields) {
      Alert.alert(
        "Missing Fields",
        "Please fill out all fields before submitting."
      );
      return;
    }
    try {
      setIsLoading(true);
      const formattedData = JSON.stringify({
        kitchen_id: kitchenid,
        name: items[0].name,
        quantity: parseInt(items[0].quantity, 10) || 0,
        unit: items[0].unit || "",
        bucket_type: "mylist",
      });

      const resp = await postData("/api/kitchen/add_item_to_list", formattedData);
      if (resp.message) {
        ToastAndroid.show("Item Added successfully!", ToastAndroid.SHORT); // Show success toast
        setItems([{ id: Date.now(), name: "", unit: "", quantity: "kg" }]);
        onItemAdded();
        setIsLoading(false); // Hide loader
        onClose(true);
      } else {
        ToastAndroid.show("Something went wrong..", ToastAndroid.SHORT); // Show success toast
        setIsLoading(false);
      }
    } catch (error) {
      alert("Failed to submit items. Please try again.");
      console.error(error);
    } finally {
    }
  };
  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={isVisible}
      onRequestClose={() => onClose(false)}
    >
      <View style={add_item_modal_style.modalOverlay}>
        <View style={add_item_modal_style.modalContainer}>
          <Text style={add_item_modal_style.modalTitle}>Add to Final List</Text>

          <FlatList
            data={items}
            renderItem={renderRow}
            keyExtractor={(item) => item.id.toString()}
            style={styles.list}
            contentContainerStyle={{ paddingBottom: 5 }} // Add padding for better spacing
            showsVerticalScrollIndicator={true}
          />

          <View style={add_item_modal_style.buttonContainer}>
            {isLoading ? (
              <ActivityIndicator size="small" color="#0000ff" />
            ) : (
              <>
                <TouchableOpacity
                  style={add_item_modal_style.submitButton}
                  onPress={handleSubmit}
                >
                  <Text style={add_item_modal_style.submitButtonText}>Submit</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={add_item_modal_style.closeButton}
                  onPress={() => onClose(false)}
                >
                  <Text style={modal_style.submitButtonText}>Close</Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        </View>
      </View>
    </Modal>
  );
}

const add_item_modal_style = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  modalContainer: {
    backgroundColor: "#fff",
    width: "95%",
    borderRadius: 10,
    paddingHorizontal: 6,
    paddingVertical: 10,
    elevation: 10,
    maxHeight: "60%",
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 20,
    textAlign: "center",
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 5,
    paddingHorizontal: 0,
  },
  input: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 5,
    padding: 5,
    marginHorizontal: 2,
  },
  addButton: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 15,
    justifyContent: "center",
  },
  addButtonText: {
    // marginLeft: 10,
    fontSize: 16,
    color: "#007bff",
  },
  buttonContainer: {
    flexDirection: "row",
    justifyContent: "center",
    gap: 8,
  },
  submitButton: {
    backgroundColor: "#007bff",
    paddingVertical: 8,
    paddingHorizontal: 20,
    borderRadius: 10,
    alignItems: "center",
  },
  submitButtonText: {
    color: "#fff",
    fontSize: 16,
  },
  closeButton: {
    backgroundColor: "#d33942",
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 10,
    alignItems: "center",
  },
});
