import {
  View,
  TextInput,
  Button,
  StyleSheet,
  Text,
  TouchableOpacity,
  Image,
  ScrollView,
  ActivityIndicator,
  Pressable,
  ToastAndroid,
} from "react-native";
import React, { useState, useEffect } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import { useNavigation, useRouter, Link } from "expo-router";
import { getData, postData } from "../../../../services/apiService";
import { useFocusEffect } from "expo-router";
import { useCallback } from "react";
import { useAppContext } from "@/components/AppContext";

export default function craete_kitchen() {
  const { activeKitchenId, setActiveKitchenId } = useAppContext();

  const [loadingGenerated, setLoadingGenerated] = useState(false);
  const [text, setText] = useState("");
  const router = useRouter();

  const fetchGeneratedRecipe = async () => {
    setLoadingGenerated(true);

    try {
      const response = await postData("/api/kitchen/create", {
        kitchen_name: text,
      });
      // console.log("Response from API:", response);
      if (response?.error) {
        ToastAndroid.show("Failed to Create Kitchen", ToastAndroid.SHORT);
      } else {
        setLoadingGenerated(false);
        ToastAndroid.show("Kitchen Created!", ToastAndroid.SHORT);
        handlePress({
          kitchen_id: response.kitchen_id,
          invitation_code: response.invitation_code,
          kitchen_name: text,
          role: "host",
        });
        setText("");
      }
    } catch (error) {
      console.error("Error posting data:", error);
      ToastAndroid.show("Failed to Create Kitchen", ToastAndroid.SHORT);
      setLoadingGenerated(false);
    }
  };
  const onToggle = () => {
    router.push("/dashboard/home/kitchen/kitchen_lst");
  };
  const handlePress = (data) => {
    setActiveKitchenId(data);
    router.push({
      pathname: "/dashboard/home",
    });
  };
  return (
    <SafeAreaView style={styles.container}>
      <TouchableOpacity onPress={onToggle} style={styles.backBtnCon}>
        <Image
          source={require("../../../../assets/images/backBtn.png")}
          style={styles.backBtnIcon}
        />
      </TouchableOpacity>
      <Text style={styles.maintitle}>Create a Kitchen</Text>
      <View style={styles.formCom}>
        <View style={styles.form}>
          <Text style={styles.inputtitle}>Kitchen Name</Text>

          <TextInput
            style={styles.input}
            placeholder="Name ...."
            value={text}
            onChangeText={setText}
            placeholderTextColor="#888"
            maxLength={40}
          />
          <Text style={styles.charCount}>{text.length}/40</Text>
          <View style={styles.btnCon}>
            <TouchableOpacity
              style={styles.button}
              onPress={fetchGeneratedRecipe}
            >
              {loadingGenerated ? (
                <ActivityIndicator size="small" color="#ffffff" />
              ) : (
                <Text style={styles.buttonText}>Create</Text>
              )}
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,

    paddingHorizontal: 26,
    paddingVertical: 13,
    backgroundColor: "#FFF6E5",
  },
  form: {
    width: "90%",
  },
  input: {
    height: 48,
    borderWidth: 0,
    borderRadius: 10, // Rounded corners
    paddingHorizontal: 15,
    backgroundColor: "#F5F5F5", // Light background
    fontSize: 14,
    color: "#111719", // Darker text color
  },
  backBtnCon: {
    width: 38,
    height: 38,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#fff",
    borderRadius: 10,
    // marginBottom: 20,
  },
  maintitle: {
    fontFamily: "InriaSerif_700Bold",
    color: "#000",
    fontSize: 30,
    lineHeight: 36,
    // marginBottom: 20,
    marginTop: 20,
  },
  formCom: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "column",
    marginTop: -100,
  },
  inputtitle: {
    fontFamily: "InriaSerif_700Bold",
    color: "#000",
    fontSize: 14,
    lineHeight: 16,
    marginTop: 20,
    marginBottom: 5,
  },
  charCount: {
    fontFamily: "InriaSerif_400Regular",
    color: "#000",
    textAlign: "right",
    fontSize: 10,
    lineHeight: 11,
    marginTop: 5,
    marginBottom: 10,
  },
  scrollcontainer: {
    flex: 1,
    // paddingBottom:250
  },
  btnCon: {
    width: "100%",
    justifyContent: "center",
    alignItems: "center",
  },
  button: {
    width: 248,
    height: 48,
    borderRadius: 28.5,
    backgroundColor: "#000000",
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#E6C068",
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 1,
    shadowRadius: 20,
    elevation: 5,
  },
  buttonText: {
    color: "#F8A600",
    fontFamily: "InriaSerif_400Regular",
    fontSize: 14,
    lineHeight: 16.79,
    letterSpacing: 0.08,
    textAlign: "center",
  },
  warning: {
    fontFamily: "InriaSerif_400Regular",
    color: "#000",
    textAlign: "center",
    fontSize: 14,
    lineHeight: 16,
  },
});
