import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Pressable,
  ToastAndroid,
  Modal,
  TextInput,
  ActivityIndicator,
  Alert,
} from "react-native";
import { useAppContext } from "@/components/AppContext";

import React, { useState, useEffect } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { getData, postData } from "../../../../services/apiService";
import { useFocusEffect } from "expo-router";
import { useCallback } from "react";
export default function kitchen() {
  const router = useRouter();
  const { activeKitchenId, loggedInUser, setActiveKitchenId } = useAppContext();
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [isModalVisibleInviteCode, setIsModalVisibleInviteCode] =
    useState(false);

  const [loading, setLoading] = useState(false);

  const [loading_leave, setLoading_leave] = useState(false);
  const [loading_delete, setLoading_delete] = useState(false);
  const [loading_invite, setLoading_invite] = useState(false);

  const [membersLst, setMembersLst] = useState([]);
  const [currentMem, setCurrentMem] = useState(null);

  const fetchSavedRecipe = async (offLoading = true) => {
    console.log("===Feteciing Memebers===");

    setLoading(offLoading);

    try {
      const response = await getData(
        `/api/kitchen/get_members?kitchen_id=${activeKitchenId?.kitchen_id}`
      );

      setMembersLst(response.members);
      const matchedMember = response.members.find(
        (member) => member.user_id === loggedInUser.user_id
      );

      setCurrentMem(matchedMember || null);
    } catch (error) {
      console.error("Error posting data:", error);
      // ToastAndroid.show("Failed to fetch Members", ToastAndroid.SHORT);
    } finally {
      setLoading(false);
    }
  };
  useFocusEffect(
    useCallback(() => {
      if (activeKitchenId != null) fetchSavedRecipe();

      return;
    }, [activeKitchenId])
  );
  const makeMemberCoHost = async (memberid) => {
    try {
      const response = await postData("/api/kitchen/make_cohost", {
        kitchen_id: activeKitchenId?.kitchen_id,
        member_id: memberid,
      });

      ToastAndroid.show("Status Updated!", ToastAndroid.SHORT);
      return true;
    } catch (error) {
      ToastAndroid.show("Something Went Wrong!", ToastAndroid.SHORT);
      return false;
    }
  };
  const kickMember = async (memberid) => {
    try {
      const response = await postData("/api/kitchen/kick_member", {
        kitchen_id: activeKitchenId?.kitchen_id,
        member_id: memberid,
      });

      ToastAndroid.show("Status Updated!", ToastAndroid.SHORT);
      return true;
    } catch (error) {
      ToastAndroid.show("Something Went Wrong!", ToastAndroid.SHORT);
      return false;
    }
  };
  const leaveMember = async () => {
    try {
      setLoading_leave(true);
      const response = await postData("/api/kitchen/leave", {
        kitchen_id: activeKitchenId?.kitchen_id,
      });
      ToastAndroid.show("Status Updated!", ToastAndroid.SHORT);
      setActiveKitchenId(null);
      router.push("/dashboard/home/kitchen/kitchen_lst", undefined, {
        shallow: true,
      });
    } catch (error) {
      ToastAndroid.show("Something Went Wrong!", ToastAndroid.SHORT);
    } finally {
      setLoading_leave(false);
    }
  };
  const showKitchenDeleetConfirmation = () => {
    Alert.alert(
      "Confirm Kitchen Delete", // Title
      "Are you sure you want to proceed?", // Message
      [
        {
          text: "Cancel",
          onPress: () => console.log("Cancel Pressed"),
          style: "cancel",
        },
        {
          text: "Yes",
          onPress: deleteKitchen,
        },
      ],
      { cancelable: false } // Prevent closing by tapping outside
    );
  };
  const deleteKitchen = async () => {
    try {
      setLoading_delete(true);
      const response = await postData("/api/kitchen/remove", {
        kitchen_id: activeKitchenId?.kitchen_id,
      });
      if (response?.message) {
        ToastAndroid.show("Status Updated!", ToastAndroid.SHORT);
        console.log("===Status Updated===");
        setActiveKitchenId(null);
        router.push("/dashboard/home/kitchen/kitchen_lst", undefined, {
          shallow: true,
        });
      } else {
        ToastAndroid.show("Failed to delete kitchen.", ToastAndroid.SHORT);
      }
    } catch (error) {
      ToastAndroid.show("Something Went Wrong!", ToastAndroid.SHORT);
    } finally {
      setLoading_delete(false);
    }
  };
  const refreshCodeKitchen = async () => {
    try {
      // setLoading_invite(true);

      const { kitchen_id } = activeKitchenId; // Deconstruct for clarity
      const response = await postData("/api/kitchen/refresh_invitation_code", {
        kitchen_id,
      });

      if (response.new_invitation_code) {
        ToastAndroid.show(
          response.message || "Invitation code refreshed successfully!",
          ToastAndroid.SHORT
        );
        setActiveKitchenId((prev) => ({
          ...prev,
          invitation_code: response.new_invitation_code,
        }));
      } else {
        ToastAndroid.show(
          "Unable to refresh invitation code. Please try again.",
          ToastAndroid.SHORT
        );
      }
    } catch (error) {
      console.error("Error refreshing invitation code:", error); // Log for debugging
      ToastAndroid.show(
        "An error occurred while refreshing the code. Please try again later.",
        ToastAndroid.SHORT
      );
    } finally {
      // setLoading_invite(false); // Ensure loading state is updated
    }
  };
  return (
    <SafeAreaView style={styles.container}>
      <TouchableOpacity
        onPress={() => router.push("/dashboard/home")}
        style={styles.backBtnCon}
      >
        <Image
          source={require("../../../../assets/images/back.png")}
          style={styles.backBtnIcon}
        />
      </TouchableOpacity>
      <Text style={styles.kitchenTitle}>Kitchen:</Text>
      <ScrollView
        style={styles.scrollcontainer}
        showsVerticalScrollIndicator={false}
        showsHorizontalScrollIndicator={false}
      >
        <View style={styles.BtnRowCon}>
          {currentMem?.type == "member" ? (
            <Pressable
              style={[styles.button, styles.leaveBtn]}
              onPress={leaveMember}
              disabled={loading_leave}
            >
              {loading_leave ? (
                <ActivityIndicator size="small" color="#ffffff" />
              ) : (
                <Text>Leave Kitchen</Text>
              )}
            </Pressable>
          ) : (
            <View></View>
          )}

          {currentMem?.type == "host" ? (
            <Pressable
              style={[styles.button, styles.deleteBtn]}
              onPress={showKitchenDeleetConfirmation}
              disabled={loading_delete}
            >
              {loading_delete ? (
                <ActivityIndicator size="small" color="#ffffff" />
              ) : (
                <Text>Delete Kitchen</Text>
              )}
            </Pressable>
          ) : (
            <View></View>
          )}
          {currentMem?.type == "host" ? (
            <Pressable
              style={[styles.button, styles.InviteBtn]}
              onPress={() => setIsModalVisibleInviteCode(true)}
            >
              <Text>Invite Code</Text>
            </Pressable>
          ) : (
            <View></View>
          )}
          {/* {currentMem?.type == "host" || currentMem?.type == "co-host" ? (
            <Pressable
              onPress={() => setIsModalVisible(true)}
              style={[styles.button, styles.InviteBtn]}
            >
              <Text>Invite Member</Text>
            </Pressable>
          ) : (
            <View></View>
          )} */}
        </View>
        <View style={styles.kitchenCon}>
          <Text
            style={[
              styles.kitchenTitle,
              { fontSize: 18, marginBottom: 6, lineHeight: 18 },
            ]}
          >
            Members:
          </Text>

          <View style={styles.kitchenLst}>
            {loading && membersLst.length == 0 && <Text>Loading...</Text>}
            {!loading && membersLst.length == 0 && (
              <Text>No Member Found.</Text>
            )}
            {membersLst.map((member, index) => (
              <MemberRow
                member={member}
                onCoHost={makeMemberCoHost}
                onKick={kickMember}
                iam={currentMem?.type}
                refresh={() => fetchSavedRecipe(false)}
              />
            ))}
          </View>
          {/* <View style={styles.btnCon}>
            <TouchableOpacity
              style={styles.button}
              onPress={() =>
                router.push("/dashboard/home/kitchen/join_kitchen")
              }
            >
              <Text style={styles.buttonText}>Join a Kitchen</Text>
            </TouchableOpacity>
          </View> */}
        </View>
      </ScrollView>
      <InviteMemberModal
        isVisible={isModalVisible}
        onClose={(e = false) => {
          if (e == true) fetchSavedRecipe();
          setIsModalVisible(false);
        }}
        kitchenid={activeKitchenId?.kitchen_id}
      />
      <InviteCodeModal
        isVisible={isModalVisibleInviteCode}
        onClose={() => {
          setIsModalVisibleInviteCode(false);
        }}
        invitation_code={activeKitchenId?.invitation_code}
        update={refreshCodeKitchen}
      />
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    //   justifyContent: "center",
    //   alignItems: "center",
    paddingHorizontal: 28,
    paddingVertical: 13,
    backgroundColor: "#FFF6E5",
  },
  scrollcontainer: {
    flex: 1,
  },
  backBtnCon: {
    width: 38,
    height: 38,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#fff",
    borderRadius: 10,
  },
  kitchenCon: {
    marginTop: 8,
  },
  kitchenTitle: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 30,
    fontWeight: "400",
    lineHeight: 36,
    textAlign: "left",
    color: "#000",
    marginBottom: 10,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 8,
  },
  BtnRowCon: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginVertical: 8,
  },
  kitchenIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 10,
  },
  kitchenLbl: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 14,
    fontWeight: "400",
    lineHeight: 14,
    textAlign: "left",
    color: "#000",
  },
  btnCon: {
    justifyContent: "center",
    flexDirection: "row",
    marginTop: 10,
  },
  button: {
    height: 36,
    minWidth: 120,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 8,
    backgroundColor: "#F8A600",
    paddingHorizontal: 4,
  },
  buttonText: {
    fontSize: 12,
    fontWeight: 600,
  },
});

const MemberRow = ({ member, onCoHost, onKick, iam, refresh }) => {
  const [loading, setLoading] = useState(false);
  const [loadingKick, setloadingKick] = useState(false);

  //   let member = {
  //     name: "sohail khan",
  //     type: "host",
  //     user_id: "66df69e3f21e0df5ced9a504",
  //   };
  const cohostMem = async () => {
    try {
      setLoading(true);
      let resp = await onCoHost(member.user_id);
      if (resp == true) await refresh();
    } catch (error) {
    } finally {
      setLoading(false);
    }
  };
  const showkickMemConfirmation = (user_id) => {
    Alert.alert(
      "Confirm Kick Member", // Title
      "Are you sure you want to proceed?", // Message
      [
        {
          text: "Cancel",
          onPress: () => console.log("Cancel Pressed"),
          style: "cancel",
        },
        {
          text: "Yes",
          onPress: ()=>kickMem(user_id),
        },
      ],
      { cancelable: false } // Prevent closing by tapping outside
    );
  };
  const kickMem = async (user_id) => {
    try {
      setloadingKick(true);
      let resp = await onKick(user_id);
      if (resp == true) await refresh();
    } catch (error) {
    } finally {
      setloadingKick(false);
    }
  };
  return (
    <View
      style={{
        flex:1,
        alignItems: "center",
        flexDirection: "row",
        justifyContent: "space-between",
        marginBottom: 8,
      }}
    >
      <View style={{ alignItems: "center", gap: 2, flexDirection: "row" }}>
        <Text style={stylesInvite.name}>{member.name}</Text>
        <Text style={stylesInvite.type}>
          {"("}
          {member.type}
          {")"}{" "}
        </Text>
      </View>

      <View>
        <View style={{ alignItems: "center", gap: 4, flexDirection: "row" }}>
          {iam == "host" && member.type == "member" && (
            <Pressable
              style={stylesInvite.acceptButton}
              onPress={cohostMem}
              disabled={loading || loadingKick}
            >
              {loading ? (
                <ActivityIndicator size="small" color="#ffffff" />
              ) : (
                <Text style={stylesInvite.acceptButtonText}>Make CoHost</Text>
              )}
            </Pressable>
          )}
          {(iam == "host" || iam == "co-host") && member.type != "host" && (
            <Pressable
              style={stylesInvite.deniedButton}
              onPress={()=>showkickMemConfirmation(member.user_id)}
              disabled={loading || loadingKick}
            >
              {loadingKick ? (
                <ActivityIndicator size="small" color="#ff5e5e" />
              ) : (
                <Text style={stylesInvite.deniedButtonText}>Kick</Text>
              )}
            </Pressable>
          )}
        </View>
      </View>
    </View>
  );
};
const stylesInvite = StyleSheet.create({
  acceptButton: {
    backgroundColor: "#F8A600",
    borderRadius: 12,
    paddingVertical: 3,
    paddingHorizontal: 6,
  },
  acceptButtonText: {
    color: "white",
    fontSize: 10,
  },
  deniedButton: {
    borderColor: "#ff5e5e",
    borderWidth: 1,
    borderRadius: 12,
    paddingVertical: 3,
    paddingHorizontal: 6,
  },
  deniedButtonText: {
    color: "#ff5e5e",
    fontSize: 10,
  },
  detailsContainer: {
    marginTop: 8,
  },
});

function InviteMemberModal({ isVisible, onClose, kitchenid }) {
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async () => {
    if (email.trim() === "") {
      Alert.alert(
        "Missing Fields",
        "Please fill out all fields before submitting."
      );
      return;
    }

    try {
      setIsLoading(true);

      await postData("/api/kitchen/invite", {
        kitchen_id: kitchenid,
        email: email.trim(),
      });

      ToastAndroid.show("Member Invited successfully!", ToastAndroid.SHORT);
      setEmail(""); // Reset email input
    } catch (error) {
      Alert.alert("Failed to Invite. Please try again.");
      console.error(error);
    } finally {
      setIsLoading(false);
      onClose(true);
    }
  };

  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={isVisible}
      onRequestClose={() => onClose(false)}
    >
      <View style={Modalstyles.overlay}>
        <View style={Modalstyles.container}>
          <Text style={Modalstyles.title}>Invite Member</Text>

          <TextInput
            style={Modalstyles.input}
            placeholder="Enter email address"
            value={email}
            onChangeText={(text) => setEmail(text)}
          />

          <View style={Modalstyles.buttonContainer}>
            <TouchableOpacity
              style={Modalstyles.button}
              onPress={handleSubmit}
              disabled={isLoading}
            >
              {isLoading ? (
                <ActivityIndicator size="small" color="#ffff" />
              ) : (
                <Text style={Modalstyles.buttonText}>Invite</Text>
              )}
            </TouchableOpacity>
            <TouchableOpacity
              style={[Modalstyles.button, Modalstyles.cancelButton]}
              onPress={() => onClose(false)}
              disabled={isLoading}
            >
              <Text style={Modalstyles.buttonText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}
function InviteCodeModal({ isVisible, onClose, invitation_code, update }) {
  // const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async () => {
    try {
      setIsLoading(true);

      await update();
    } catch (error) {
    } finally {
      setIsLoading(false);
      // onClose();
    }
  };

  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={isVisible}
      onRequestClose={() => onClose(false)}
    >
      <View style={Modalstyles.overlay}>
        <View style={Modalstyles.container}>
          <Text style={Modalstyles.title}>Invite Member</Text>

          <TextInput
            style={Modalstyles.input}
            placeholder=""
            value={invitation_code}
            disableFullscreenUI={true}
            editable={false}
            // onChangeText={(text) => setEmail(text)}
          />

          <View style={Modalstyles.buttonContainer}>
            <TouchableOpacity
              style={Modalstyles.button}
              onPress={handleSubmit}
              disabled={isLoading}
            >
              {isLoading ? (
                <ActivityIndicator size="small" color="#ffff" />
              ) : (
                <Text style={Modalstyles.buttonText}>Reset Code</Text>
              )}
            </TouchableOpacity>
            <TouchableOpacity
              style={[Modalstyles.button, Modalstyles.cancelButton]}
              onPress={() => onClose(false)}
              disabled={isLoading}
            >
              <Text style={Modalstyles.buttonText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}
const Modalstyles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  container: {
    backgroundColor: "#fff",
    width: "90%",
    borderRadius: 10,
    padding: 20,
    elevation: 5,
    alignItems: "center",
  },
  title: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 20,
  },
  input: {
    width: "100%",
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 5,
    padding: 10,
    marginBottom: 20,
    color: "#000",
  },
  buttonContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: "100%",
  },
  button: {
    flex: 1,
    backgroundColor: "#007bff",
    paddingVertical: 5,
    borderRadius: 5,
    alignItems: "center",
    marginHorizontal: 5,
  },
  cancelButton: {
    backgroundColor: "#d33942",
  },
  buttonText: {
    color: "#fff",
    fontSize: 16,
  },
});
