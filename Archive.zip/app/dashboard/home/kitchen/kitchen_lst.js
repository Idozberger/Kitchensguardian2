import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  ToastAndroid,
} from "react-native";
import { useAppContext } from "@/components/AppContext";
import { DrawerActions } from "@react-navigation/native";

import React, { useState, useEffect } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import { useRouter, useNavigation } from "expo-router";
import { getData, postData } from "../../../../services/apiService";
import { useFocusEffect } from "expo-router";
import { useCallback } from "react";
export default function kitchen() {
  const router = useRouter();
  const { activeKitchenId, setActiveKitchenId, loggedInUser } = useAppContext();
  const navigation = useNavigation();
  const [loading, setLoading] = useState(false);
  const [kitchensLst, setKitchensLst] = useState([]);
  const [kitchensMLst, setKitchensMLst] = useState([]);

  const fetchSavedRecipe = async () => {
    if (loggedInUser == null) return;

    setLoading(true);

    try {
      const response = await getData("/api/kitchen/list_user_kitchens");
      if (response?.kitchens) {
        // setKitchensLst(response.kitchens);
        const hosts = response.kitchens.filter(
          (kitchen) => kitchen.role === "host"
        );
        const members = response.kitchens.filter(
          (kitchen) => kitchen.role === "member"
        );
        setKitchensMLst(members);
        setKitchensLst(hosts);
        console.log(response.kitchens);
      }
    } catch (error) {
      console.error("Error posting data:", error);
      ToastAndroid.show("Failed to fetch Saved Recipes", ToastAndroid.SHORT);
    } finally {
      setLoading(false);
    }
  };
  useFocusEffect(
    useCallback(() => {
      if (loggedInUser != null) fetchSavedRecipe();

      return () => {
        console.log("This route is now unfocused.");
      };
    }, [loggedInUser])
  );
  const handlePress = (data) => {
    setActiveKitchenId(data);
    router.push({
      pathname: "/dashboard/home",
    });
  };
  const onToggle = () => {
    navigation.dispatch(DrawerActions.openDrawer());
  };
  return (
    <SafeAreaView style={styles.container}>
      {activeKitchenId != null ? (
        <TouchableOpacity
          onPress={() => router.push("/dashboard/home")}
          style={styles.backBtnCon}
        >
          <Image
            source={require("../../../../assets/images/back.png")}
            style={styles.backBtnIcon}
          />
        </TouchableOpacity>
      ) : (
        <TouchableOpacity onPress={onToggle} style={styles.backBtnCon}>
          <Image
            source={require("../../../../assets/images/menu.png")}
            style={styles.backBtnIcon}
          />
        </TouchableOpacity>
      )}
      <ScrollView
        style={styles.scrollcontainer}
        showsVerticalScrollIndicator={false}
        showsHorizontalScrollIndicator={false}
      >
        <View style={styles.kitchenCon}>
          <Text style={styles.kitchenTitle}>Kitchens you have joined.</Text>
          <View style={styles.kitchenLst}>
            {loading && kitchensMLst.length == 0 && <Text>Loading...</Text>}
            {!loading && kitchensMLst.length == 0 && (
              <Text>No Kitchen Found.</Text>
            )}
            {kitchensMLst.map((kit, index) => (
              <TouchableOpacity
                key={index}
                style={styles.kitchenRowTouch}
                onPress={() => handlePress(kit)}
              >
                <View style={styles.row}>
                  <Image
                    source={require("../../../../assets/images/kitchen/kitchen.png")}
                    style={styles.kitchenIcon}
                  />
                  <Text style={styles.kitchenLbl}>{kit.kitchen_name}</Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
          <View style={styles.btnCon}>
            <TouchableOpacity
              style={styles.button}
              onPress={() =>
                router.push("/dashboard/home/kitchen/join_kitchen")
              }
            >
              <Text style={styles.buttonText}>Join a Kitchen</Text>
            </TouchableOpacity>
          </View>
        </View>
        <View style={styles.kitchenCon}>
          <Text style={styles.kitchenTitle}>Kitchens you have made.</Text>
          <View style={styles.kitchenLst}>
            {loading && kitchensLst.length == 0 && <Text>Loading...</Text>}
            {!loading && kitchensLst.length == 0 && (
              <Text>No Kitchen Found.</Text>
            )}
            {kitchensLst.map((kit, index) => (
              <TouchableOpacity
                key={index}
                style={styles.kitchenRowTouch}
                onPress={() => handlePress(kit)}
              >
                <View style={styles.row}>
                  <Image
                    source={require("../../../../assets/images/kitchen/kitchen.png")}
                    style={styles.kitchenIcon}
                  />
                  <Text style={styles.kitchenLbl}>{kit.kitchen_name}</Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
          <View style={styles.btnCon}>
            <TouchableOpacity
              style={styles.button}
              onPress={() =>
                router.push("/dashboard/home/kitchen/create_kitchen")
              }
            >
              <Text style={styles.buttonText}>Create a Kitchen</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    //   justifyContent: "center",
    //   alignItems: "center",
    paddingHorizontal: 28,
    paddingVertical: 13,
    backgroundColor: "#FFF6E5",
  },
  scrollcontainer: {
    flex: 1,
  },
  backBtnCon: {
    width: 38,
    height: 38,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#fff",
    borderRadius: 10,
  },
  kitchenCon: {
    marginTop: 12,
  },
  kitchenTitle: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 30,
    fontWeight: "400",
    lineHeight: 36,
    textAlign: "left",
    color: "#000",
    marginBottom: 10,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 8,
  },
  kitchenIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 10,
  },
  kitchenLbl: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 14,
    fontWeight: "400",
    lineHeight: 14,
    textAlign: "left",
    color: "#000",
  },
  btnCon: {
    justifyContent: "center",
    flexDirection: "row",
    marginTop: 10,
  },
  button: {
    width: 145,
    height: 48,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 8,
    backgroundColor: "#F8A600",
  },
  buttonText: {
    fontSize: 12,
  },
});
