import {
  View,
  Text,
  StyleSheet,
  TextInput,
  ScrollView,
  TouchableOpacity,
  Image,
  ToastAndroid,
  ActivityIndicator,
  Pressable,
} from "react-native";
import React, { useState, useEffect } from "react";
import { getData, postData } from "../../../../services/apiService";
import { useFocusEffect } from "expo-router";
import { useCallback } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { useAppContext } from "@/components/AppContext";

export default function join_kitchen() {
  // const [loading, setLoading] = useState(false);
  const [loadingGenerated, setLoadingGenerated] = useState(false);
  const { activeKitchenId, setActiveKitchenId } = useAppContext();
  const [text, setText] = useState("");

  const router = useRouter();

  // const [inviteLst, setInviteLst] = useState([]);
  // const fetchSavedRecipe = async (loaderOff = true) => {
  //   setLoading(loaderOff);

  //   try {
  //     const response = await getData("/api/kitchen/invitations");

  //     setInviteLst(response?.invitations ?? []);
  //   } catch (error) {
  //     console.error("Error posting data:", error);
  //     ToastAndroid.show("Failed to fetch Invites", ToastAndroid.SHORT);
  //   } finally {
  //     setLoading(false);
  //   }
  // };
  // useFocusEffect(
  //   useCallback(() => {
  //     fetchSavedRecipe();

  //     return () => {
  //       console.log("This route is now unfocused.");
  //     };
  //   }, [])
  // );
  // const fetchGeneratedRecipe = async (invitation_id, response) => {
  //   try {
  //     const responseR = await postData("/api/kitchen/respond_to_invitation", {
  //       invitation_id: invitation_id,
  //       response: response,
  //     });
  //     if (responseR?.error) {
  //       ToastAndroid.show(responseR?.error, ToastAndroid.SHORT);
  //     } else {
  //       ToastAndroid.show("Invitation Updated!", ToastAndroid.SHORT);
  //       await fetchSavedRecipe((loaderOff = false));
  //     }
  //   } catch (error) {
  //     console.error("Error posting data:", error);
  //     ToastAndroid.show("Failed to Accept Invitate", ToastAndroid.SHORT);
  //   }
  // };
  const fetchGeneratedRecipe = async () => {
    setLoadingGenerated(true);

    try {
      const response = await postData("/api/kitchen/join_with_code", {
        invitation_code: text,
      });

      if (response?.error) {
        ToastAndroid.show(response?.error, ToastAndroid.SHORT);
      } else if (response.kitchen) {
        setText("");
        ToastAndroid.show("Kitchen Joined!", ToastAndroid.SHORT);
        setActiveKitchenId(response?.kitchen);
        router.push({
          pathname: "/dashboard/home",
        });
      }else{
        ToastAndroid.show("Something went wrong", ToastAndroid.SHORT);

      }
      // console.log("Response from API:", response);
      setLoadingGenerated(false);
    } catch (error) {
      console.error("Error posting data:", error);
      ToastAndroid.show("Failed to Join", ToastAndroid.SHORT);
      setLoadingGenerated(false);
    }
  };
  const onToggle = () => {
    router.push("/dashboard/home/kitchen/kitchen_lst");
  };

  return (
    <SafeAreaView style={styles.container}>
      <TouchableOpacity onPress={onToggle} style={styles.backBtnCon}>
        <Image
          source={require("../../../../assets/images/backBtn.png")}
          style={styles.backBtnIcon}
        />
      </TouchableOpacity>
      <Text style={styles.maintitle}>Join a Kitchen</Text>
      <View style={styles.formCom}>
        <View style={styles.form}>
          <Text style={styles.inputtitle}>Code</Text>

          <TextInput
            style={styles.input}
            placeholder="Enter code"
            value={text}
            onChangeText={setText}
            placeholderTextColor="#888"
          />
          <Text style={styles.charCount}></Text>

          <View style={styles.btnCon}>
            <TouchableOpacity
              style={styles.button}
              onPress={fetchGeneratedRecipe}
            >
              {loadingGenerated ? (
                <ActivityIndicator size="small" color="#ffffff" />
              ) : (
                <Text style={styles.buttonText}>Join</Text>
              )}
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
  // return (
  //   <SafeAreaView style={styles.container}>
  //     <TouchableOpacity onPress={onToggle} style={styles.backBtnCon}>
  //       <Image
  //         source={require("../../../../assets/images/backBtn.png")}
  //         style={styles.backBtnIcon}
  //       />
  //     </TouchableOpacity>
  //     <Text style={styles.maintitle}>Join a Kitchen</Text>
  //     <ScrollView style={styles.scrollcontainer}>
  //       {loading && inviteLst.length == 0 && <Text>Loading...</Text>}
  //       {!loading && inviteLst.length == 0 && <Text>No Invite Found.</Text>}
  //       {inviteLst.map((invite) => (
  //         <InviteRow invite={invite} onAccept={fetchGeneratedRecipe} />
  //       ))}
  //     </ScrollView>
  //   </SafeAreaView>
  // );
}

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,

//     paddingHorizontal: 26,
//     paddingVertical: 13,
//     backgroundColor: "#FFF6E5",
//   },
//   form: {
//     width: "90%",
//   },
//   input: {
//     height: 48,
//     borderWidth: 0,
//     borderRadius: 10, // Rounded corners
//     paddingHorizontal: 15,
//     backgroundColor: "#F5F5F5", // Light background
//     fontSize: 14,
//     color: "#111719", // Darker text color
//   },
//   backBtnCon: {
//     width: 38,
//     height: 38,
//     alignItems: "center",
//     justifyContent: "center",
//     backgroundColor: "#fff",
//     borderRadius: 10,
//     // marginBottom: 20,
//   },
//   maintitle: {
//     fontFamily: "InriaSerif_700Bold",
//     color: "#000",
//     fontSize: 30,
//     lineHeight: 36,
//     // marginBottom: 20,
//     marginTop: 20,
//   },

//   scrollcontainer: {
//     flex: 1,
//     // paddingBottom:250
//   },
// });

// const InviteRow = ({ invite, onAccept }) => {
//   const [loading, setLoading] = useState(false);
//   const [loadingDenied, setLoadingDenied] = useState(false);

//   const acceptIT = async () => {
//     setLoading(true);
//     try {
//       await onAccept(invite.invitation_id, "accepted");
//     } catch (error) {
//     } finally {
//       setLoading(false);
//     }
//   };
//   const denieIT = async () => {
//     setLoadingDenied(true);
//     try {
//       await onAccept(invite.invitation_id, "denied");
//     } catch (error) {
//     } finally {
//       setLoadingDenied(false);
//     }
//   };
//  return (
//     <SafeAreaView style={styles.container}>
//       <TouchableOpacity onPress={onToggle} style={styles.backBtnCon}>
//         <Image
//           source={require("../../../../assets/images/backBtn.png")}
//           style={styles.backBtnIcon}
//         />
//       </TouchableOpacity>
//       <Text style={styles.maintitle}>Create a Kitchen</Text>
//       <View style={styles.formCom}>
//         <View style={styles.form}>
//           <Text style={styles.inputtitle}>Kitchen Name</Text>

//           <TextInput
//             style={styles.input}
//             placeholder="Name ...."
//             value={text}
//             onChangeText={setText}
//             placeholderTextColor="#888"
//             maxLength={40}
//           />
//           <Text style={styles.charCount}>{text.length}/40</Text>
//           <View style={styles.btnCon}>
//             <TouchableOpacity
//               style={styles.button}
//               onPress={fetchGeneratedRecipe}
//             >
//               {loadingGenerated ? (
//                 <ActivityIndicator size="small" color="#ffffff" />
//               ) : (
//                 <Text style={styles.buttonText}>Create</Text>
//               )}
//             </TouchableOpacity>
//           </View>
//         </View>
//       </View>
//     </SafeAreaView>
//   );
//   // return (
//   //   <View style={stylesInvite.card}>
//   //     {/* Top Bar */}
//   //     <View style={stylesInvite.topBar}>
//   //       <Text style={stylesInvite.idText}>#{invite._id}</Text>
//   //       <View style={{ alignItems: "center", gap: 4, flexDirection: "row" }}>
//   //         <Pressable
//   //           style={stylesInvite.acceptButton}
//   //           onPress={acceptIT}
//   //           disabled={loading || loadingDenied}
//   //         >
//   //           {loading ? (
//   //             <ActivityIndicator size="small" color="#ffffff" />
//   //           ) : (
//   //             <Text style={stylesInvite.acceptButtonText}>Accept</Text>
//   //           )}
//   //         </Pressable>
//   //         <Pressable
//   //           style={stylesInvite.deniedButton}
//   //           onPress={denieIT}
//   //           disabled={loading || loadingDenied}
//   //         >
//   //           {loadingDenied ? (
//   //             <ActivityIndicator size="small" color="#F8A600" />
//   //           ) : (
//   //             <Text style={stylesInvite.deniedButtonText}>Deny</Text>
//   //           )}
//   //         </Pressable>
//   //       </View>
//   //     </View>

//   //     {/* Bottom View */}
//   //     <View style={stylesInvite.detailsContainer}>
//   //       <View style={stylesInvite.detailRow}>
//   //         <Text style={stylesInvite.key}>Kitchen Name:</Text>
//   //         <Text style={stylesInvite.value}>{invite.kitchen_name}</Text>
//   //       </View>
//   //       <View style={stylesInvite.detailRow}>
//   //         <Text style={stylesInvite.key}>Inviter Name:</Text>
//   //         <Text style={stylesInvite.value}>{invite.inviter_name}</Text>
//   //       </View>
//   //       <View style={stylesInvite.detailRow}>
//   //         <Text style={stylesInvite.key}>Date:</Text>
//   //         <Text style={stylesInvite.value}>{invite.created_at}</Text>
//   //       </View>
//   //     </View>
//   //   </View>
//   // );
// };

const styles = StyleSheet.create({
  container: {
    flex: 1,

    paddingHorizontal: 26,
    paddingVertical: 13,
    backgroundColor: "#FFF6E5",
  },
  form: {
    width: "90%",
  },
  input: {
    height: 48,
    borderWidth: 0,
    borderRadius: 10, // Rounded corners
    paddingHorizontal: 15,
    backgroundColor: "#F5F5F5", // Light background
    fontSize: 14,
    color: "#111719", // Darker text color
  },
  backBtnCon: {
    width: 38,
    height: 38,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#fff",
    borderRadius: 10,
    // marginBottom: 20,
  },
  maintitle: {
    fontFamily: "InriaSerif_700Bold",
    color: "#000",
    fontSize: 30,
    lineHeight: 36,
    // marginBottom: 20,
    marginTop: 20,
  },
  formCom: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "column",
    marginTop: -100,
  },
  inputtitle: {
    fontFamily: "InriaSerif_700Bold",
    color: "#000",
    fontSize: 14,
    lineHeight: 16,
    marginTop: 20,
    marginBottom: 5,
  },
  charCount: {
    fontFamily: "InriaSerif_400Regular",
    color: "#000",
    textAlign: "right",
    fontSize: 10,
    lineHeight: 11,
    marginTop: 5,
    marginBottom: 10,
  },
  scrollcontainer: {
    flex: 1,
    // paddingBottom:250
  },
  btnCon: {
    width: "100%",
    justifyContent: "center",
    alignItems: "center",
  },
  button: {
    width: 248,
    height: 48,
    borderRadius: 28.5,
    backgroundColor: "#000000",
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#E6C068",
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 1,
    shadowRadius: 20,
    elevation: 5,
  },
  buttonText: {
    color: "#F8A600",
    fontFamily: "InriaSerif_400Regular",
    fontSize: 14,
    lineHeight: 16.79,
    letterSpacing: 0.08,
    textAlign: "center",
  },
  warning: {
    fontFamily: "InriaSerif_400Regular",
    color: "#000",
    textAlign: "center",
    fontSize: 14,
    lineHeight: 16,
  },
});

// const stylesInvite = StyleSheet.create({
//   card: {
//     borderWidth: 1,
//     borderColor: "#F8A600",
//     borderRadius: 12,
//     padding: 8,
//     width: "100%",
//     marginVertical: 8,
//   },
//   topBar: {
//     flexDirection: "row",
//     justifyContent: "space-between",
//     alignItems: "center",
//     marginBottom: 8,
//   },
//   idText: {
//     color: "gray",
//     fontSize: 12,
//   },
//   acceptButton: {
//     backgroundColor: "#F8A600",
//     borderRadius: 12,
//     paddingVertical: 4,
//     paddingHorizontal: 12,
//   },
//   acceptButtonText: {
//     color: "white",
//     fontSize: 12,
//   },
//   deniedButton: {
//     borderColor: "#F8A600",
//     borderWidth: 1,
//     borderRadius: 12,
//     paddingVertical: 4,
//     paddingHorizontal: 12,
//   },
//   deniedButtonText: {
//     color: "#F8A600",
//     fontSize: 12,
//   },
//   detailsContainer: {
//     marginTop: 8,
//   },
//   detailRow: {
//     flexDirection: "row",
//     justifyContent: "space-between",
//     marginVertical: 2,
//   },
//   key: {
//     fontFamily: "InriaSerif_400Regular",
//     fontSize: 11.82,
//     lineHeight: 14.17,
//     textAlign: "left",
//     textUnderlinePosition: "from-font",
//     textDecorationSkipInk: "none",
//   },
//   value: {
//     fontFamily: "InriaSerif_700Bold",
//     fontSize: 13.78,
//     lineHeight: 16.53,
//     textAlign: "left",
//   },
// });
