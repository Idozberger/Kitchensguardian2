import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Modal,
  Pressable,
  TextInput,
  Button,
  FlatList,
  Alert,
  ActivityIndicator,
  ToastAndroid,
} from "react-native";
import React, { useState, useEffect, useCallback } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import { useNavigation, useRouter, useFocusEffect } from "expo-router";
import { DrawerActions } from "@react-navigation/native";
import { getData, postData } from "../../../services/apiService";
import { FontAwesome } from "@expo/vector-icons";
import { useAppContext } from "@/components/AppContext";
import { useLocalSearchParams } from "expo-router";
import RNPickerSelect from "react-native-picker-select";

export default function index() {
  const router = useRouter();
  const { activeKitchenId } = useAppContext();
  const { items } = useLocalSearchParams();

  const navigation = useNavigation();
  const [listofItems, setListofItems] = useState([]);
  const [showAddItemModal, setShowAddItemModal] = useState(null);
  const [showRequestItemModal, setShowRequestItemModal] = useState(null);

  useFocusEffect(
    useCallback(() => {
      console.log(activeKitchenId);
      if (activeKitchenId && activeKitchenId != null) {
        listTheItemsKitchens(activeKitchenId.kitchen_id);
      } else {
        router.push("/dashboard/home/kitchen/kitchen_lst", undefined, {
          shallow: true,
        });
      }

      return () => {
        console.log("This route is now unfocused.");
      };
    }, [activeKitchenId, navigation])
  );
  useFocusEffect(
    useCallback(() => {
      const getV = async (items_) => {
        console.log("items_", typeof items_, items_);
        try {
          console.log("01");
          let temp = JSON.parse(items_);
          console.log("02");

          setShowAddItemModal(temp);
          console.log("03");

          // router.replace({
          //   pathname: router.pathname,
          //   params: {}, // Clear all search parameters
          // });
        } catch (error) {
          console.error(error);
        }
      };
      if (items) getV(items);

      return;
    }, [items])
  );
  const listTheItemsKitchens = async (KID) => {
    try {
      const response = await getData(
        "/api/kitchen/list_items?kitchen_id=" + KID
      );
      console.log(response.items);
      setListofItems(response.items);
    } catch (error) {
      console.error("Error posting data:", error);
    }
  };

  const onToggle = () => {
    navigation.dispatch(DrawerActions.openDrawer());
  };

  return (
    <>
      <SafeAreaView style={styles.container}>
        {/* <Button onPress={onToggle} title="TEst"></Button> */}
        <View style={styles.menuBAr}>
          <TouchableOpacity onPress={onToggle} style={styles.backBtnCon}>
            <Image
              source={require("../../../assets/images/menu.png")}
              style={styles.backBtnIcon}
            />
          </TouchableOpacity>
          <Text style={[styles.subtitle, { fontSize: 18 }]}>
            {activeKitchenId?.kitchen_name}
          </Text>
          <TouchableOpacity
            onPress={() => {
              router.replace("/dashboard/profile");
            }}
          >
            <Image
              source={require("../../../assets/images/SideMenu/avatar.png")}
              style={styles.userIcon}
            />
          </TouchableOpacity>
        </View>
        <ScrollView
          style={styles.scrollcontainer}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
        >
          <Text style={styles.title}>Scan to log in your food!</Text>
          <View style={styles.scanCard}>
            <TouchableOpacity
              style={[
                styles.ScanbtnCon,
                activeKitchenId?.role == "member" && styles.ScanbtnConDisbale,
              ]}
              onPress={() => router.push("/dashboard/home/camera")}
              disabled={activeKitchenId?.role == "member"}
            >
              <Text style={styles.ScanbtnText}>SCAN NOW</Text>
            </TouchableOpacity>
          </View>
          <Text style={styles.title}>What's in?</Text>
          <View style={styles.ingredientsBar}>
            <Text style={styles.titleMenu}>Available ingredients</Text>
            {activeKitchenId && activeKitchenId?.role !== "member" && (
              <TouchableOpacity
                style={[styles.addMenuBtn]}
                onPress={() => setShowAddItemModal([])}
                disabled={activeKitchenId?.role == "member"}
              >
                <Text style={styles.addMenuBtnLbl}>Add Items</Text>
              </TouchableOpacity>
            )}
            <TouchableOpacity
              style={styles.titleMenuBtn}
              onPress={() => router.push(`/dashboard/home/see_all_items`)}
            >
              <Text style={styles.titleMenuBtnLbl}>See all</Text>
            </TouchableOpacity>
          </View>

          <View>
            {listofItems.length == 0 && (
              <Text style={styles.nofound}>No Ingredients Found.</Text>
            )}
            {listofItems.slice(0, 4).map((item, index) => (
              <View style={styles.itemRow} key={index}>
                <View style={styles.itemRowLeft}>
                  <Image
                    style={styles.itemRowLeftImg}
                    source={require("../../../assets/images/kitchen/item.png")}
                  />
                  <Text style={styles.itemRowLeftLbl}>{item.name}</Text>
                </View>
                <Text style={styles.itemRowRight}>
                  {item.quantity} {item.unit}
                </Text>
              </View>
            ))}

            <View style={styles.btnCon}>
              <TouchableOpacity
                style={styles.button}
                onPress={() =>
                  router.push(
                    "/dashboard/home/available_recipes/recipe_generate"
                  )
                }
              >
                <Text style={styles.buttonText}>Available recipes </Text>
              </TouchableOpacity>
            </View>
          </View>
          <Text style={styles.title}>Request List</Text>
          <Text style={styles.subtitle}>
            Request host to buy groceries or dinner
          </Text>
          <View style={styles.btnCon}>
            <TouchableOpacity
              style={styles.button}
              onPress={() => setShowRequestItemModal([])}
            >
              <Text style={styles.buttonText}>Request Now </Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </SafeAreaView>
      <AddItemModal
        isVisible={showAddItemModal != null}
        preItems={showAddItemModal}
        onClose={(e) => {
          if (e == true) listTheItemsKitchens(activeKitchenId?.kitchen_id);
          setShowAddItemModal(null);
        }}
        kitchenid={activeKitchenId?.kitchen_id}
      />
      <RequestItemModal
        isVisible={showRequestItemModal != null}
        preItems={showRequestItemModal}
        onClose={(e) => {
          // if (e == true) listTheItemsKitchens(activeKitchenId?.kitchen_id);
          setShowRequestItemModal(null);
        }}
        kitchenid={activeKitchenId?.kitchen_id}
      />
    </>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    // justifyContent: "center",
    // alignItems: "center",
    paddingHorizontal: 26,
    paddingVertical: 13,
    backgroundColor: "#FFF6E5",
  },
  scrollcontainer: {
    flex: 1,
  },
  menuBAr: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  backBtnCon: {
    width: 38,
    height: 38,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#fff",
    borderRadius: 10,
  },
  userIcon: {
    width: 38,
    height: 38,
    backgroundColor: "#ffc529",
    borderRadius: 10,
  },
  title: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 30,
    fontWeight: "400",
    lineHeight: 36,
    textAlign: "left",
    color: "#000",
    marginBottom: 10,
    marginTop: 20,
  },
  subtitle: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 14,
    fontWeight: "400",
    lineHeight: 16,
    textAlign: "left",
    color: "#000",
  },
  nofound: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 14,
    fontWeight: "400",
    lineHeight: 16,
    textAlign: "center",
    color: "#000",
    marginVertical: 10,
  },
  scanCard: {
    backgroundColor: "#000",
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
    height: 110,
    // width: 323,
  },
  ScanbtnCon: {
    width: 248,
    height: 48,
    borderRadius: 12,
    backgroundColor: "#FFF6E5",
    justifyContent: "center",
    alignItems: "center",
    // iOS Shadow
    shadowColor: "#E6C068",
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 1,
    shadowRadius: 10,
    // Android Shadow (elevation)
    elevation: 10,
  },
  ScanbtnConDisbale: {
    backgroundColor: "gray",
  },
  ScanbtnText: {
    fontFamily: "InriaSerif_700Bold",
    color: "#000",
    fontSize: 14,
    lineHeight: 16,
    fontWeight: "700",
  },
  ingredientsBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  titleMenu: {
    fontFamily: "InriaSerif_700Bold",
    color: "#000",
    fontSize: 15,
    lineHeight: 16,
    // fontWeight: "700",
  },
  titleMenuBtn: {
    minWidth: 70,
    width: "auto",
    height: 31,
    borderRadius: 8,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
  titleMenuBtnLbl: {
    color: "#000",
    fontSize: 12,
    lineHeight: 14,
    fontWeight: "700",
    textDecorationLine: "underline",
  },
  addMenuBtn: {
    width: 70,
    height: 31,
    borderRadius: 8,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
  addMenuBtnLbl: {
    color: "#000",
    fontSize: 12,
    lineHeight: 14,
    fontWeight: "700",
  },
  itemRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: 10,
  },
  itemRowLeft: {
    flexDirection: "row",
    alignItems: "center",
  },
  itemRowLeftImg: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 8,
  },
  itemRowLeftLbl: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 14,
    fontWeight: "400",
    lineHeight: 16,
    textAlign: "left",
    color: "#000",
  },
  itemRowRight: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 14,
    fontWeight: "400",
    lineHeight: 16,
    textAlign: "left",
    color: "#000",
  },
  btnCon: {
    justifyContent: "center",
    flexDirection: "row",
    marginTop: 10,
  },
  button: {
    width: 145,
    height: 48,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 8,
    backgroundColor: "#F8A600",
  },
  buttonText: {
    fontSize: 12,
  },
});
function AddItemModal({ isVisible, onClose, kitchenid, preItems }) {
  const [items, setItems] = useState([
    { id: Date.now(), name: "", unit: "kg", quantity: "", group: "pantry" },
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const addNewItem = () => {
    setItems((prevItems) => [
      ...prevItems,
      { id: Date.now(), name: "", unit: "kg", quantity: "", group: "pantry" },
    ]);
  };

  const updateItem = (id, field, value) => {
    setItems((prevItems) =>
      prevItems.map((item) =>
        item.id === id ? { ...item, [field]: value } : item
      )
    );
  };
  const deleteItem = (id) => {
    setItems((prevItems) => prevItems.filter((item) => item.id !== id));
  };

  useEffect(() => {
    if (preItems != null && preItems.length > 0) {
      let temp = [];
      preItems.forEach((element) => {
        temp.push({
          id:
            Date.now().toLocaleString() +
            Math.floor(Math.random() * 1000).toLocaleString(),
          name: element.name || "",
          unit: element.unit || "kg",
          quantity: element.amount || "0",
          group: element.group || "pantry",
        });
      });
      setItems(temp);
    }
  }, [preItems]);

  const renderRow = ({ item, index }) => (
    <View style={modal_style.row}>
      {/* <Text style={modal_style.index}>{index + 1}.</Text> */}
      <TextInput
        style={modal_style.input}
        placeholder="Item Name"
        value={item.name}
        onChangeText={(text) => updateItem(item.id, "name", text)}
      />
      <TextInput
        style={[modal_style.input, { maxWidth: 50 }]}
        placeholder="Qty"
        value={item.quantity}
        keyboardType="numeric"
        onChangeText={(text) => updateItem(item.id, "quantity", text)}
      />
      {/* <TextInput
        style={[modal_style.input, { maxWidth: 75 }]}
        placeholder="Item Unit"
        value={item.unit}
        onChangeText={(text) => updateItem(item.id, "unit", text)}
      /> */}
      {/* Kg, count, liters, milliliters, grams, pounds, ounces */}
      <View style={{ width: 75, marginRight: 5 }}>
        <RNPickerSelect
          onValueChange={(text) => updateItem(item.id, "unit", text)}
          items={[
            { label: "KG", value: "kg" },
            { label: "Litre", value: "litre" },
            { label: "Count", value: "count" },

            { label: "Milliliters", value: "milliliters" },
            { label: "Grams", value: "grams" },
            { label: "Pounds", value: "pounds" },
            { label: "Ounces", value: "ounces" },
          ]}
          value={item.unit}
          useNativeAndroidPickerStyle={false}
          style={{
            inputAndroid: {
              fontSize: 12,
              paddingHorizontal: 10,
              paddingVertical: 5,
              borderWidth: 1,
              borderColor: "#ccc",
              borderRadius: 5,
              color: "#333",
              paddingRight: 0, // to ensure the text is not overlapping the dropdown arrow
            },
            placeholder: {
              color: "#888",
              fontSize: 12,
            },
            iconContainer: {
              top: 15,
              right: 8,
            },
          }}
          Icon={() => {
            return <FontAwesome name="chevron-down" size={12} color="#888" />;
          }}
        />
      </View>
      <View style={{ width: 75 }}>
        <RNPickerSelect
          onValueChange={(value) => updateItem(item.id, "group", value)}
          items={[
            { label: "Pantry", value: "pantry" },
            { label: "Fridge", value: "fridge" },
            { label: "Freezer", value: "freezer" },
          ]}
          value={item.group}
          useNativeAndroidPickerStyle={false}
          style={{
            inputAndroid: {
              fontSize: 12,
              paddingHorizontal: 10,
              paddingVertical: 5,
              borderWidth: 1,
              borderColor: "#ccc",
              borderRadius: 5,
              color: "#333",
              paddingRight: 0, // to ensure the text is not overlapping the dropdown arrow
            },
            placeholder: {
              color: "#888",
              fontSize: 12,
            },
            iconContainer: {
              top: 15,
              right: 8,
            },
          }}
          Icon={() => {
            return <FontAwesome name="chevron-down" size={12} color="#888" />;
          }}
        />
      </View>
      <TouchableOpacity
        onPress={() => deleteItem(item.id)}
        style={{ marginLeft: 5 }}
      >
        <FontAwesome name="trash" size={16} color="red" />
      </TouchableOpacity>
    </View>
  );

  const handleSubmit = async () => {
    const hasEmptyFields = items.some(
      (item) =>
        !item.name?.trim() ||
        !item.unit?.trim() ||
        !item.quantity ||
        isNaN(item.quantity)
    );

    if (hasEmptyFields) {
      Alert.alert(
        "Missing Fields",
        "Please fill out all fields before submitting."
      );
      return;
    }
    try {
      setIsLoading(true);
      const formattedData = {
        kitchen_id: kitchenid,
        items: items.map((item) => ({
          name: item.name || "",
          quantity: parseInt(item.quantity, 10) || 0,
          unit: item.unit || "",
          group: item.group || "pantry",
        })),
      };

      const resp = await postData("/api/kitchen/add_items", formattedData);
      if (resp.message) {
        ToastAndroid.show("All items added successfully!", ToastAndroid.SHORT); // Show success toast

        setItems([{ id: Date.now(), name: "", unit: "", quantity: "" }]);
        setIsLoading(false); // Hide loader
        onClose(true);
      } else {
        ToastAndroid.show("Something went wrong..", ToastAndroid.SHORT); // Show success toast
        setIsLoading(false);
      }
    } catch (error) {
      alert("Failed to submit items. Please try again.");
      console.error(error);
    } finally {
    }
  };
  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={isVisible}
      onRequestClose={() => onClose(false)}
    >
      <View style={modal_style.modalOverlay}>
        <View style={modal_style.modalContainer}>
          <Text style={modal_style.modalTitle}>Add Ingredients</Text>

          <FlatList
            data={items}
            renderItem={renderRow}
            keyExtractor={(item) => item.id.toString()}
            style={styles.list}
            contentContainerStyle={{ paddingBottom: 5 }} // Add padding for better spacing
            showsVerticalScrollIndicator={true}
          />

          <TouchableOpacity style={modal_style.addButton} onPress={addNewItem}>
            <Text style={modal_style.addButtonText}>Add Another Item</Text>
          </TouchableOpacity>

          <View style={modal_style.buttonContainer}>
            {isLoading ? (
              <ActivityIndicator size="small" color="#0000ff" />
            ) : (
              <>
                <TouchableOpacity
                  style={modal_style.submitButton}
                  onPress={handleSubmit}
                >
                  <Text style={modal_style.submitButtonText}>Submit</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={modal_style.closeButton}
                  onPress={() => onClose(false)}
                >
                  <Text style={modal_style.submitButtonText}>Close</Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        </View>
      </View>
    </Modal>
  );
}
function RequestItemModal({ isVisible, onClose, kitchenid, preItems }) {
  const [items, setItems] = useState([
    { id: Date.now(), name: "", unit: "kg", quantity: "" },
  ]);
  const [isLoading, setIsLoading] = useState(false);
  

  const updateItem = (id, field, value) => {
    setItems((prevItems) =>
      prevItems.map((item) =>
        item.id === id ? { ...item, [field]: value } : item
      )
    );
  };
  
  useEffect(() => {
    if (preItems != null && preItems.length > 0) {
      let temp = [];
      preItems.forEach((element) => {
        temp.push({
          id:
            Date.now().toLocaleString() +
            Math.floor(Math.random() * 1000).toLocaleString(),
          name: element.name || "",
          unit: element.unit || "kg",
          quantity: element.amount || "0",
        });
      });
      setItems(temp);
    }
  }, [preItems]);

  const renderRow = ({ item, index }) => (
    <View style={modal_style.row}>
      {/* <Text style={modal_style.index}>{index + 1}.</Text> */}
      <TextInput
        style={modal_style.input}
        placeholder="Item Name"
        value={item.name}
        onChangeText={(text) => updateItem(item.id, "name", text)}
      />
      <TextInput
        style={[modal_style.input, { maxWidth: 50 }]}
        placeholder="Qty"
        value={item.quantity}
        keyboardType="numeric"
        onChangeText={(text) => updateItem(item.id, "quantity", text)}
      />
      {/* <TextInput
        style={[modal_style.input, { maxWidth: 75 }]}
        placeholder="Item Unit"
        value={item.unit}
        onChangeText={(text) => updateItem(item.id, "unit", text)}
      /> */}
      {/* Kg, count, liters, milliliters, grams, pounds, ounces */}
      <View style={{ width: 75, marginRight: 5 }}>
        <RNPickerSelect
          onValueChange={(text) => updateItem(item.id, "unit", text)}
          items={[
            { label: "KG", value: "kg" },
            { label: "Litre", value: "litre" },
            { label: "Count", value: "count" },

            { label: "Milliliters", value: "milliliters" },
            { label: "Grams", value: "grams" },
            { label: "Pounds", value: "pounds" },
            { label: "Ounces", value: "ounces" },
          ]}
          value={item.unit}
          useNativeAndroidPickerStyle={false}
          style={{
            inputAndroid: {
              fontSize: 12,
              paddingHorizontal: 10,
              paddingVertical: 5,
              borderWidth: 1,
              borderColor: "#ccc",
              borderRadius: 5,
              color: "#333",
              paddingRight: 0, // to ensure the text is not overlapping the dropdown arrow
            },
            placeholder: {
              color: "#888",
              fontSize: 12,
            },
            iconContainer: {
              top: 15,
              right: 8,
            },
          }}
          Icon={() => {
            return <FontAwesome name="chevron-down" size={12} color="#888" />;
          }}
        />
      </View>
    </View>
  );

  const handleSubmit = async () => {
    const hasEmptyFields = items.some(
      (item) =>
        !item.name?.trim() ||
        !item.unit?.trim() ||
        !item.quantity ||
        isNaN(item.quantity)
    );

    if (hasEmptyFields) {
      Alert.alert(
        "Missing Fields",
        "Please fill out all fields before submitting."
      );
      return;
    }
    try {
      setIsLoading(true);
      const formattedData = {
        kitchen_id: kitchenid,

        name: items[0].name,
        quantity: parseInt(items[0].quantity, 10) || 0,
        unit: items[0].unit || "",
      };

      const resp = await postData("/api/kitchen/request_item", formattedData);
      if (resp.message) {
        ToastAndroid.show("Item requested successfully!", ToastAndroid.SHORT); // Show success toast

        setItems([{ id: Date.now(), name: "", unit: "", quantity: "kg" }]);
        setIsLoading(false); // Hide loader
        onClose(true);
      } else {
        ToastAndroid.show("Something went wrong..", ToastAndroid.SHORT); // Show success toast
        setIsLoading(false);
      }
    } catch (error) {
      alert("Failed to submit items. Please try again.");
      console.error(error);
    } finally {
    }
  };
  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={isVisible}
      onRequestClose={() => onClose(false)}
    >
      <View style={modal_style.modalOverlay}>
        <View style={modal_style.modalContainer}>
          <Text style={modal_style.modalTitle}>Request Ingredients</Text>

          <FlatList
            data={items}
            renderItem={renderRow}
            keyExtractor={(item) => item.id.toString()}
            style={styles.list}
            contentContainerStyle={{ paddingBottom: 5 }} // Add padding for better spacing
            showsVerticalScrollIndicator={true}
          />

          <View style={modal_style.buttonContainer}>
            {isLoading ? (
              <ActivityIndicator size="small" color="#0000ff" />
            ) : (
              <>
                <TouchableOpacity
                  style={modal_style.submitButton}
                  onPress={handleSubmit}
                >
                  <Text style={modal_style.submitButtonText}>Submit</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={modal_style.closeButton}
                  onPress={() => onClose(false)}
                >
                  <Text style={modal_style.submitButtonText}>Close</Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        </View>
      </View>
    </Modal>
  );
}
const modal_style = StyleSheet.create({
  buttonText: {
    color: "#fff",
    fontSize: 16,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  modalContainer: {
    backgroundColor: "#fff",
    width: "95%",
    borderRadius: 10,
    paddingHorizontal: 6,
    paddingVertical: 10,
    elevation: 10,
    maxHeight: "60%",
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 20,
    textAlign: "center",
  },

  buttonContainer: {
    flexDirection: "row",
    justifyContent: "center",
    gap: 8,
  },
  list: {
    flexGrow: 0,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 5,
    paddingHorizontal: 0,
  },
  index: {
    width: 25,
    textAlign: "center",
    fontSize: 14,
    fontWeight: "bold",
  },
  input: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 5,
    padding: 5,
    marginHorizontal: 2,
  },
  addButton: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 15,
    justifyContent: "center",
  },
  addButtonText: {
    // marginLeft: 10,
    fontSize: 16,
    color: "#007bff",
  },
  submitButton: {
    backgroundColor: "#007bff",
    paddingVertical: 8,
    paddingHorizontal: 20,
    borderRadius: 10,
    alignItems: "center",
  },
  closeButton: {
    backgroundColor: "#d33942",
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 10,
    alignItems: "center",
  },
  submitButtonText: {
    color: "#fff",
    fontSize: 16,
  },
});
