import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Button,
  Image,
  ActivityIndicator,
  Alert,
} from "react-native";
import React, { useState, useEffect, useRef } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import { CameraView, CameraType, useCameraPermissions } from "expo-camera";
import { postDataForm } from "../../../services/apiService";
import { useRouter } from "expo-router";
import { useFocusEffect } from "expo-router";
export default function camera() {
  const router = useRouter();
  const [facing, setFacing] = useState("back");
  const [loading, setLoading] = useState(false);
  const resetTheAction = useRef(false);

  const [permission, requestPermission] = useCameraPermissions();
  const [photoUri, setPhotoUri] = useState(null); // Store the captured photo
  const cameraRef = useRef(null); // Reference to the camera
  useFocusEffect(
    React.useCallback(() => {
      console.log("I am Called Callback");
      setLoading(false);
      resetTheAction.current = false;

      setPhotoUri(null); // Reset the captured image when screen is focused
      return () => {
        console.log("I am Called Callback Unfocus");
        setLoading(false);
        resetTheAction.current = false;

        setPhotoUri(null);
      };
    }, [])
  );
  if (!permission) {
    // Camera permissions are still loading.
    return <View />;
  }

  if (!permission.granted) {
    // Camera permissions are not granted yet.
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.Subcontainer}>
          <Text style={styles.message}>
            We need your permission to show the camera
          </Text>
          <TouchableOpacity onPress={requestPermission} style={styles.ourBtn}>
            <Text style={styles.ourBtnTxt}>Allow Camera</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const captureCamera = async () => {
    console.log("i am here");

    if (cameraRef.current) {
      console.log("Hello");
      try {
        const photo = await cameraRef.current.takePictureAsync(); // Capture the photo
        setPhotoUri(photo.uri); // Store the URI of the captured photo
      } catch (error) {
        console.log("Error taking photo:", error);
      }
    }
  };
  const retakePhoto = () => {
    setLoading(false);
    resetTheAction.current = false;

    setPhotoUri(null); // Reset the captured photo to retake
  };
  const confirmPhoto = async () => {
    setLoading(true);
    resetTheAction.current = true;

    // Function to send the captured image to the API
    const formData = new FormData();
    formData.append("file", {
      uri: photoUri,
      type: "image/jpeg", // Change to the correct file type if needed
      name: "photo.jpg",
    });

    try {
      let response = await postDataForm("/api/scan_recipt", formData);
      console.log("loading", resetTheAction.current);

      if (resetTheAction.current == false) {
      } else if (response?.error) {
        Alert.alert("Error", response?.error);
      } else {
        console.log(response);
        if (response.res.items || response.res.ingredients) {
          const data = response.res.items || response.res.ingredients;

          // Navigate to the dashboard/home screen with the data
          console.log("response 00");

          router.push({
            pathname: "/dashboard/home",
            params: { items: JSON.stringify(data) }, // Convert the object to a string for navigation
          });
        } else {
          Alert.alert("Warning", "No item found!");
        }
      }
    } catch (error) {
      console.log("Error uploading image:", error);
    } finally {
      setLoading(false);
      resetTheAction.current = false;
    }
  };
  if (photoUri) {
    // Show the captured image with "Confirm" and "Retake" buttons
    return (
      <SafeAreaView style={styles.container}>
        <Image source={{ uri: photoUri }} style={styles.preview} />
        <View style={styles.buttonContainer}>
          <TouchableOpacity
            style={styles.button}
            onPress={() => confirmPhoto()}
          >
            {loading ? (
              <ActivityIndicator size="small" color="#ffffff" />
            ) : (
              <Text style={styles.text}>Confirm</Text>
            )}
          </TouchableOpacity>
          <TouchableOpacity style={styles.buttonR} onPress={retakePhoto}>
            <Text style={styles.textR}>Retake</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }
  return (
    <SafeAreaView style={styles.container}>
      <CameraView style={styles.camera} facing={facing} ref={cameraRef}>
        <View style={styles.buttonContainerC}>
          <TouchableOpacity style={styles.buttonC} onPress={captureCamera}>
            <Text style={styles.textC}>Capture</Text>
          </TouchableOpacity>
        </View>
      </CameraView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,

    // paddingHorizontal: 10,
    // paddingVertical: 5,
    backgroundColor: "#FFF6E5",
  },
  Subcontainer: {
    flex: 1,
    justifyContent: "center",
  },
  message: {
    textAlign: "center",
    paddingBottom: 10,
  },
  camera: {
    flex: 1,
    borderRadius: 8,
  },
  buttonContainerC: {
    flex: 1,
    flexDirection: "row",
    backgroundColor: "transparent",
    margin: 64,
  },
  buttonC: {
    flex: 1,
    alignSelf: "flex-end",
    alignItems: "center",
  },
  textC: {
    fontSize: 24,
    fontWeight: "bold",
    color: "white",
  },
  ourBtn: {
    width: 145,
    height: 48,
    borderRadius: 8,
    backgroundColor: "#f8a600",
    justifyContent: "center",
    alignItems: "center",
  },
  ourBtnTxt: {
    fontSize: 12,
    lineHeight: 14,
    textAlign: "center",
    color: "#fff",
  },
  preview: {
    flex: 1,
    // borderRadius: 8,
    width: "100%",
  },
  buttonContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    padding: 16,
  },
  button: {
    width: 120,
    padding: 12,
    borderRadius: 8,
    backgroundColor: "#f8a600",
    alignItems: "center",
  },
  text: {
    fontSize: 18,
    color: "white",
    fontWeight: "bold",
  },
  buttonR: {
    width: 120,
    padding: 12,
    borderRadius: 8,
    // backgroundColor: "#f8a600",
    alignItems: "center",
  },
  textR: {
    fontSize: 18,
    color: "#f8a600",
    // fontWeight: "bold",
  },
});
