import {
  View,
  TextInput,
  Button,
  StyleSheet,
  Text,
  TouchableOpacity,
  Image,
  ScrollView,
  Modal,
  TouchableWithoutFeedback,
  Pressable,
  Alert,
  ToastAndroid,
} from "react-native";
import React, { useState, useEffect } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  useNavigation,
  useRouter,
  useLocalSearchParams,
  useGlobalSearchParams,
} from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useAppContext } from "@/components/AppContext";
import { getData, postData } from "../../../../services/apiService";

export default function Recipe_home() {
  const { activeKitchenId, setRunningRecipeContext } = useAppContext();

  const [selectedTab, setSelectedTab] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);

  // 0 - null, 1 - current Running, 2 - other running
  const [recipeRunning, setRecipeRunning] = useState(0);

  const [recipeDetails, setRecipeDetails] = useState(null);

  const navigation = useNavigation();
  const router = useRouter();
  const { data } = useLocalSearchParams();
  useEffect(() => {
    if (data && activeKitchenId != null) {
      const getV = async () => {
        
        let temp = JSON.parse(data);
        setRecipeDetails(temp);
        console.log("temp", temp);
        let run = await retrieveFromAsyncStorage(temp._id, activeKitchenId.kitchen_id);
        if (run != null) {
          if (run._id == temp._id) {
            setRecipeRunning(1);
          }
        }
      };
      getV();
    }
  }, [data,activeKitchenId]);
  const onToggle = () => {
    navigation.goBack();
  };
  const addToFav = async () => {
    try {
      if (recipeDetails?.liked && recipeDetails?.liked == true) {
        setRecipeDetails((prev) => ({
          ...prev,
          liked: false,
        }));
        const response = await postData("/api/recipe/remove_from_fav", {
          recipe_id: recipeDetails._id,
        });
        if (
          response?.error &&
          response?.error != undefined &&
          response?.error != null
        ) {
          ToastAndroid.show("Failed to remove Recipe.", ToastAndroid.SHORT);
          setRecipeDetails((prev) => ({
            ...prev,
            liked: true,
          }));
        } else {
          // setRecipeDetails((prev) => ({
          //   ...prev,
          //   liked: false,
          // }));
          ToastAndroid.show(
            "Recipe removed from favourites successfully",
            ToastAndroid.SHORT
          );
        }
      } else {
        setRecipeDetails((prev) => ({
          ...prev,
          liked: true,
        }));
        const response = await postData("/api/recipe/add_to_fav", {
          _id: recipeDetails._id,
        });
        if (response?.error == "Recipe is already in your favourites") {
          setRecipeDetails((prev) => ({
            ...prev,
            liked: true,
          }));
        } else if (
          response?.message == "Recipe added to favourites successfully"
        ) {
          // setRecipeDetails((prev) => ({
          //   ...prev,
          //   liked: true,
          // }));
          ToastAndroid.show(
            "Recipe added to favourites successfully",
            ToastAndroid.SHORT
          );
        }
      }
    } catch (error) {
      console.error("Error posting data:", error);
    }
  };
  const retrieveFromAsyncStorage = async (globalId, kitchen_id) => {
    try {
      const jsonString = await AsyncStorage.getItem("@RunningRecipe");
      if (jsonString !== null) {
        const data = JSON.parse(jsonString);
        const foundItem = data.find(
          (item) => item._id === globalId && item.kitchen_id === kitchen_id
        );
        return foundItem;
      } else {
        console.log("No data found");
      }
    } catch (error) {
      console.error("Error retrieving data from AsyncStorage:", error);
    }
    return null;
  };
  const onRecipeStart = async () => {
    if (recipeDetails.missing_items) {
      Alert.alert("Error", "Some ingredients are missing, so the recipe can’t be started.");
      return;
    }
    try {
      const jsonString = await AsyncStorage.getItem("@RunningRecipe");
      let data = [];
      if (jsonString !== null) {
        data = JSON.parse(jsonString);
        data.push({ ...recipeDetails, kitchen_id: activeKitchenId?.kitchen_id });
        await AsyncStorage.setItem("@RunningRecipe", JSON.stringify(data));
      } else {
        data.push({ ...recipeDetails, kitchen_id: activeKitchenId?.kitchen_id });

        await AsyncStorage.setItem("@RunningRecipe", JSON.stringify(data));
      }
      // const jsonString = JSON.stringify(recipeDetails);
      setRecipeRunning(1);
      const foundItems = data.filter(
        (item) => item.kitchen_id === activeKitchenId?.kitchen_id
      );

      setRunningRecipeContext(foundItems);

      Alert.alert("Success", "Recipe Started!");
    } catch (error) {
      Alert.alert("Error", "Failed Start Recipe!");
      console.error("Error saving data to AsyncStorage:", error);
    }
  };
  const onRecipeFinish = async () => {
    try {
      const response = await postData("/api/kitchen/mark_recipe_finished", {
        kitchen_id: activeKitchenId?.kitchen_id,
        recipe_id: recipeDetails._id,
      });
      if (response?.error) {
        Alert.alert("Error", response?.error);
      } else {
        const jsonString = await AsyncStorage.getItem("@RunningRecipe");
        let data = [];
        if (jsonString !== null) {
          data = JSON.parse(jsonString);
          const updatedData = data.filter(
            (item) =>
              item._id !== recipeDetails._id &&
              item.kitchen_id !== activeKitchenId?.kitchen_id
          );
          data = updatedData;
          // Save the updated array back to AsyncStorage
          await AsyncStorage.setItem(
            "@RunningRecipe",
            JSON.stringify(updatedData)
          );
        }

        // await AsyncStorage.removeItem("@RunningRecipe");
        setRecipeRunning(0);
        setRunningRecipeContext(data);

        Alert.alert("Success", "Recipe Finished!");
      }
    } catch (error) {
      Alert.alert("Error", "Failed Finish Recipe!");
      console.error("Error saving data to AsyncStorage:", error);
    }
  };
  const onRecipeStop = async () => {
    try {
      const jsonString = await AsyncStorage.getItem("@RunningRecipe");

      let data = [];
      if (jsonString !== null) {
        data = JSON.parse(jsonString);
        const updatedData = data.filter(
          (item) =>
            item._id !== recipeDetails._id &&
            item.kitchen_id !== activeKitchenId?.kitchen_id
        );
        data = updatedData;

        // Save the updated array back to AsyncStorage
        await AsyncStorage.setItem(
          "@RunningRecipe",
          JSON.stringify(updatedData)
        );
      }

      // await AsyncStorage.removeItem("@RunningRecipe");
      setRecipeRunning(0);
      setRunningRecipeContext(data);

      Alert.alert("Success", "Recipe Stopped!");
    } catch (error) {
      Alert.alert("Error", "Failed Stop Recipe!");
      console.error("Error saving data to AsyncStorage:", error);
    }
  };
  const showRecipeStartConfirmation = () => {
    Alert.alert(
      "Confirm Recipe Start", // Title
      "Are you sure you want to proceed?", // Message
      [
        {
          text: "Cancel",
          onPress: () => console.log("Cancel Pressed"),
          style: "cancel",
        },
        {
          text: "Yes",
          onPress: onRecipeStart,
        },
      ],
      { cancelable: false } // Prevent closing by tapping outside
    );
  };
  const showRecipeFinishConfirmation = () => {
    Alert.alert(
      "Confirm Recipe Finish", // Title
      "Are you sure you want to proceed?", // Message
      [
        {
          text: "Cancel",
          onPress: () => console.log("Cancel Pressed"),
          style: "cancel",
        },
        {
          text: "Yes",
          onPress: onRecipeFinish,
        },
      ],
      { cancelable: false } // Prevent closing by tapping outside
    );
  };
  const showRecipeCancelConfirmation = () => {
    Alert.alert(
      "Confirm Recipe Cancel", // Title
      "Are you sure you want to proceed?", // Message
      [
        {
          text: "Cancel",
          onPress: () => console.log("Cancel Pressed"),
          style: "cancel",
        },
        {
          text: "Yes",
          onPress: onRecipeStop,
        },
      ],
      { cancelable: false } // Prevent closing by tapping outside
    );
  };
  const showRecipeChangeConfirmation = () => {
    Alert.alert(
      "Confirm Change of Making Recipe", // Title
      "Are you sure you want to proceed with this Recipe?", // Message
      [
        {
          text: "Cancel",
          onPress: () => console.log("Cancel Pressed"),
          style: "cancel",
        },
        {
          text: "Yes",
          onPress: onRecipeStart,
        },
      ],
      { cancelable: false } // Prevent closing by tapping outside
    );
  };
  return (
    <SafeAreaView style={styles.container}>
      <TouchableOpacity onPress={onToggle} style={styles.backBtnCon}>
        <Image
          source={require("../../../../assets/images/backBtn.png")}
          style={styles.backBtnIcon}
        />
      </TouchableOpacity>
      <ScrollView
        style={ing_styles.scrollcontainer}
        showsVerticalScrollIndicator={false}
        showsHorizontalScrollIndicator={false}
      >
        <View style={styles.ImgCon}>
          <Image
            source={require("../../../../assets/images/recipes/recipe.png")}
            style={styles.mainImg}
          />
          <Pressable onPress={addToFav} style={styles.heartICon}>
            {recipeDetails?.liked ? (
              <Image
                style={styles.recipeHeartIcon}
                source={require("../../../../assets/images/heart_red.png")}
              />
            ) : (
              <Image
                style={styles.recipeHeartIcon}
                source={require("../../../../assets/images/heart.png")}
              />
            )}
          </Pressable>
        </View>
        <Text style={styles.recipeTitle}>{recipeDetails?.title}</Text>

        <View style={styles.detailsRow}>
          <View style={styles.detailsRow_left}>
            <Pressable onPress={addToFav}>
              {recipeDetails?.liked ? (
                <Image
                  source={require("../../../../assets/images/heart_red.png")}
                  style={styles.heartIcon}
                />
              ) : (
                <Image
                  source={require("../../../../assets/images/heart.png")}
                  style={styles.heartIcon}
                />
              )}
            </Pressable>
            <Text style={styles.detailsRow_likesLbl}>
              {recipeDetails?.liked
                ? "Added to favourite!"
                : "Add To Favourite?"}
            </Text>
          </View>
          <Text style={styles.CaloriesLbl}>
            {recipeDetails?.calories} per 100 grams
          </Text>
        </View>
        <View style={styles.cookingRow}>
          <Text style={styles.cookingRowLbl}>Cooking time</Text>

          <Image
            source={require("../../../../assets/images/clock.png")}
            style={styles.cookingRow_clockIcon}
          />
          <Text style={styles.cookingRowLbl}>
            {recipeDetails?.cooking_time}
          </Text>
        </View>
        <View style={recipe_styles.btnCon}>
          {recipeRunning == 0 ? (
            <TouchableOpacity
              style={[
                recipe_styles.button,
                {
                  backgroundColor: recipeDetails?.available
                    ? recipeDetails.available == true
                      ? "#F8A600"
                      : "#696e77"
                    : "#F8A600",
                },
              ]}
              onPress={showRecipeStartConfirmation}
              disabled={
                recipeDetails?.available ? !recipeDetails.available : false
              }
            >
              <Text style={recipe_styles.buttonText}>Start Recipe</Text>
            </TouchableOpacity>
          ) : recipeRunning == 1 ? (
            <>
              <TouchableOpacity
                style={[
                  recipe_styles.button,
                  recipe_styles.stopButton,
                  recipe_styles.finishButton,
                ]}
                onPress={showRecipeFinishConfirmation}
              >
                <Text style={recipe_styles.buttonText}>Finish Recipe</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[recipe_styles.button, recipe_styles.stopButton]}
                onPress={showRecipeCancelConfirmation}
              >
                <Text style={recipe_styles.buttonText}>Cancel Recipe</Text>
              </TouchableOpacity>
            </>
          ) : (
            <TouchableOpacity
              style={[recipe_styles.button, recipe_styles.StopStartbutton]}
              onPress={showRecipeChangeConfirmation}
            >
              <Text style={recipe_styles.buttonText}>
                Stop other and Start this Recipe
              </Text>
            </TouchableOpacity>
          )}
        </View>
        <View style={styles.menuBar}>
          <TouchableOpacity
            style={selectedTab ? styles.item : styles.selecteditem}
            onPress={() => setSelectedTab(false)}
          >
            <Text style={styles.itemText}>Ingredients</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={!selectedTab ? styles.item : styles.selecteditem}
            onPress={() => setSelectedTab(true)}
          >
            <Text style={styles.itemText}>Recipe</Text>
          </TouchableOpacity>
        </View>
        {selectedTab == false ? (
          <View style={ing_styles.view}>
            <Text style={ing_styles.title}>Ingredients</Text>

            {recipeDetails?.ingredients.map((item, index) => (
              <View style={ing_styles.itemRow} key={index}>
                <View style={ing_styles.itemRowLeft}>
                  <Image
                    style={ing_styles.itemRowLeftImg}
                    source={require("../../../../assets/images/kitchen/item.png")}
                  />
                  <Text style={ing_styles.itemRowLeftLbl}>{item.name}</Text>
                </View>
                <View style={ing_styles.itemRowRight}>
                  <Text style={ing_styles.itemRowRight_lbl}>
                    {item.amount} {item.unit}
                  </Text>
                  <CheckBox onCheck={() => {}} />
                </View>
              </View>
            ))}
            {/* </ScrollView> */}
          </View>
        ) : (
          <View style={recipe_styles.view}>
            <Text style={recipe_styles.title}>Recipe</Text>
            <Pressable onPress={() => setModalVisible(true)}>
              <Text style={recipe_styles.subtitle}>
                {truncateText(recipeDetails?.recipe_short_summary)}
              </Text>
            </Pressable>

            <Text style={recipe_styles.title}>Steps</Text>

            {/* <View
              style={recipe_styles.scrollcontainer}
              showsVerticalScrollIndicator={false}
              showsHorizontalScrollIndicator={false}
            > */}
            {recipeDetails?.cooking_steps.map((item, index) => (
              <View style={recipe_styles.itemRow} key={index}>
                <CheckBox onCheck={() => {}} />
                <Text style={recipe_styles.itemRowLeftLbl}>{item}</Text>
              </View>
            ))}
            {/* </ScrollView> */}
          </View>
        )}
      </ScrollView>
      <RecipeModal
        modalVisible={modalVisible}
        setModalVisible={setModalVisible}
        text={recipeDetails?.recipe_short_summary}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,

    paddingHorizontal: 26,
    paddingVertical: 13,
    backgroundColor: "#FFF6E5",
  },
  input: {
    height: 50,
    borderColor: "#F8A600", // iOS default blue color for input focus
    borderWidth: 2,
    borderRadius: 10, // Rounded corners
    paddingHorizontal: 15,
    backgroundColor: "#F5F5F5", // Light background
    fontSize: 16,
    color: "#333", // Darker text color
    marginBottom: 20,
  },
  backBtnCon: {
    width: 38,
    height: 38,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#fff",
    borderRadius: 10,
    marginBottom: 20,
  },
  ImgCon: {
    width: "100%",
    position: "relative",
  },
  heartICon: {
    position: "absolute",
    right: 10,
    top: 10,
    padding: 5,
    backgroundColor: "rgba(255, 255, 255, 0.5)",
    borderRadius: 20,
  },
  mainImg: {
    width: "100%",
    // aspectRatio: 428 / 242,
    borderRadius: 10,
  },
  recipeTitle: {
    fontFamily: "InriaSerif_700Bold",
    color: "#000",
    fontSize: 28,
    lineHeight: 32,
    // fontWeight: "700",
    marginTop: 20,
  },
  detailsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 10,
  },
  detailsRow_left: {
    flexDirection: "row",
    alignItems: "center",
  },
  heartIcon: {
    marginRight: 4,
  },
  detailsRow_likesLbl: {
    fontFamily: "InriaSerif_400Regular",
    color: "#656565",
    fontSize: 13,
    lineHeight: 15,
    textDecorationLine: "underline",
  },
  CaloriesLbl: {
    fontFamily: "InriaSerif_400Regular",
    color: "#656565",
    fontSize: 13,
    lineHeight: 15,
  },
  cookingRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 10,
  },
  cookingRowLbl: {
    fontFamily: "InriaSerif_400Regular",
    color: "#656565",
    fontSize: 12,
    lineHeight: 14,
  },
  cookingRow_clockIcon: {
    marginRight: 5,
    marginLeft: 5,
  },
  menuBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    width: "100%", // 100% width of the parent container
    height: 22,
    backgroundColor: "#161714", // Background color
    borderRadius: 5, // Border radius

    // Shadow for iOS
    shadowColor: "#E6C068",
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 20,

    // Shadow for Android
    elevation: 10,
    marginTop: 20,
  },
  item: {
    width: 100,
    // flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    height: "100%",
  },
  itemText: {
    fontFamily: "InriaSerif_400Regular",
    color: "#fff",
    fontSize: 10,
    lineHeight: 12,
  },
  selecteditem: {
    width: 100,
    // flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#A4885E",
    height: "100%",
  },
});
const ing_styles = StyleSheet.create({
  view: {
    flex: 1,
  },
  title: {
    fontFamily: "InriaSerif_700Bold",
    color: "#000",
    fontSize: 18,
    lineHeight: 21,
    // fontWeight: "700",
    marginTop: 20,
  },
  scrollcontainer: {
    flex: 1,
  },
  itemRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: 10,
  },
  itemRowLeft: {
    flexDirection: "row",
    alignItems: "center",
  },
  itemRowLeftImg: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 8,
  },
  itemRowLeftLbl: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 14,
    fontWeight: "400",
    lineHeight: 16,
    textAlign: "left",
    color: "#000",
  },
  itemRowRight: {
    flexDirection: "row",
    alignItems: "center",
  },
  itemRowRight_lbl: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 14,
    fontWeight: "400",
    lineHeight: 16,
    textAlign: "left",
    color: "#000",
    marginRight: 14,
  },
  itemRowRight_checkBox: {
    width: 22,
    height: 22,
  },
});
const recipe_styles = StyleSheet.create({
  view: {
    flex: 1,
  },
  title: {
    fontFamily: "InriaSerif_700Bold",
    color: "#000",
    fontSize: 18,
    lineHeight: 21,
    // fontWeight: "700",
    marginTop: 20,
  },
  subtitle: {
    fontFamily: "InriaSerif_400Regular",
    color: "#000",
    fontSize: 15,
    lineHeight: 23,
    // fontWeight: "700",
    marginTop: 5,
  },
  scrollcontainer: {
    flex: 1,
  },
  itemRow: {
    flexDirection: "row",
    // alignItems: "center",
    // justifyContent: "space-between",
    marginTop: 13,
  },
  itemRowLeftLbl: {
    fontFamily: "InriaSerif_400Regular",
    color: "#000",
    fontSize: 15,
    lineHeight: 20,
    // fontWeight: "700",
    marginLeft: 8,
  },
  btnCon: {
    justifyContent: "center",
    flexDirection: "row",
    marginTop: 10,
  },
  button: {
    // width: 145,
    flex: 1,
    height: 32,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 8,
    backgroundColor: "#F8A600",
    maxWidth: "70%",
  },
  stopButton: {
    backgroundColor: "#d33942",
    maxWidth: "40%",
    marginHorizontal: 5,
  },
  finishButton: {
    backgroundColor: "#62af3f",
  },
  StopStartbutton: {
    backgroundColor: "#ff784b",
  },
  buttonText: {
    fontSize: 14,
    fontWeight: "500",
  },
});
const modalView_styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    // marginTop: 22,
    backgroundColor: "rgba(0, 0, 0,0.5)",
  },
  modalView: {
    margin: 40,
    maxHeight: "60%",
    backgroundColor: "white",
    borderRadius: 20,
    padding: 20,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  scrollcontainer: {
    flex: 1,
    // maxHeight: 100,
  },
  button: {
    borderRadius: 20,
    padding: 10,
    elevation: 2,
  },
  buttonOpen: {
    backgroundColor: "#F194FF",
  },
  buttonClose: {
    backgroundColor: "#2196F3",
  },
  textStyle: {
    color: "white",
    fontWeight: "bold",
    textAlign: "center",
  },
  modalText: {
    fontFamily: "InriaSerif_700Bold",
    color: "#000",
    fontSize: 18,
    lineHeight: 21,
    marginBottom: 15,
    // textAlign: "center",
  },
  modalTextRecipe: {
    fontFamily: "InriaSerif_400Regular",
    color: "#000",
    fontSize: 15,
    lineHeight: 18,
    // marginBottom: 15,
    // textAlign: "center",
  },
});
const CheckBox = ({ onCheck }) => {
  const [isChecked, setIsCheck] = useState(false);

  return isChecked ? (
    <TouchableOpacity onPress={() => setIsCheck(false)}>
      <Image
        style={ing_styles.itemRowRight_checkBox}
        source={require("../../../../assets/images/checkBox_checked.png")}
      />
    </TouchableOpacity>
  ) : (
    <TouchableOpacity onPress={() => setIsCheck(true)}>
      <Image
        style={ing_styles.itemRowRight_checkBox}
        source={require("../../../../assets/images/checkBox_unchecked.png")}
      />
    </TouchableOpacity>
  );
};

const RecipeModal = ({ modalVisible, setModalVisible, text }) => {
  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={modalVisible}
      onRequestClose={() => {
        // Alert.alert("Modal has been closed.");
        setModalVisible(!modalVisible);
      }}
    >
      <TouchableWithoutFeedback onPress={() => setModalVisible(false)}>
        <View style={modalView_styles.centeredView}>
          <TouchableWithoutFeedback onPress={() => {}}>
            <View style={modalView_styles.modalView}>
              <Text style={modalView_styles.modalText}>Recipe</Text>
              <ScrollView
                style={modalView_styles.scrollcontainer}
                showsVerticalScrollIndicator={false}
                showsHorizontalScrollIndicator={false}
              >
                <Text style={modalView_styles.modalTextRecipe}>{text}</Text>
              </ScrollView>

              {/* <Pressable
                style={[modalView_styles.button, modalView_styles.buttonClose]}
                onPress={() => setModalVisible(!modalVisible)}
              >
                <Text style={modalView_styles.textStyle}>Hide Modal</Text>
              </Pressable> */}
            </View>
          </TouchableWithoutFeedback>
        </View>
      </TouchableWithoutFeedback>
    </Modal>
  );
};

function truncateText(text) {
  const maxLength = 200;
  if (text == null) {
    return "";
  }
  if (text.length > maxLength) {
    return text.slice(0, maxLength) + "... read more";
  } else {
    return text; // return the text as is if it's under 200 chars
  }
}
