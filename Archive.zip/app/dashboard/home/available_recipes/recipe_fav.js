import {
  View,
  TextInput,
  Button,
  StyleSheet,
  Text,
  TouchableOpacity,
  Image,
  ScrollView,
  ActivityIndicator,
  Pressable,
  ToastAndroid,
} from "react-native";
import React, { useState, useEffect } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import { useNavigation, useRouter, Link } from "expo-router";
import { getData, postData } from "../../../../services/apiService";
import { useFocusEffect } from "expo-router";
import { useCallback } from "react";
import { useAppContext } from "@/components/AppContext";

export default function Favorite_recipes() {
  const { loggedInUser } = useAppContext();

  const [loadingSaved, setLoadingSaved] = useState(false);
  const [savedRecipes, setSavedRecipes] = useState([]);

  const [generatedRecipes, setGeneratedRecipes] = useState([]);

  const navigation = useNavigation();
  const router = useRouter();
  useFocusEffect(
    useCallback(() => {
      fetchSavedRecipe();

      return () => {
        console.log("This route is now unfocused.");
      };
    }, [])
  );
  const onToggle = () => {
    // navigation.goBack();
    // router.back();
    router.push("/dashboard/home");
  };
  const fetchSavedRecipe = async () => {
    if (loggedInUser == null) return;
    setLoadingSaved(true);

    try {
      const response = await getData("/api/recipe/list_fav");
      // console.log("Response from API:", response);
      response.favourite_recipes = response.favourite_recipes.map((recipe) => {
        return { ...recipe, liked: true };
      });
      setSavedRecipes(response.favourite_recipes);
      setLoadingSaved(false);
    } catch (error) {
      console.error("Error posting data:", error);
      ToastAndroid.show("Failed to fetch Saved Recipes", ToastAndroid.SHORT);
      setLoadingSaved(false);
    }
  };

  const handlePress = (data) => {
    router.push({
      pathname: "/dashboard/home/available_recipes/recipe_home",
      params: {
        data: JSON.stringify(data),
      },
    });
  };
  const removeItem = (itemToRemove) => {
    // Filter out the item to remove
    const updatedList = generatedRecipes.filter(
      (item) => item !== itemToRemove
    );

    // Update the state with the new list
    setGeneratedRecipes(updatedList);
  };
  return (
    <SafeAreaView style={styles.container}>
      <TouchableOpacity onPress={onToggle} style={styles.backBtnCon}>
        <Image
          source={require("../../../../assets/images/backBtn.png")}
          style={styles.backBtnIcon}
        />
      </TouchableOpacity>

      <ScrollView
        style={styles.scrollcontainer}
        showsVerticalScrollIndicator={false}
        showsHorizontalScrollIndicator={false}
      >
        <Text style={styles.maintitle}>Your Saved Recipes</Text>
        {loadingSaved ? (
          <ActivityIndicator size="small" color="#000" />
        ) : (
          <View style={styleSaveRecipesCard.rowRecipe}>
            {savedRecipes.map((item) => (
              <Pressable
                style={styleSaveRecipesCard.card}
                onPress={() => handlePress(item)}
              >
                <View style={styleSaveRecipesCard.top}>
                  <Image
                    style={styleSaveRecipesCard.recipeIcon}
                    source={require("../../../../assets/images/recipes/recipe.png")}
                  />
                  <View style={styleSaveRecipesCard.heartICon}>
                    <Image
                      style={styleSaveRecipesCard.recipeHeartIcon}
                      source={require("../../../../assets/images/black_heart.png")}
                    />
                  </View>
                  <View style={styleSaveRecipesCard.likesCard}>
                    <Text style={styleSaveRecipesCard.numbersRating}>4.5</Text>
                    <Image
                      style={styleSaveRecipesCard.recipeStarIcon}
                      source={require("../../../../assets/images/star.png")}
                    />
                    <Text style={styleSaveRecipesCard.numbersLikes}>
                      {"("}+4.5{")"}
                    </Text>
                  </View>
                </View>
                <Text
                  style={styleSaveRecipesCard.recipeName}
                  numberOfLines={1} // Limits to 1 line, truncating if overflow occurs
                  ellipsizeMode="tail"
                >
                  {item.title}
                </Text>
                <Text
                  style={styleSaveRecipesCard.recipesubtitle}
                  numberOfLines={1} // Limits to 1 line, truncating if overflow occurs
                  ellipsizeMode="middle"
                >
                  {item.recipe_short_summary}
                </Text>
              </Pressable>
            ))}
          </View>
        )}
        {savedRecipes.length == 0 && (
          <Text style={styles.warning}>
            No Saved Recipes here! Try Generating one...
          </Text>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,

    paddingHorizontal: 26,
    paddingVertical: 13,
    backgroundColor: "#FFF6E5",
  },
  input: {
    height: 50,
    borderColor: "#F8A600", // iOS default blue color for input focus
    borderWidth: 2,
    borderRadius: 10, // Rounded corners
    paddingHorizontal: 15,
    backgroundColor: "#F5F5F5", // Light background
    fontSize: 16,
    color: "#333", // Darker text color
  },
  backBtnCon: {
    width: 38,
    height: 38,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#fff",
    borderRadius: 10,
    // marginBottom: 20,
  },
  maintitle: {
    fontFamily: "InriaSerif_700Bold",
    color: "#000",
    fontSize: 18,
    lineHeight: 22,
    fontWeight: "700",
    marginBottom: 20,
    marginTop: 20,
  },
  charCount: {
    fontFamily: "InriaSerif_400Regular",
    color: "#000",
    textAlign: "right",
    fontSize: 10,
    lineHeight: 11,
    marginTop: 5,
    marginBottom: 10,
  },
  scrollcontainer: {
    flex: 1,
    // paddingBottom:250
  },
  btnCon: {
    justifyContent: "center",
    flexDirection: "row",
    // marginBottom: 20,
  },
  button: {
    // width: 145,
    flex: 1,
    height: 48,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 8,
    backgroundColor: "#F8A600",
  },
  buttonText: {
    fontSize: 16,
  },
  warning: {
    fontFamily: "InriaSerif_400Regular",
    color: "#000",
    textAlign: "center",
    fontSize: 14,
    lineHeight: 16,
  },
});

const styleRecipesCard = StyleSheet.create({
  card: {
    flex: 1,
    flexDirection: "row",
    justifyContent: "space-between",
    maxHeight: 82,
    marginBottom: 8,
  },
  left: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
  },
  recipeIcon: {
    width: 82,
    height: 82,
    shadowColor: "#E6C068",
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 10,
    elevation: 20,
  },
  recipeDetailsCol: {
    // flex: 1,
    marginLeft: 20,
    flexDirection: "column",
    justifyContent: "space-between",
    height: "100%",
    maxWidth: "65%",
  },
  recipeDetailsColTitle: {
    fontFamily: "InriaSerif_700Bold",
    color: "#656565",
    fontSize: 16,
    lineHeight: 20,
    fontWeight: "700",
  },
  recipeDetailsColCal: {
    fontSize: 14,
    color: "#666",
  },
  recipeDetailsColViewBtn: {
    width: 70,
    height: 22,
    borderRadius: 5,
    backgroundColor: "#000",
    justifyContent: "center",
    alignItems: "center",
  },
  recipeDetailsColViewBtnText: {
    color: "#fff",
    fontFamily: "InriaSerif_400Regular",
    textAlign: "center",
    fontSize: 12,
    lineHeight: 13,
  },
});

const styleSaveRecipesCard = StyleSheet.create({
  rowRecipe: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-evenly",
  },
  card: {
    width: "45%",
    // maxWidth: 152,
    // height: 212,
    // maxHeight: 212,
    paddingBottom: 10,
    // paddingRight:10,

    borderRadius: 14.77,
    backgroundColor: "rgba(214, 214, 214, 0.3)", // equivalent to #D6D6D64D
    overflow: "hidden",
    marginBottom: 10,
  },
  top: {
    position: "relative",
  },
  recipeIcon: {
    width: "100%",
    height: 145,
    borderRadius: 14.77,
  },
  heartICon: {
    position: "absolute",
    top: 10,
    // left: 0,
    // bottom: 0,
    backgroundColor: "rgba(255, 255, 255, 0.5)",
    right: 10,
    // padding: 2,
    width: 20,
    height: 20,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
    // borderRadius: 10,
  },
  recipeHeartIcon: {
    width: 15,
    height: 15,
  },
  likesCard: {
    position: "absolute",
    padding: 8,
    bottom: -10,
    left: 10,
    flexDirection: "row",
    backgroundColor: "#fff",
    alignItems: "center",
    borderRadius: 50,
  },
  recipeStarIcon: {
    marginHorizontal: 8,
  },
  numbersRating: {
    fontFamily: "InriaSerif_700Bold",
    color: "#000",
    fontSize: 10,
    lineHeight: 11,
  },
  numbersLikes: {
    fontFamily: "InriaSerif_400Regular",
    color: "#9796A1",
    fontSize: 7,
    lineHeight: 8,
  },
  recipeName: {
    fontFamily: "InriaSerif_700Bold",
    color: "#000",
    fontSize: 14,
    lineHeight: 17,
    marginTop: 15,
    marginLeft: 8,
    marginRight: 8,
  },
  recipesubtitle: {
    fontFamily: "InriaSerif_400Regular",
    color: "#161714",
    fontSize: 12,
    lineHeight: 15,
    marginTop: 5,
    marginLeft: 8,
    marginRight: 8,
  },
});
