import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  ToastAndroid,
  Pressable,
  TextInput,
  Modal,
  ActivityIndicator,
} from "react-native";
import React, { useState, useEffect } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { getData, postData } from "../../../services/apiService";

import { useFocusEffect } from "expo-router";
import { useCallback } from "react";
import { useAppContext } from "@/components/AppContext";

export default function kitchen() {
  const router = useRouter();
  const [showEditModal, setShowEditModal] = useState(null);

  const [loading, setLoading] = useState(false);
  const [isLoadingupdate, setIsLoadingupdate] = useState(false);

  const [listofItems, setListofItems] = useState([]);
  const { activeKitchenId } = useAppContext();
  const [quantities, setQuantities] = useState({});
  const [modifiedRows, setModifiedRows] = useState({});

  const [searchQuery, setSearchQuery] = useState("");

  const listTheItemsKitchens = async (KID) => {
    setLoading(true);
    try {
      const response = await getData(
        "/api/kitchen/list_items?kitchen_id=" + KID
      );
      console.log(response.items);
      // const initialQuantities = response.items.reduce((acc, item) => {
      //   acc[item.name] = item.quantity || 0; // Initialize with item quantity or 0
      //   return acc;
      // }, {});
      // setQuantities(initialQuantities);
      setListofItems(response.items);
    } catch (error) {
      console.error("Error posting data:", error);
    } finally {
      setLoading(false);
    }
  };

  useFocusEffect(
    useCallback(() => {
      if (activeKitchenId != null) {
        listTheItemsKitchens(activeKitchenId.kitchen_id);
      }

      return () => {
        console.log("This route is now unfocused.");
      };
    }, [activeKitchenId])
  );
  // const handleIncrement = (itemName, unit, group) => {
  //   setQuantities((prevQuantities) => {
  //     const newQuantities = {
  //       ...prevQuantities,
  //       [itemName]: prevQuantities[itemName] + 1,
  //     };
  //     setModifiedRows((prevRows) => ({
  //       ...prevRows,
  //       [itemName]: { unit, group },
  //     }));
  //     return newQuantities;
  //   });
  // };

  // const handleDecrement = (itemName, unit, group) => {
  //   setQuantities((prevQuantities) => {
  //     const newQuantities = {
  //       ...prevQuantities,
  //       [itemName]: Math.max(prevQuantities[itemName] - 1, 0), // Prevent negative values
  //     };
  //     setModifiedRows((prevRows) => ({
  //       ...prevRows,
  //       [itemName]: { unit, group },
  //     }));
  //     return newQuantities;
  //   });
  // };
  // const handleSaveAll = async () => {
  //   setIsLoadingupdate(true);
  //   const modifiedItems = Object.keys(modifiedRows).map((itemName) => ({
  //     name: itemName,
  //     unit: modifiedRows[itemName]?.unit,
  //     quantity: quantities[itemName],
  //     group: modifiedRows[itemName]?.group,
  //   }));

  //   if (modifiedItems.length > 0) {
  //     console.log(modifiedItems);
  //     try {
  //       const response = await postData("/api/kitchen/update_items", {
  //         kitchen_id: activeKitchenId.kitchen_id,
  //         items: modifiedItems, // Send all modified items
  //       });
  //       ToastAndroid.show("All changes saved!", ToastAndroid.SHORT);
  //       setModifiedRows({}); // Clear modified rows
  //     } catch (error) {
  //       console.error("Error saving data:", error);
  //       ToastAndroid.show("Error saving changes.", ToastAndroid.SHORT);
  //     } finally {
  //       setIsLoadingupdate(false);
  //     }
  //   } else {
  //     ToastAndroid.show("No changes to save.", ToastAndroid.SHORT);
  //   }
  // };
  const filteredAndGroupedItems = listofItems.reduce((acc, item) => {
    if (item.name.toLowerCase().includes(searchQuery.toLowerCase())) {
      if (!acc[item.group]) {
        acc[item.group] = [];
      }
      acc[item.group].push(item);
    }
    return acc;
  }, {});
  return (
    <SafeAreaView style={styles.container}>
      <TouchableOpacity
        onPress={() => router.push("/dashboard/home")}
        style={styles.backBtnCon}
      >
        <Image
          source={require("r../../../assets/images/back.png")}
          style={styles.backBtnIcon}
        />
      </TouchableOpacity>
      <View
        style={{ flex: 1 }}
        // showsVerticalScrollIndicator={false}
        // showsHorizontalScrollIndicator={false}
      >
        <View style={styles.kitchenCon}>
          <Text style={styles.kitchenTitle}>All Ingredients</Text>
          <View style={styles.searchContainer}>
            <TextInput
              style={styles.searchInput}
              placeholder="Search Ingredients..."
              value={searchQuery}
              onChangeText={setSearchQuery} // Update search query
            />
            <Pressable
              onPress={() => setSearchQuery("")} // Clear search input
              style={styles.clearBtn}
            >
              <Text style={styles.controlText}>Clear</Text>
            </Pressable>
          </View>
          <ScrollView
            style={styles.scrollcontainer}
            showsVerticalScrollIndicator={false}
            showsHorizontalScrollIndicator={false}
          >
            {loading ? (
              <Text>Loading...</Text>
            ) : Object.keys(filteredAndGroupedItems).length === 0 ? (
              <Text>No Ingredients Found.</Text>
            ) : (
              Object.keys(filteredAndGroupedItems).map((group) => (
                <View key={group}>
                  <Text style={styles.groupTitle}>{group}</Text>
                  {filteredAndGroupedItems[group].map((kit, index) => (
                    <View style={styles.kitchenRowTouch} key={kit.name}>
                      <View style={styles.row}>
                        <Image
                          source={require("../../../assets/images/kitchen/item.png")}
                          style={styles.kitchenIcon}
                        />
                        <Text style={styles.kitchenLbl}>{kit.name}</Text>
                        <Text style={styles.kitchenLblUnit}>
                          {"( "} {kit.quantity} {kit.unit} {" )"}
                        </Text>
                      </View>
                      <View style={styles.btnCon}>
                        {activeKitchenId?.role != "member" && (
                          <TouchableOpacity
                            style={styles.button}
                            onPress={() => setShowEditModal(kit)}
                          >
                            <Text style={styles.buttonText}>Edit</Text>
                          </TouchableOpacity>
                        )}
                      </View>
                      {/* <View style={styles.controls}>
                      <Pressable
                        onPress={() =>
                          handleDecrement(kit.name, kit.unit, kit.group)
                        }
                        style={styles.controlBtn}
                      >
                        <Text style={styles.controlText}>-</Text>
                      </Pressable>
                      <TextInput
                        keyboardType="numeric"
                        value={quantities[kit.name]?.toString()}
                        editable={false}
                        style={styles.quantityInput}
                      />
                      <Pressable
                        onPress={() =>
                          handleIncrement(kit.name, kit.unit, kit.group)
                        }
                        style={styles.controlBtn}
                      >
                        <Text style={styles.controlText}>+</Text>
                      </Pressable>
                    </View> */}
                    </View>
                  ))}
                </View>
              ))
            )}
          </ScrollView>
          {/* <View style={styles.btnCon}>
            <TouchableOpacity
              style={styles.button}
              onPress={handleSaveAll}
              disabled={isLoadingupdate}
            >
              <Text style={styles.buttonText}>
                {isLoadingupdate ? "Updating" : "Update"}{" "}
              </Text>
            </TouchableOpacity>
          </View> */}
        </View>
      </View>
      <UpdateItemModal
        isVisible={showEditModal != null}
        onClose={(e) => {
          setShowEditModal(null);
          if (e == true) listTheItemsKitchens(activeKitchenId?.kitchen_id);
        }}
        kitchenid={activeKitchenId?.kitchen_id}
        item={showEditModal}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    //   justifyContent: "center",
    //   alignItems: "center",
    paddingHorizontal: 28,
    paddingVertical: 13,
    backgroundColor: "#FFF6E5",
  },
  scrollcontainer: {
    flex: 1,
    minHeight: 100,
  },
  backBtnCon: {
    width: 38,
    height: 38,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#fff",
    borderRadius: 10,
  },
  kitchenCon: {
    marginTop: 12,
    flex: 1,
    paddingBottom: 12,
  },
  kitchenTitle: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 30,
    fontWeight: "400",
    lineHeight: 36,
    textAlign: "left",
    color: "#000",
    marginBottom: 10,
  },
  groupTitle: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 16,
    fontWeight: "400",
    lineHeight: 18,
    textAlign: "left",
    color: "#000",
    marginVertical: 5,
  },
  kitchenLst: {
    flex: 1,
  },
  kitchenRowTouch: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 8,
    justifyContent: "space-between",
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    // marginTop: 8,
  },
  controls: {
    flexDirection: "row",
    alignItems: "center",
  },
  controlBtn: {
    alignItems: "center",
    justifyContent: "center",
    width: 14,
    height: 14,
    backgroundColor: "#000",
    borderWidth: 0,
    borderRadius: 2,
  },
  controlText: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 12,
    fontWeight: "400",
    lineHeight: 12,
    textAlign: "center",
    color: "#fff",
    // marginBottom: 10,
  },
  quantityInput: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 12,
    fontWeight: "400",
    lineHeight: 12,
    textAlign: "center",
    color: "#000",
  },
  kitchenIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 10,
  },
  kitchenLbl: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 14,
    fontWeight: "400",
    lineHeight: 14,
    textAlign: "left",
    color: "#000",
  },
  kitchenLblUnit: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 13,
    fontWeight: "400",
    lineHeight: 13,
    textAlign: "left",
    color: "#6c757d",
    marginLeft: 4,
  },
  btnCon: {
    justifyContent: "center",
    flexDirection: "row",
    marginTop: 10,
  },
  button: {
    width: 55,
    height: 35,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 8,
    backgroundColor: "#F8A600",
  },
  buttonText: {
    fontSize: 13,
  },

  searchContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 15,
  },
  searchInput: {
    flex: 1,
    height: 40,
    borderColor: "#ddd",
    borderWidth: 1,
    borderRadius: 5,
    paddingLeft: 10,
    fontSize: 14,
    marginRight: 10,
  },
  clearBtn: {
    backgroundColor: "#F8A600",
    padding: 8,
    borderRadius: 5,
  },
});

function UpdateItemModal({ isVisible, onClose, kitchenid, item }) {
  const [value, setValue] = useState(0);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async () => {
    if (value == null || value == "" || isNaN(value)) {
      Alert.alert("Missing Fields", "Please fill out Value correctly");
      return;
    }
    try {
      setIsLoading(true);
      const modifiedItems = {
        name: item.name,
        unit: item?.unit,
        quantity: Number((Number(item.quantity) - Number(value)).toFixed(3)),
        group: item?.group,
      };
      console.log(modifiedItems);
      const response = await postData("/api/kitchen/update_items", {
        kitchen_id: kitchenid,
        items: [modifiedItems], // Send all modified items
      });
      console.log(response);
      if (response?.error) {
        throw new Error("Error");
      }

      ToastAndroid.show("Item Updated successfully!", ToastAndroid.SHORT); // Show success toast
    } catch (error) {
      alert("Failed to submit item. Please try again.");
      console.error(error);
    } finally {
      setIsLoading(false); // Hide loader
      onClose(true);
    }
  };
  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={isVisible}
      onRequestClose={() => onClose(false)}
    >
      <View style={modal_style.modalOverlay}>
        <View style={modal_style.modalContainer}>
          <View style={modal_style.titleRow}>
            <Text style={modal_style.modalTitle}>{item?.name}</Text>
            <Text style={modal_style.modalTitleUnit}>
              ~{item?.quantity} {item?.unit}
            </Text>
          </View>
          {/* <View style={modal_style.qtyRow}>
            <Text style={modal_style.qtyText}>Current Quantity:</Text>
            <Text style={modal_style.qtyTextVale}>{item?.quantity}</Text>
          </View> */}
          <Text style={modal_style.addButtonText}>
            Quantity {"( To Remove ):"}
          </Text>
          <TextInput
            style={modal_style.input}
            placeholder="0"
            value={value}
            keyboardType="numeric"
            disabled={isLoading}
            onChangeText={(text) => {
              if (!isNaN(text) && Number(text) <= Number(item?.quantity ?? 0))
                setValue(text);
            }}
          />

          <View style={modal_style.buttonContainer}>
            <TouchableOpacity
              style={modal_style.submitButton}
              onPress={handleSubmit}
            >
              {isLoading ? (
                <ActivityIndicator size="small" color="#0000ff" />
              ) : (
                <Text style={modal_style.submitButtonText}>Remove</Text>
              )}
            </TouchableOpacity>
            <TouchableOpacity
              style={modal_style.closeButton}
              onPress={() => onClose(false)}
              disabled={isLoading}
            >
              <Text style={modal_style.submitButtonText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const modal_style = StyleSheet.create({
  buttonText: {
    color: "#fff",
    fontSize: 16,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  modalContainer: {
    backgroundColor: "#fff",
    width: "85%",
    borderRadius: 10,
    paddingHorizontal: 15,
    paddingVertical: 15,
    elevation: 10,
    maxHeight: "60%",
  },
  titleRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: "bold",
    textAlign: "center",
  },
  modalTitleUnit: {
    fontSize: 16,
    textAlign: "center",
    color: "#9e9e9e",
    marginLeft: 4,
  },
  buttonContainer: {
    flexDirection: "row",
    justifyContent: "center",
    gap: 8,
    marginTop: 10,
  },
  list: {
    flexGrow: 0,
  },
  qtyRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
    paddingHorizontal: 0,
  },
  qtyText: {
    fontSize: 16,
    color: "#545454",
  },
  qtyTextVale: {
    fontSize: 16,
    color: "#000",
    marginLeft: 5,
  },
  index: {
    width: 25,
    textAlign: "center",
    fontSize: 14,
    fontWeight: "bold",
  },
  input: {
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 5,
    paddingVertical: 0,
    paddingHorizontal: 5,
    marginHorizontal: 2,
    height: 35,
  },
  addButton: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 15,
    justifyContent: "center",
  },
  addButtonText: {
    // marginLeft: 10,
    fontSize: 14,
    color: "#007bff",
    marginBottom: 5,
  },
  submitButton: {
    backgroundColor: "#007bff",
    paddingVertical: 8,
    paddingHorizontal: 20,
    borderRadius: 10,
    alignItems: "center",
  },
  closeButton: {
    backgroundColor: "#d33942",
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 10,
    alignItems: "center",
  },
  submitButtonText: {
    color: "#fff",
    fontSize: 16,
  },
});
