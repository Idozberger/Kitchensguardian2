import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  Alert,
  Animated,
} from "react-native";
import React, { useState, useEffect, useRef, useCallback } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { getScanHistory } from "../../../services/apiService";
import { useAppContext } from "@/components/AppContext";
import { useFocusEffect } from "expo-router";
import { format } from "date-fns";

export default function SearchedItems() {
  const router = useRouter();
  const { activeKitchenId } = useAppContext();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [scanHistory, setScanHistory] = useState([]);
  const [currentPage, setCurrentPage] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const [expandedItems, setExpandedItems] = useState({});
  const animationValues = useRef({});
  const scrollViewRef = useRef(null);
  const isFetching = useRef(false);

  // Add a cleanup function to reset all states
  const resetState = useCallback(() => {
    setScanHistory([]);
    setCurrentPage(0);
    setHasMore(true);
    setError(null);
    setLoading(false);
    setExpandedItems({});
    isFetching.current = false;
    // Cleanup animation values
    Object.values(animationValues.current).forEach(value => value.stopAnimation());
    animationValues.current = {};
  }, []);

  useFocusEffect(
    useCallback(() => {
      if (activeKitchenId) {
        // Reset state when entering the screen
        resetState();
        // Fetch initial data
        fetchScanHistory(0);
      }

      // Cleanup when leaving the screen
      return () => {
        resetState();
      };
    }, [activeKitchenId])
  );

  const fetchScanHistory = async (page) => {
    if (!activeKitchenId || isFetching.current) return;
    
    isFetching.current = true;
    setLoading(true);
    setError(null);
    try {
      const response = await getScanHistory(page);
      if (response?.history) {
        // Initialize animation values for new items before setting state
        response.history.forEach((item) => {
          if (!animationValues.current[item.scanned_at]) {
            animationValues.current[item.scanned_at] = new Animated.Value(0);
          }
        });

        if (page === 0) {
          setScanHistory(response.history);
        } else {
          setScanHistory(prev => [...prev, ...response.history]);
        }
        
        // Check if there are more items to load
        setHasMore(response.history.length > 0);
      } else if (response?.error) {
        setError(response.error);
      }
    } catch (error) {
      console.error("Error fetching scan history:", error);
      setError("Failed to load scan history. Please try again.");
      if (error.message.includes("token")) {
        Alert.alert("Session Expired", "Please log in again.");
      }
    } finally {
      setLoading(false);
      isFetching.current = false;
    }
  };

  const handleScroll = useCallback((event) => {
    const { layoutMeasurement, contentOffset, contentSize } = event.nativeEvent;
    const paddingToBottom = 50;
    const isCloseToBottom = layoutMeasurement.height + contentOffset.y >= 
      contentSize.height - paddingToBottom;

    if (isCloseToBottom && hasMore && !loading && !isFetching.current) {
      console.log('Triggering next page load:', currentPage + 1);
      setCurrentPage(prev => prev + 1);
      // Fetch next page immediately
      fetchScanHistory(currentPage + 1);
      scrollViewRef.current.scrollToEnd({ animated: true });
    }
  }, [hasMore, loading, currentPage]);

  const toggleAccordion = (scannedAt) => {
    // Ensure animation value exists
    if (!animationValues.current[scannedAt]) {
      animationValues.current[scannedAt] = new Animated.Value(0);
    }

    setExpandedItems(prev => {
      const newState = { ...prev, [scannedAt]: !prev[scannedAt] };
      
      // Animate the expansion/collapse
      Animated.timing(animationValues.current[scannedAt], {
        toValue: newState[scannedAt] ? 1 : 0,
        duration: 300,
        useNativeDriver: false,
      }).start();
      
      return newState;
    });
  };

  const formatDate = (dateString) => {
    try {
      return format(new Date(dateString), "MMM dd, yyyy 'at' h:mm a");
    } catch (error) {
      return dateString;
    }
  };

  const formatQuantity = (amount, unit) => {
    const numAmount = parseFloat(amount);
    return `${numAmount} ${numAmount === 1 ? unit : unit + 's'}`;
  };

  const renderPagination = () => {
    const pages = [];
    const maxVisiblePages = 5; // Maximum number of page buttons to show
    
    // Ensure totalPages is at least 1
    const safeTotalPages = Math.max(1, totalPages);
    
    // Calculate start page, ensuring it's never negative
    let startPage = Math.max(0, Math.min(
      currentPage - Math.floor(maxVisiblePages / 2),
      safeTotalPages - maxVisiblePages
    ));

    // Add Previous button
    pages.push(
      <TouchableOpacity
        key="prev"
        style={[
          styles.pageButton,
          currentPage === 0 && styles.pageButtonDisabled
        ]}
        onPress={() => setCurrentPage(Math.max(0, currentPage - 1))}
        disabled={currentPage === 0 || loading}
      >
        <Text style={[
          styles.pageButtonText,
          currentPage === 0 && styles.pageButtonTextDisabled
        ]}>←</Text>
      </TouchableOpacity>
    );

    // Add page numbers
    for (let i = startPage; i < startPage + maxVisiblePages && i < safeTotalPages; i++) {
      pages.push(
        <TouchableOpacity
          key={i}
          style={[
            styles.pageButton,
            currentPage === i && styles.currentPageButton,
          ]}
          onPress={() => setCurrentPage(i)}
          disabled={loading}
        >
          <Text
            style={[
              styles.pageButtonText,
              currentPage === i && styles.currentPageButtonText,
            ]}
          >
            {i + 1}
          </Text>
        </TouchableOpacity>
      );
    }

    // Add Next button
    pages.push(
      <TouchableOpacity
        key="next"
        style={[
          styles.pageButton,
          currentPage === safeTotalPages - 1 && styles.pageButtonDisabled
        ]}
        onPress={() => setCurrentPage(Math.min(safeTotalPages - 1, currentPage + 1))}
        disabled={currentPage === safeTotalPages - 1 || loading}
      >
        <Text style={[
          styles.pageButtonText,
          currentPage === safeTotalPages - 1 && styles.pageButtonTextDisabled
        ]}>→</Text>
      </TouchableOpacity>
    );

    return (
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.pagination}
      >
        {pages}
      </ScrollView>
    );
  };

  if (!activeKitchenId) {
    return (
      <SafeAreaView style={styles.container}>
        <Text style={styles.errorText}>Please select a kitchen first</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <TouchableOpacity
        onPress={() => router.push("/dashboard/home")}
        style={styles.backBtnCon}
      >
        <Image
          source={require("../../../assets/images/back.png")}
        />
      </TouchableOpacity>

      <View style={styles.content}>
        <Text style={styles.title}>Scan History</Text>

        {loading && scanHistory.length === 0 ? (
          <View style={styles.initialLoadingContainer}>
            <ActivityIndicator size="large" color="#F8A600" />
            <Text style={styles.loadingText}>Loading scan history...</Text>
          </View>
        ) : error ? (
          <Text style={styles.errorText}>{error}</Text>
        ) : scanHistory.length === 0 ? (
          <Text style={styles.emptyText}>No scan history found</Text>
        ) : (
          <ScrollView 
            ref={scrollViewRef}
            style={styles.scrollView}
            onScroll={handleScroll}
            scrollEventThrottle={16}
            onEndReached={() => {
              if (hasMore && !loading && !isFetching.current) {
                console.log('End reached, loading more');
                setCurrentPage(prev => prev + 1);
              }
            }}
            onEndReachedThreshold={0.5}
          >
            {scanHistory.map((scan) => (
              <View key={scan.scanned_at} style={styles.accordionContainer}>
                <TouchableOpacity
                  style={styles.accordionHeader}
                  onPress={() => toggleAccordion(scan.scanned_at)}
                >
                  <View style={styles.headerContent}>
                    <Text style={styles.dateText}>
                      {formatDate(scan.scanned_at)}
                    </Text>
                    <Text style={styles.itemsCount}>
                      {scan.items.length} items
                    </Text>
                  </View>
                  <View style={[
                    styles.arrowIcon,
                    expandedItems[scan.scanned_at] && styles.arrowIconRotated
                  ]} />
                </TouchableOpacity>

                {animationValues.current[scan.scanned_at] && (
                  <Animated.View
                    style={[
                      styles.accordionContent,
                      {
                        maxHeight: animationValues.current[scan.scanned_at].interpolate({
                          inputRange: [0, 1],
                          outputRange: [0, 500],
                        }),
                      },
                    ]}
                  >
                    {scan.items.map((item, index) => (
                      <View key={index} style={styles.itemRow}>
                        <Text style={styles.itemName}>{item.name}</Text>
                        <Text style={styles.itemQuantity}>
                          {formatQuantity(item.amount, item.unit)}
                        </Text>
                      </View>
                    ))}
                  </Animated.View>
                )}
              </View>
            ))}
            {loading && (
              <View style={styles.loadingMoreContainer}>
                <View style={styles.loadingMore}>
                  <ActivityIndicator size="small" color="#F8A600" />
                  {/* <Text style={styles.loadingMoreText}>Loading more items...</Text> */}
                </View>
              </View>
            )}
          </ScrollView>
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFF6E5",
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 10,
  },
  backBtnCon: {
    width: 38,
    height: 38,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#fff",
    borderRadius: 10,
    margin: 20,
    marginBottom: 0,
  },
  backBtnIcon: {
    width: 24,
    height: 24,
  },
  title: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 30,
    fontWeight: "400",
    color: "#000",
    marginBottom: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  errorText: {
    color: "red",
    textAlign: "center",
    marginTop: 20,
  },
  emptyText: {
    textAlign: "center",
    marginTop: 20,
    color: "#666",
  },
  scrollView: {
    flex: 1,
  },
  accordionContainer: {
    backgroundColor: "#fff",
    borderWidth: 2,
    borderColor: "#F8A600",
    borderRadius: 10,
    marginBottom: 10,
    overflow: "hidden",
    // elevation: 2,
    // shadowColor: "#000",
    // shadowOffset: { width: 0, height: 2 },
    // shadowOpacity: 0.1,
    // shadowRadius: 4,
  },
  accordionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 15,
    backgroundColor: "#fff",
  },
  headerContent: {
    flex: 1,
  },
  dateText: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 16,
    color: "#000",
  },
  itemsCount: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 14,
    color: "#666",
    marginTop: 4,
  },
  arrowIcon: {
    width: 0,
    height: 0,
    backgroundColor: 'transparent',
    borderStyle: 'solid',
    borderLeftWidth: 6,
    borderRightWidth: 6,
    borderTopWidth: 10,
    borderLeftColor: 'transparent',
    borderRightColor: 'transparent',
    borderTopColor: '#F8A600',
    transform: [{ rotate: '0deg' }],
  },
  arrowIconRotated: {
    transform: [{ rotate: '180deg' }],
  },
  accordionContent: {
    backgroundColor: "#f9f9f9",
    overflow: "hidden",
  },
  itemRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    padding: 15,
    borderTopWidth: 1,
    borderTopColor: "#eee",
  },
  itemName: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 14,
    color: "#000",
  },
  itemQuantity: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 14,
    color: "#666",
  },
  paginationContainer: {
    height: 40,
    justifyContent: 'center',
  },
  pagination: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    paddingVertical: 5,
    gap: 4,
    paddingHorizontal: 10,
  },
  pageButton: {
    width: 30,
    height: 30,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 6,
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: "#F8A600",
  },
  currentPageButton: {
    backgroundColor: "#F8A600",
  },
  pageButtonDisabled: {
    borderColor: "#ccc",
    backgroundColor: "#f5f5f5",
  },
  pageButtonText: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 14,
    color: "#F8A600",
  },
  pageButtonTextDisabled: {
    color: "#ccc",
  },
  currentPageButtonText: {
    color: "#fff",
  },
  loadingMoreContainer: {
    paddingVertical: 20,
    backgroundColor: '#FFF6E5',
  },
  loadingMore: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'transparent',
    // paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 20,
    gap: 8,
    marginHorizontal: 20,
    shadowColor: "#000",
    // shadowOffset: {
    //   width: 0,
    //   height: 2,
    // },
    // shadowOpacity: 0.1,
    // shadowRadius: 3,
    // elevation: 3,
  },
  loadingMoreText: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 14,
    color: "#F8A600",
  },
  initialLoadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 16,
    color: "#F8A600",
    marginTop: 8,
  },
}); 