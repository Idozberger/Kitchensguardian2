import { GestureHandlerRootView } from "react-native-gesture-handler";
import { Drawer } from "expo-router/drawer";
import { Dimensions } from "react-native";
import SideMenuDrawer from "../../../components/SideMenu/SideMenuDrawer";
export default function homeLayout() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <Drawer
        drawerContent={SideMenuDrawer}
        screenOptions={{
          headerShown: false,
          drawerHideStatusBarOnOpen: true,
          drawerStyle: {
            width: Dimensions.get("window").width * 0.8,
          },
          drawerItemStyle: {
            margin: 0,
            padding: 0,
          },
        }}
      />
    </GestureHandlerRootView>
  );
}
