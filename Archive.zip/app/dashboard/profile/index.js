import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
} from "react-native";
import React, { useEffect, useState } from "react";
import { SafeAreaView, useSafeAreaFrame } from "react-native-safe-area-context";
import { Image } from "expo-image";
import ProfileIcon from "../../../assets/images/user.png";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useRouter } from "expo-router";

export default function profile() {
  const [userInfo, setUserinfo] = useState({
    firstName: "",
    lastName: "",
    email: "",
  });
    const router = useRouter();
  
  const fetchData = async () => {
    const usertoken = await AsyncStorage.getItem("@token");
    if (usertoken) {
      const decoded = decodeToken(usertoken);
      if (decoded) {
        setUserinfo({
          firstName: decoded.sub.first_name,
          lastName: decoded.sub.last_name,
          email: decoded.sub.email,
        });
      }
    }
  };

  useEffect(() => {
    fetchData();
  }, []);
  return (
    <SafeAreaView style={styles.container}>
      <View
        style={{ flexDirection: "row", justifyContent: "center", height: 80 }}
      >
        <Image
          contentFit="fill"
          source={ProfileIcon}
          style={{ width: 80, height: 80 }}
        />
      </View>
      <View style={styles.textInput}>
        <Text style={styles.textInputLbl}>First Name</Text>
        <TextInput
          style={styles.textInputText}
          placeholder="First Name"
          value={userInfo.firstName}
          editable={false}
        />
      </View>
      <View style={styles.textInput}>
        <Text style={styles.textInputLbl}>Last Name</Text>
        <TextInput
          style={styles.textInputText}
          placeholder="Last Name"
          value={userInfo.lastName}
          editable={false}
        />
      </View>
      <View style={styles.textInput}>
        <Text style={styles.textInputLbl}>E-mail</Text>
        <TextInput
          style={styles.textInputText}
          placeholder="mail@mail.com"
          value={userInfo.email}
          editable={false}
        />
      </View>
      <View style={styles.btnCon}>
        <TouchableOpacity
          style={styles.button}
          onPress={() => router.push("/dashboard/profile/change-pwd")}
        >
          <Text style={styles.buttonText}>Change Password</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}
const decodeToken = (jwt) => {
  try {
    const base64Url = jwt.split(".")[1]; // Get payload
    let base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/"); // Decode base64url to base64

    // Add padding if necessary
    const padding = "=".repeat((4 - (base64.length % 4)) % 4); // Calculate padding
    base64 += padding; // Add padding

    const jsonPayload = decodeURIComponent(
      atob(base64)
        .split("")
        .map((c) => `%${`00${c.charCodeAt(0).toString(16)}`.slice(-2)}`)
        .join("")
    );

    return JSON.parse(jsonPayload);
  } catch (error) {
    console.error("Error decoding JWT:", error);
    return null;
  }
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // justifyContent: "center",
    // alignItems: "center",
    paddingHorizontal: 43,
    paddingVertical: 90,
    backgroundColor: "#FFF6E5",
  },
  textInput: {
    marginVertical: 15,
  },
  textInputLbl: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 14,
    fontWeight: "400",
  },
  textInputText: {
    height: 48,
    width: "100%",
    backgroundColor: "#fff",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#eee",
    paddingHorizontal: 16,
    marginTop: 8,
    fontFamily: "InriaSerif_400Regular",
    fontSize: 13,
    color: "#000",
  },
  btnCon: {
    flexDirection: "row",
    justifyContent: "center",
    marginTop: 36,
  },
  button: {
    width: 248,
    height: 48,
    borderRadius: 28.5,
    backgroundColor: "#000000",
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#E6C068",
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 1,
    shadowRadius: 20,
    elevation: 5,
  },
  buttonText: {
    color: "#F8A600",
    fontFamily: "InriaSerif_400Regular",
    fontSize: 14,
    lineHeight: 16.79,
    letterSpacing: 0.08,
    textAlign: "center",
  },
});
