import { Stack } from "expo-router";

export default function profileLayout() {
  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="index" />
      <Stack.Screen name="change-pwd" />
    </Stack>
  );
}
