import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  TextInput,
  ToastAndroid,
} from "react-native";
import React, { useState } from "react";
import { SafeAreaView } from "react-native-safe-area-context";

import { useRouter, useLocalSearchParams } from "expo-router";
import { getData, postData } from "../services/apiService";
import { useAppContext } from "@/components/AppContext";
import AsyncStorage from "@react-native-async-storage/async-storage";

export default function veriification() {
  const [loading, setLoading] = useState(false);
  const [loadingResend, setLoadingResend] = useState(false);

  const [verifyCode, setVerifycode] = useState(null);
  // const [userEmail, setVerifycode] = useState(null);

  const { setLoggedInUser } = useAppContext();
  const { email } = useLocalSearchParams();

  const router = useRouter();

  const handlePress = async () => {
    setLoading(true);
    // const dataToSend = {
    //   email: "saad@gmail.com",
    //   password: "saad123",
    // };
    if (!verifyCode || verifyCode == "") {
      Alert.alert("Error", "Please fill Code.");
      setLoading(false);
      return;
    }

    const dataToSend = {
      email: email,
      verification_code: verifyCode,
    };
    try {
      const response = await postData("/api/verify_user", dataToSend);
      if (response.error) {
        Alert.alert("Error", response.error);
      } else if (response.message == "User verified successfully") {
        const decoded = decodeToken(response?.access_token);
        if (decoded == null) {
          throw new Error("Invalid Token");
        }
        await AsyncStorage.setItem("@token", response?.access_token);
        // Alert.alert("Success", "User Verified!");
        ToastAndroid.show("User Verified!", ToastAndroid.SHORT); // Show success toast
        setLoggedInUser(decoded?.sub);
        router.replace("/dashboard/home/kitchen/kitchen_lst");
      } else {
        Alert.alert("Failed", "Something went wrong!");
      }
    } catch (error) {
      console.error("Error posting data:", error);

      setLoading(false);
      Alert.alert("Failed", "Something went wrong!");
    } finally {
      setLoading(false);
    }
  };
  const resendCode = async () => {
    setLoadingResend(true);
    // const myHeaders = new Headers();
    // myHeaders.append("Content-Type", "application/json");

    // const raw = JSON.stringify({
    //   "email": "saaddemo@yopmail.com"
    // });

    // const requestOptions = {
    //   method: "POST",
    //   headers: myHeaders,
    //   body: raw,
    //   redirect: "follow"
    // };

    // fetch("https://fcf6a732-70b0-4df6-9779-df32cd7edac3-00-2q4mtnr6rzfzw.worf.replit.dev/api/send_verification_code", requestOptions)
    //   .then((response) => response.text())
    //   .then((result) => console.log(result))
    //   .catch((error) => console.error(error));
    if (!email) {
      Alert.alert("Error", "Email Missing!");
      setLoadingResend(false);
      return;
    }

    const dataToSend = {
      email: email,
    };
    try {
      const response = await postData(
        "/api/send_verification_code",
        dataToSend
      );
      if (response.error) {
        Alert.alert("Error", response.error);
      } else if (response.message == "Verification code sent successfully") {
        Alert.alert("Success", "Verification code sent successfully");
      } else {
        Alert.alert("Failed", "Something went wrong!");
      }
    } catch (error) {
      console.error("Error posting data:", error);

      Alert.alert("Failed", "Something went wrong!");
    }
    setLoadingResend(false);
  };
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.heading}>Verification Code</Text>

      <Text style={styles.subheading}>
        Please type the verification code sent to {email}
      </Text>

      <View style={styles.textInput}>
        <Text style={styles.textInputLbl}>Code</Text>
        <TextInput
          style={styles.textInputText}
          placeholder="0000"
          value={verifyCode}
          editable={!loading}
          onChangeText={(text) => {
            setVerifycode(text);
          }}
        />
      </View>

      <View style={styles.btnCon}>
        <TouchableOpacity
          style={styles.button}
          onPress={handlePress}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator size="small" color="#ffffff" />
          ) : (
            <Text style={styles.buttonText}>Verify</Text>
          )}
        </TouchableOpacity>
      </View>

      <TouchableOpacity
        onPress={() => {
          if (!loadingResend) resendCode();
        }}
        style={styles.belowCon}
      >
        <Text style={[styles.linkText, { color: "#000", fontSize: 14 }]}>
          I don't recevie a code!
        </Text>
        <Text style={[styles.linkText, { fontSize: 14 }]}>
          {" "}
          {loadingResend ? "Resending..." : "Please resend"}
        </Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // justifyContent: "center",
    // alignItems: "center",
    paddingHorizontal: 43,
    paddingVertical: 50,
    backgroundColor: "#FFF6E5",
  },
  heading: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 36,
    fontWeight: "400",
    lineHeight: 43.2,
    textAlign: "left",
  },
  subheading: {
    marginTop: 25,
    marginBottom: 15,
    fontFamily: "InriaSerif_400Regular",
    fontSize: 14,
    fontWeight: "400",
  },
  textInput: {
    marginTop: 15,
  },
  textInputLbl: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 14,
    fontWeight: "400",
  },
  textInputText: {
    height: 48,
    width: "100%",
    backgroundColor: "#fff",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#eee",
    paddingHorizontal: 16,
    marginTop: 8,
    fontFamily: "InriaSerif_400Regular",
    fontSize: 13,
    color: "#000",
  },
  linkCon: {
    flexDirection: "row",
    justifyContent: "flex-end",
  },
  linkText: {
    color: "#E6C068",
    fontFamily: "InriaSerif_700Bold",
    fontSize: 12,
  },
  btnCon: {
    flexDirection: "row",
    justifyContent: "center",
    marginTop: 36,
  },
  button: {
    width: 248,
    height: 48,
    borderRadius: 28.5,
    backgroundColor: "#000000",
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#E6C068",
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 1,
    shadowRadius: 20,
    elevation: 5,
  },
  buttonText: {
    color: "#F8A600",
    fontFamily: "InriaSerif_400Regular",
    fontSize: 14,
    lineHeight: 16.79,
    letterSpacing: 0.08,
    textAlign: "center",
  },
  belowCon: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginTop: 50,
  },
});
const decodeToken = (jwt) => {
  try {
    const base64Url = jwt.split(".")[1]; // Get payload
    let base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/"); // Decode base64url to base64

    // Add padding if necessary
    const padding = "=".repeat((4 - (base64.length % 4)) % 4); // Calculate padding
    base64 += padding; // Add padding

    const jsonPayload = decodeURIComponent(
      atob(base64)
        .split("")
        .map((c) => `%${`00${c.charCodeAt(0).toString(16)}`.slice(-2)}`)
        .join("")
    );

    return JSON.parse(jsonPayload);
  } catch (error) {
    console.error("Error decoding JWT:", error);
    return null;
  }
};
