import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  TextInput,
  ScrollView,
  ToastAndroid,
} from "react-native";
import React, { useState } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { getData, postData } from "../services/apiService";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useAppContext } from "@/components/AppContext";

export default function signup() {
  const [loading, setLoading] = useState(false);
  const [fname, setFname] = useState("");
  const [lname, setLname] = useState("");

  const [email, setEmail] = useState("");
  const [pwd, setPwd] = useState("");
  const [cPwd, setCPwd] = useState("");

  const { setLoggedInUser } = useAppContext();

  const router = useRouter();

  const handlePress = async () => {
    setLoading(true);
    // const dataToSend = {
    //   email: "saad@gmail.com",
    //   password: "saad123",
    // };
    if (!email || !pwd) {
      Alert.alert("Error", "Please fill in all fields.");
      setLoading(false);
      return;
    }
    if (!/\S+@\S+\.\S+/.test(email)) {
      Alert.alert("Error", "Please enter a valid email address.");
      setLoading(false);
      return;
    }
    if (pwd != cPwd) {
      Alert.alert("Error", "Password didn't Match!");
      setLoading(false);
      return;
    }
    const dataToSend = {
      first_name: fname,
      last_name: lname,
      email: email,
      0: pwd,
    };
    try {
      const response = await postData("/api/register_user", dataToSend);
      if (response.error) {
        Alert.alert("Error", response.error);
      } else if (response.message == "User created successfully") {
        const response = await postData(
          "/api/send_verification_code",
          dataToSend
        );

        // Alert.alert("Success", "User created successfully");
        ToastAndroid.show("User created successfully!", ToastAndroid.SHORT); // Show success toast

        setCPwd("");
        // setEmail("");
        setFname("");
        setLname("");
        setPwd("");
        router.replace({
          pathname: "/verification",

          params: {
            email: email,
          },
        });
        // router.push({
        //   pathname: "/dashboard/home/available_recipes/recipe_home",
        //   params: {
        //     data: JSON.stringify(runningRecipeContext[selectedRunningRecipeIndex]),
        //   },
        // });
      } else {
        Alert.alert("Failed", "Something went wrong!");
      }
    } catch (error) {
      console.error("Error posting data:", error);

      setLoading(false);
      Alert.alert("Failed", "Something went wrong!");
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView
        style={styles.scrollcontainer}
        showsVerticalScrollIndicator={false}
        showsHorizontalScrollIndicator={false}
      >
        <Text style={styles.heading}>Sign Up</Text>
        <View style={styles.textInput}>
          <Text style={styles.textInputLbl}>First Name</Text>
          <TextInput
            style={styles.textInputText}
            placeholder="Arlene"
            value={fname}
            editable={!loading}
            onChangeText={(text) => {
              setFname(text);
            }}
          />
        </View>
        <View style={styles.textInput}>
          <Text style={styles.textInputLbl}>Last Name</Text>
          <TextInput
            style={styles.textInputText}
            placeholder="Mccoy"
            value={lname}
            editable={!loading}
            onChangeText={(text) => {
              setLname(text);
            }}
          />
        </View>
        <View style={styles.textInput}>
          <Text style={styles.textInputLbl}>E-mail</Text>
          <TextInput
            style={styles.textInputText}
            placeholder="abc@mail.com"
            value={email}
            editable={!loading}
            onChangeText={(text) => {
              setEmail(text);
            }}
          />
        </View>

        <View style={styles.textInput}>
          <Text style={styles.textInputLbl}>Password</Text>
          <TextInput
            style={styles.textInputText}
            placeholder="********"
            secureTextEntry={true}
            value={pwd}
            editable={!loading}
            onChangeText={(text) => {
              setPwd(text);
            }}
          />
        </View>
        <View style={styles.textInput}>
          <Text style={styles.textInputLbl}>Confirm Password</Text>
          <TextInput
            style={styles.textInputText}
            placeholder="********"
            secureTextEntry={true}
            value={cPwd}
            editable={!loading}
            onChangeText={(text) => {
              setCPwd(text);
            }}
          />
        </View>

        <View style={styles.btnCon}>
          <TouchableOpacity
            style={styles.button}
            onPress={handlePress}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator size="small" color="#ffffff" />
            ) : (
              <Text style={styles.buttonText}>Sign Up</Text>
            )}
          </TouchableOpacity>
        </View>

        <TouchableOpacity
          onPress={() => router.push("/")}
          style={styles.belowCon}
        >
          <Text style={[styles.linkText, { color: "#000", fontSize: 14 }]}>
            Already have an account?
          </Text>
          <Text style={[styles.linkText, { fontSize: 14 }]}> Login</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // justifyContent: "center",
    // alignItems: "center",
    paddingHorizontal: 43,
    paddingTop: 50,
    paddingBottom: 25,

    backgroundColor: "#FFF6E5",
  },
  scrollcontainer: {
    flex: 1,
    paddingBottom: 50,

    // paddingBottom:250
  },
  heading: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 36,
    fontWeight: "400",
    lineHeight: 43.2,
    textAlign: "left",
  },
  textInput: {
    marginTop: 15,
  },
  textInputLbl: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 14,
    fontWeight: "400",
  },
  textInputText: {
    height: 48,
    width: "100%",
    backgroundColor: "#fff",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#eee",
    paddingHorizontal: 16,
    marginTop: 8,
    fontFamily: "InriaSerif_400Regular",
    fontSize: 13,
    color: "#000",
  },
  linkCon: {
    flexDirection: "row",
    justifyContent: "flex-end",
  },
  linkText: {
    color: "#E6C068",
    fontFamily: "InriaSerif_700Bold",
    fontSize: 12,
  },
  btnCon: {
    flexDirection: "row",
    justifyContent: "center",
    marginTop: 36,
  },
  button: {
    width: 248,
    height: 48,
    borderRadius: 28.5,
    backgroundColor: "#000000",
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#E6C068",
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 1,
    shadowRadius: 20,
    elevation: 5,
  },
  buttonText: {
    color: "#F8A600",
    fontFamily: "InriaSerif_400Regular",
    fontSize: 14,
    lineHeight: 16.79,
    letterSpacing: 0.08,
    textAlign: "center",
  },
  belowCon: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginTop: 40,
  },
});
const decodeToken = (jwt) => {
  try {
    const base64Url = jwt.split(".")[1]; // Get payload
    let base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/"); // Decode base64url to base64

    // Add padding if necessary
    const padding = "=".repeat((4 - (base64.length % 4)) % 4); // Calculate padding
    base64 += padding; // Add padding

    const jsonPayload = decodeURIComponent(
      atob(base64)
        .split("")
        .map((c) => `%${`00${c.charCodeAt(0).toString(16)}`.slice(-2)}`)
        .join("")
    );

    return JSON.parse(jsonPayload);
  } catch (error) {
    console.error("Error decoding JWT:", error);
    return null;
  }
};
