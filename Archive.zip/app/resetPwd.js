import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  TextInput,
} from "react-native";
import React, { useState } from "react";
import { SafeAreaView } from "react-native-safe-area-context";

import { useRouter, useLocalSearchParams } from "expo-router";
import { getData, postData } from "../services/apiService";
import { useAppContext } from "@/components/AppContext";

export default function veriification() {
  const [loading, setLoading] = useState(false);
  const [loadingResend, setLoadingResend] = useState(false);

  const [verifyCode, setVerifycode] = useState("");
  const [newPwd, setNewPwd] = useState("");
  const [newPwdConfirm, setNewPwdConfirm] = useState("");

  // const [userEmail, setVerifycode] = useState(null);

  const { setLoggedInUser } = useAppContext();
  const { email } = useLocalSearchParams();

  const router = useRouter();

  const handlePress = async () => {
    setLoading(true);

    if (!verifyCode || verifyCode == "") {
      Alert.alert("Error", "Please fill Code.");
      setLoading(false);
      return;
    }
    if (!newPwd || newPwd == "" || newPwd.length < 6) {
      Alert.alert("Error", "Please fill Password.");
      setLoading(false);
      return;
    }

    if (newPwdConfirm != newPwd) {
      Alert.alert("Error", "Please fill Confirm Password Correctly .");
      setLoading(false);
      return;
    }

    const dataToSend = {
      email: email,
      reset_code: verifyCode,
      new_password: newPwd
    };
    try {
      const response = await postData("/api/reset_password", dataToSend);
      if (response.error) {
        Alert.alert("Error", response.error);
      } else if (response.message == "Password reset successfully") {
        Alert.alert("Success", "Password reset successfully!");
        router.replace("/");
      } else {
        Alert.alert("Failed", "Something went wrong!");
      }
    } catch (error) {
      console.error("Error posting data:", error);

      setLoading(false);
      Alert.alert("Failed", "Something went wrong!");
    } finally {
      setLoading(false);
    }
  };
  const resendCode = async () => {
    setLoadingResend(true);
    if (!email) {
      Alert.alert("Error", "Email Missing!");
      setLoadingResend(false);
      return;
    }

    const dataToSend = {
      email: email,
    };
    try {
      const response = await postData(
        "/api/forgot_password",
        dataToSend
      );
      if (response.error) {
        Alert.alert("Error", response.error);
      } else if (response.message == "Password reset code sent successfully") {
        Alert.alert("Success", "Password reset code sent successfully");
      } else {
        Alert.alert("Failed", "Something went wrong!");
      }
    } catch (error) {
      console.error("Error posting data:", error);

      Alert.alert("Failed", "Something went wrong!");
    }
    setLoadingResend(false);
  };
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.heading}>Reset Password</Text>

      <Text style={styles.subheading}>
        Please type the verification code sent to {email}
      </Text>

      <View style={styles.textInput}>
        <Text style={styles.textInputLbl}>Code</Text>
        <TextInput
          style={styles.textInputText}
          placeholder="0000"
          value={verifyCode}
          editable={!loading}
          onChangeText={(text) => {
            setVerifycode(text);
          }}
        />
      </View>

      <View style={styles.textInput}>
        <Text style={styles.textInputLbl}>New Password</Text>
        <TextInput
          style={styles.textInputText}
          placeholder="****"
          value={newPwd}
          editable={!loading}
          onChangeText={(text) => {
            setNewPwd(text);
          }}
        />
      </View>

      <View style={styles.textInput}>
        <Text style={styles.textInputLbl}>Confirm Password</Text>
        <TextInput
          style={styles.textInputText}
          placeholder="****"
          value={newPwdConfirm}
          editable={!loading}
          onChangeText={(text) => {
            setNewPwdConfirm(text);
          }}
        />
      </View>
      <View style={styles.btnCon}>
        <TouchableOpacity
          style={styles.button}
          onPress={handlePress}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator size="small" color="#ffffff" />
          ) : (
            <Text style={styles.buttonText}>Submit</Text>
          )}
        </TouchableOpacity>
      </View>

      <TouchableOpacity
        onPress={() => {
          if (!loadingResend) resendCode();
        }}
        style={styles.belowCon}
      >
        <Text style={[styles.linkText, { color: "#000", fontSize: 14 }]}>
          I don't recevie a code!
        </Text>
        <Text style={[styles.linkText, { fontSize: 14 }]}>
          {" "}
          {loadingResend ? "Resending..." : "Please resend"}
        </Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // justifyContent: "center",
    // alignItems: "center",
    paddingHorizontal: 43,
    paddingVertical: 50,
    backgroundColor: "#FFF6E5",
  },
  heading: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 36,
    fontWeight: "400",
    lineHeight: 43.2,
    textAlign: "left",
  },
  subheading: {
    marginTop: 25,
    marginBottom: 15,
    fontFamily: "InriaSerif_400Regular",
    fontSize: 14,
    fontWeight: "400",
  },
  textInput: {
    marginTop: 15,
  },
  textInputLbl: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 14,
    fontWeight: "400",
  },
  textInputText: {
    height: 48,
    width: "100%",
    backgroundColor: "#fff",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#eee",
    paddingHorizontal: 16,
    marginTop: 8,
    fontFamily: "InriaSerif_400Regular",
    fontSize: 13,
    color: "#000",
  },
  linkCon: {
    flexDirection: "row",
    justifyContent: "flex-end",
  },
  linkText: {
    color: "#E6C068",
    fontFamily: "InriaSerif_700Bold",
    fontSize: 12,
  },
  btnCon: {
    flexDirection: "row",
    justifyContent: "center",
    marginTop: 36,
  },
  button: {
    width: 248,
    height: 48,
    borderRadius: 28.5,
    backgroundColor: "#000000",
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#E6C068",
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 1,
    shadowRadius: 20,
    elevation: 5,
  },
  buttonText: {
    color: "#F8A600",
    fontFamily: "InriaSerif_400Regular",
    fontSize: 14,
    lineHeight: 16.79,
    letterSpacing: 0.08,
    textAlign: "center",
  },
  belowCon: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginTop: 50,
  },
});
const decodeToken = (jwt) => {
  try {
    const base64Url = jwt.split(".")[1]; // Get payload
    let base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/"); // Decode base64url to base64

    // Add padding if necessary
    const padding = "=".repeat((4 - (base64.length % 4)) % 4); // Calculate padding
    base64 += padding; // Add padding

    const jsonPayload = decodeURIComponent(
      atob(base64)
        .split("")
        .map((c) => `%${`00${c.charCodeAt(0).toString(16)}`.slice(-2)}`)
        .join("")
    );

    return JSON.parse(jsonPayload);
  } catch (error) {
    console.error("Error decoding JWT:", error);
    return null;
  }
};
