import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  TextInput,
} from "react-native";
import React, { useEffect, useState } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { getData, postData } from "../services/apiService";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useAppContext } from "@/components/AppContext";

export default function index() {
  const [loading, setLoading] = useState(false);
  // const [email, setEmail] = useState("saad@gmail.com");
  // const [pwd, setPwd] = useState("saad123");
  // 957238
  // const [email, setEmail] = useState("sssohail8611@gmail.com");
  // const [pwd, setPwd] = useState("12345678");
  const [email, setEmail] = useState("");
  const [pwd, setPwd] = useState("");
  const { setLoggedInUser, loggedInUser } = useAppContext();

  const router = useRouter();
  useEffect(() => {
    if (loggedInUser != null) {
      router.replace("/dashboard/home/kitchen/kitchen_lst");
    }
  }, [loggedInUser]);
  const handlePress = async () => {
    setLoading(true);
    // const dataToSend = {
    //   email: "saad@gmail.com",
    //   password: "saad123",
    // };
    if (!email || !pwd) {
      Alert.alert("Error", "Please fill in all fields.");
      setLoading(false);
      return;
    }
    if (!/\S+@\S+\.\S+/.test(email)) {
      Alert.alert("Error", "Please enter a valid email address.");
      setLoading(false);
      return;
    }
    const dataToSend = {
      email: email,
      password: pwd,
    };
    try {
      const response = await postData("/api/login", dataToSend);
      if (
        response?.access_token != undefined &&
        response?.access_token != null
      ) {
        console.log(typeof response?.access_token, response?.access_token);
        const decoded = decodeToken(response?.access_token);
        if (decoded == null) {
          throw new Error("Invalid Token");
        }
        await AsyncStorage.setItem("@token", response?.access_token);
        setLoading(false);
        setLoggedInUser(decoded?.sub);

        router.replace("/dashboard/home/kitchen/kitchen_lst");
        console.log("Decoded JWT:", decoded);
      } else if (response.error == "User not verified") {
        router.replace({
          pathname: "/verification",

          params: {
            email: email,
          },
        });
      } else {
        Alert.alert("Error", "Invalid email or password.");
      }
    } catch (error) {
      console.error("Error posting data:", error);

      setLoading(false);
      Alert.alert("Failed", "Something went wrong!");
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.heading}>Login</Text>
      <View style={styles.textInput}>
        <Text style={styles.textInputLbl}>E-mail</Text>
        <TextInput
          style={styles.textInputText}
          placeholder="abc@mail.com"
          value={email}
          editable={!loading}
          onChangeText={(text) => {
            setEmail(text);
          }}
        />
      </View>
      <View style={styles.textInput}>
        <Text style={styles.textInputLbl}>Password</Text>
        <TextInput
          style={styles.textInputText}
          placeholder="********"
          secureTextEntry={true}
          value={pwd}
          editable={!loading}
          onChangeText={(text) => {
            setPwd(text);
          }}
        />
      </View>
      <View style={styles.linkCon}>
        <TouchableOpacity
          onPress={() => {
            router.push("/forgotPwd");
          }}
        >
          <Text style={styles.linkText}>Forgot password?</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.btnCon}>
        <TouchableOpacity
          style={styles.button}
          onPress={handlePress}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator size="small" color="#ffffff" />
          ) : (
            <Text style={styles.buttonText}>Login</Text>
          )}
        </TouchableOpacity>
      </View>

      <TouchableOpacity
        onPress={() => {
          router.push("/signup");
        }}
        style={styles.belowCon}
      >
        <Text style={[styles.linkText, { color: "#000", fontSize: 14 }]}>
          Don't have an account?{" "}
        </Text>
        <Text style={[styles.linkText, { fontSize: 14 }]}>Sign up</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // justifyContent: "center",
    // alignItems: "center",
    paddingHorizontal: 43,
    paddingVertical: 90,
    backgroundColor: "#FFF6E5",
  },
  heading: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 36,
    fontWeight: "400",
    lineHeight: 43.2,
    textAlign: "left",
  },
  textInput: {
    marginVertical: 15,
  },
  textInputLbl: {
    fontFamily: "InriaSerif_400Regular",
    fontSize: 14,
    fontWeight: "400",
  },
  textInputText: {
    height: 48,
    width: "100%",
    backgroundColor: "#fff",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#eee",
    paddingHorizontal: 16,
    marginTop: 8,
    fontFamily: "InriaSerif_400Regular",
    fontSize: 13,
    color: "#000",
  },
  linkCon: {
    flexDirection: "row",
    justifyContent: "flex-end",
  },
  linkText: {
    color: "#E6C068",
    fontFamily: "InriaSerif_700Bold",
    fontSize: 12,
  },
  btnCon: {
    flexDirection: "row",
    justifyContent: "center",
    marginTop: 48,
  },
  button: {
    width: 248,
    height: 48,
    borderRadius: 28.5,
    backgroundColor: "#000000",
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#E6C068",
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 1,
    shadowRadius: 20,
    elevation: 5,
  },
  buttonText: {
    color: "#F8A600",
    fontFamily: "InriaSerif_400Regular",
    fontSize: 14,
    lineHeight: 16.79,
    letterSpacing: 0.08,
    textAlign: "center",
  },
  belowCon: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginTop: 100,
  },
});
const decodeToken = (jwt) => {
  try {
    const base64Url = jwt.split(".")[1]; // Get payload
    let base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/"); // Decode base64url to base64

    // Add padding if necessary
    const padding = "=".repeat((4 - (base64.length % 4)) % 4); // Calculate padding
    base64 += padding; // Add padding

    const jsonPayload = decodeURIComponent(
      atob(base64)
        .split("")
        .map((c) => `%${`00${c.charCodeAt(0).toString(16)}`.slice(-2)}`)
        .join("")
    );

    return JSON.parse(jsonPayload);
  } catch (error) {
    console.error("Error decoding JWT:", error);
    return null;
  }
};
