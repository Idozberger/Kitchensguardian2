import axios from "axios";
import AsyncStorage from "@react-native-async-storage/async-storage";
const apiClient = axios.create({
  baseURL:
    // "https://fcf6a732-70b0-4df6-9779-df32cd7edac3-00-2q4mtnr6rzfzw.worf.replit.dev", // Replace with your API's base URL
    "https://kitchen-guardian-apis.replit.app",
  timeout: 1000000, // You can set a timeout
  headers: {
    "Content-Type": "application/json",
  },
});

apiClient.interceptors.request.use(
  async (config) => {
    try {
      const token = await AsyncStorage.getItem("@token");
      // console.log("token:", token);
      // const token =
      //   "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJmcmVzaCI6ZmFsc2UsImlhdCI6MTcyNzY0NDIyNCwianRpIjoiMjAxNjBjM2UtYmMwNi00NmU1LTg4YjgtYWJmOTE4OWI3NDczIiwidHlwZSI6ImFjY2VzcyIsInN1YiI6eyJ1c2VyX2lkIjoiNjZlNWQxMzRmMjAzN2VmMjFlNDc2MTg5IiwiZmlyc3RfbmFtZSI6IklkbyIsImxhc3RfbmFtZSI6IkJlcmdlciIsImVtYWlsIjoiaWRvQGdtYWlsLmNvbSJ9LCJuYmYiOjE3Mjc2NDQyMjQsImNzcmYiOiJjODg1N2FlNy1kNmMxLTQzNDUtYWVhZi02OWI3ODY3ZmE0YzciLCJleHAiOjE3Mjc3MzA2MjR9.a8w4YKstb6S0zOMgzPRYxWPFvTEY9oziCR2bdWZGT9s";

      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
    } catch (error) {
      console.error("Error fetching token:", error);
    }

    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

export const getData = async (endpoint, params = {}) => {
  try {
    const response = await apiClient.get(endpoint, { params });
    return response.data;
  } catch (error) {
    if (error.response) {
      console.error("Error Response Data:", error.response.data);
      console.error("Error Response Status:", error.response.status);
      console.error("Error Response Headers:", error.response.headers);
    } else if (error.request) {
      console.error("Error Request:", error.request);
    } else {
      console.error("Error Message:", error.message);
    }
  }
};

export const postData = async (endpoint, data) => {
  try {
    console.log("Data", endpoint, data);
    const response = await apiClient.post(endpoint, data);
    console.log("Data", response.data);
    return response.data;
  } catch (error) {
    console.error("Data", error.request);

    if (error.response) {
      console.error("Server Error:", error.response.data);
      return error.response.data;
    } else if (error.request) {
      console.error("Network Error: No response received.");
    } else {
      console.error("Request Error:", error.message);
    }
    return { error: "Error" };
  }
};

export const postDataForm = async (endpoint, formData) => {
  try {
    const response = await apiClient.post(endpoint, formData, {
      headers: {
        "Content-Type": "multipart/form-data", // Ensure headers are set for FormData
      },
    });
    return response.data;
  } catch (error) {
    if (error.response) {
      console.error("Server Error:", error.response.data);
      return error.response.data;
    } else if (error.request) {
      console.error("Network Error: No response received.");
    } else {
      console.error("Request Error:", error.message);
    }
  }
};

export const getScanHistory = async (page = 0) => {
  try {
    const response = await apiClient.get(`/api/get_scan_history?page=${page}`);
    console.log("Scan History", response.data);
    return response.data;
  } catch (error) {
    if (error.response) {
      console.error("Error Response Data:", error.response.data);
      console.error("Error Response Status:", error.response.status);
      console.error("Error Response Headers:", error.response.headers);
      return error.response.data;
    } else if (error.request) {
      console.error("Error Request:", error.request);
    } else {
      console.error("Error Message:", error.message);
    }
    return { error: "Failed to fetch scan history" };
  }
};

export const getAIGeneratedList = async (kitchenId) => {
  // console.log("in getAIGeneratedListss");
  try {
    const response = await apiClient.get(`/api/kitchen/get_ai_generated_list?kitchen_id=${kitchenId}`);
    // console.log("AI Generated List", response.data);
    // console.log("kitchenId:", kitchenId);
    return response.data;
  } catch (error) {
    if (error.response) {
      console.error("Error Response Data:", error.response.data);
      console.error("Error Response Status:", error.response.status);
      console.error("Error Response Headers:", error.response.headers);
      return error.response.data;
    } else if (error.request) {
      console.error("Error Request:", error.request);
    } else {
      console.error("Error Message:", error.message);
    }
    return { error: "Failed to fetch AI generated list" };
  }
};
